-- DEMO ONLY. Creates f6s_shop_demo; does NOT replace f6s_shop. Stop import if that demo database already exists.
-- =====================================================
-- WEBSITE QUẢN LÝ BÁN GIÀY THỂ THAO F6S
-- BẢN CÀI MỚI ĐÃ GỘP OTP + CATALOG + 5 SẢN PHẨM DEMO: 24/10/2026 (chỉ import file này).
-- Hệ quản trị CSDL: MySQL / MariaDB
-- =====================================================

-- Xóa database cũ nếu tồn tại và tạo lại
-- No DROP DATABASE: preserve existing databases. Installer requires a new f6s_shop_demo database.
CREATE DATABASE f6s_shop_demo CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Chọn database để sử dụng
USE f6s_shop_demo;

-- 1. TÀI KHOẢN (dùng chung cho Admin/Nhân viên và Khách hàng)
CREATE TABLE tai_khoan (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    ten_dang_nhap  VARCHAR(50)  NOT NULL UNIQUE,
    mat_khau       VARCHAR(255) NOT NULL,
    vai_tro        VARCHAR(20)  NOT NULL DEFAULT 'KHACH_HANG' CHECK (vai_tro IN ('ADMIN','NHAN_VIEN','KHACH_HANG')),
    trang_thai     TINYINT      NOT NULL DEFAULT 1,        -- 1: hoạt động, 0: khóa
    ngay_tao       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 2. NHÂN VIÊN
CREATE TABLE nhan_vien (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    ma_nhan_vien   VARCHAR(20)  NOT NULL UNIQUE,
    ho_ten         VARCHAR(100) NOT NULL,
    gioi_tinh      TINYINT,
    ngay_sinh      DATE,
    so_dien_thoai  VARCHAR(15) UNIQUE,
    email          VARCHAR(100) UNIQUE,
    dia_chi        VARCHAR(255),
    trang_thai     TINYINT NOT NULL DEFAULT 1,
    tai_khoan_id   INT NOT NULL UNIQUE,
    FOREIGN KEY (tai_khoan_id) REFERENCES tai_khoan(id)
);

-- 3. KHÁCH HÀNG
CREATE TABLE khach_hang (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    ma_khach_hang  VARCHAR(20)  NOT NULL UNIQUE,
    ho_ten         VARCHAR(100) NOT NULL,
    gioi_tinh      TINYINT,
    ngay_sinh      DATE,
    so_dien_thoai  VARCHAR(15),
    email          VARCHAR(100),
    dia_chi        VARCHAR(255),
    trang_thai     TINYINT NOT NULL DEFAULT 1,
    tai_khoan_id   INT UNIQUE,                               -- NULL = khách mua tại quầy
    FOREIGN KEY (tai_khoan_id) REFERENCES tai_khoan(id)
);

-- 4. DANH MỤC
CREATE TABLE danh_muc (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    ten_danh_muc   VARCHAR(100) NOT NULL UNIQUE,
    mo_ta          VARCHAR(255),
    trang_thai     TINYINT NOT NULL DEFAULT 1
);

-- 5. SẢN PHẨM
CREATE TABLE san_pham (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    ma_san_pham    VARCHAR(20)  NOT NULL UNIQUE,
    ten_san_pham   VARCHAR(200) NOT NULL,
    thuong_hieu    VARCHAR(100),
    mo_ta          TEXT,
    gia_ban        DECIMAL(15,0) NOT NULL CHECK (gia_ban >= 0),
    hinh_anh       VARCHAR(255),
    trang_thai     TINYINT NOT NULL DEFAULT 1,
    ngay_tao       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    danh_muc_id    INT NOT NULL,
    FOREIGN KEY (danh_muc_id) REFERENCES danh_muc(id)
);

-- 5b. SẢN PHẨM CHI TIẾT
CREATE TABLE san_pham_chi_tiet (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    san_pham_id    INT NOT NULL,
    kich_co        VARCHAR(10) NOT NULL,
    mau_sac        VARCHAR(50) NOT NULL,
    so_luong_ton   INT NOT NULL DEFAULT 0 CHECK (so_luong_ton >= 0),
    trang_thai     TINYINT NOT NULL DEFAULT 1,
    CONSTRAINT UQ_SP_Size_Color UNIQUE (san_pham_id, kich_co, mau_sac),
    FOREIGN KEY (san_pham_id) REFERENCES san_pham(id) ON DELETE CASCADE
);

-- 6. GIỎ HÀNG
CREATE TABLE gio_hang (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    khach_hang_id   INT NOT NULL UNIQUE,
    ngay_tao        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (khach_hang_id) REFERENCES khach_hang(id) ON DELETE CASCADE
);

-- 6b. GIỎ HÀNG CHI TIẾT
CREATE TABLE gio_hang_chi_tiet (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    gio_hang_id     INT NOT NULL,
    san_pham_chi_tiet_id INT NOT NULL,
    so_luong        INT NOT NULL CHECK (so_luong > 0),
    CONSTRAINT UQ_GioHang_SPCT UNIQUE (gio_hang_id, san_pham_chi_tiet_id),
    FOREIGN KEY (gio_hang_id) REFERENCES gio_hang(id) ON DELETE CASCADE,
    FOREIGN KEY (san_pham_chi_tiet_id) REFERENCES san_pham_chi_tiet(id)
);

-- 7. ĐỢT GIẢM GIÁ
CREATE TABLE dot_giam_gia (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    ma_dot           VARCHAR(20)  NOT NULL UNIQUE,
    ten_dot          VARCHAR(150) NOT NULL,
    phan_tram_giam   DECIMAL(5,2) NOT NULL CHECK (phan_tram_giam BETWEEN 0 AND 100),
    ngay_bat_dau     DATETIME NOT NULL,
    ngay_ket_thuc    DATETIME NOT NULL,
    trang_thai       TINYINT NOT NULL DEFAULT 1,
    CONSTRAINT CK_DotGiamGia_Time CHECK (ngay_ket_thuc > ngay_bat_dau)
);

CREATE TABLE dot_giam_gia_san_pham (
    dot_giam_gia_id INT NOT NULL,
    san_pham_id     INT NOT NULL,
    PRIMARY KEY (dot_giam_gia_id, san_pham_id),
    FOREIGN KEY (dot_giam_gia_id) REFERENCES dot_giam_gia(id) ON DELETE CASCADE,
    FOREIGN KEY (san_pham_id) REFERENCES san_pham(id) ON DELETE CASCADE
);

-- 8. PHIẾU GIẢM GIÁ
CREATE TABLE phieu_giam_gia (
    id                 INT AUTO_INCREMENT PRIMARY KEY,
    ma_phieu           VARCHAR(20)  NOT NULL UNIQUE,
    ten_phieu          VARCHAR(150) NOT NULL,
    loai_giam          VARCHAR(20)  NOT NULL CHECK (loai_giam IN ('PHAN_TRAM','TIEN_MAT')),
    gia_tri_giam       DECIMAL(15,2) NOT NULL CHECK (gia_tri_giam > 0),
    giam_toi_da        DECIMAL(15,0),
    don_toi_thieu      DECIMAL(15,0) NOT NULL DEFAULT 0,
    so_luong           INT NOT NULL DEFAULT 0,
    ngay_bat_dau       DATETIME NOT NULL,
    ngay_ket_thuc      DATETIME NOT NULL,
    trang_thai         TINYINT NOT NULL DEFAULT 1,
    CONSTRAINT CK_PhieuGiamGia_Time CHECK (ngay_ket_thuc > ngay_bat_dau)
);

-- 9. HÓA ĐƠN
CREATE TABLE hoa_don (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    ma_hoa_don          VARCHAR(20) NOT NULL UNIQUE,
    khach_hang_id       INT,
    nhan_vien_id        INT,
    phieu_giam_gia_id   INT,
    loai_hoa_don        VARCHAR(20) NOT NULL DEFAULT 'ONLINE' CHECK (loai_hoa_don IN ('ONLINE','TAI_QUAY')),
    trang_thai          VARCHAR(30) NOT NULL DEFAULT 'CHO_XAC_NHAN' CHECK (trang_thai IN ('CHO_XAC_NHAN','DA_XAC_NHAN','DANG_GIAO','HOAN_THANH','DA_HUY')),
    phuong_thuc_thanh_toan VARCHAR(20) NOT NULL DEFAULT 'COD' CHECK (phuong_thuc_thanh_toan IN ('TIEN_MAT','CHUYEN_KHOAN','COD')),
    ten_nguoi_nhan      VARCHAR(100),
    sdt_nguoi_nhan      VARCHAR(15),
    dia_chi_giao        VARCHAR(255),
    tong_tien           DECIMAL(15,0) NOT NULL DEFAULT 0,
    tien_giam           DECIMAL(15,0) NOT NULL DEFAULT 0,
    phi_van_chuyen      DECIMAL(15,0) NOT NULL DEFAULT 0,
    tong_thanh_toan     DECIMAL(15,0) NOT NULL DEFAULT 0,
    ngay_tao            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ngay_thanh_toan     DATETIME,
    ghi_chu             VARCHAR(255),
    FOREIGN KEY (khach_hang_id)      REFERENCES khach_hang(id),
    FOREIGN KEY (nhan_vien_id)       REFERENCES nhan_vien(id),
    FOREIGN KEY (phieu_giam_gia_id)  REFERENCES phieu_giam_gia(id)
);

-- 9b. HÓA ĐƠN CHI TIẾT
CREATE TABLE hoa_don_chi_tiet (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    hoa_don_id          INT NOT NULL,
    san_pham_chi_tiet_id INT NOT NULL,
    so_luong            INT NOT NULL CHECK (so_luong > 0),
    don_gia             DECIMAL(15,0) NOT NULL,
    giam_gia            DECIMAL(15,0) NOT NULL DEFAULT 0,
    thanh_tien          DECIMAL(15,0) NOT NULL,
    FOREIGN KEY (hoa_don_id) REFERENCES hoa_don(id) ON DELETE CASCADE,
    FOREIGN KEY (san_pham_chi_tiet_id) REFERENCES san_pham_chi_tiet(id)
);

-- 10. BÀI VIẾT
CREATE TABLE bai_viet (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    tieu_de        VARCHAR(255) NOT NULL,
    noi_dung       LONGTEXT NOT NULL,
    hinh_anh       VARCHAR(255),
    ngay_dang      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    trang_thai     TINYINT NOT NULL DEFAULT 1,
    tai_khoan_id   INT NOT NULL,
    FOREIGN KEY (tai_khoan_id) REFERENCES tai_khoan(id)
);

-- INDEX
CREATE INDEX idx_sp_ten      ON san_pham(ten_san_pham);
CREATE INDEX idx_hd_ngay     ON hoa_don(ngay_tao);
CREATE INDEX idx_hd_trangthai ON hoa_don(trang_thai);

-- VIEW: thống kê doanh thu theo ngày
CREATE VIEW v_doanh_thu_ngay AS
SELECT CAST(ngay_tao AS DATE) AS ngay,
       COUNT(*)             AS so_hoa_don,
       SUM(tong_thanh_toan) AS doanh_thu
FROM hoa_don
WHERE trang_thai = 'HOAN_THANH'
GROUP BY CAST(ngay_tao AS DATE);

-- =====================================================
-- DỮ LIỆU MẪU
-- =====================================================
INSERT INTO tai_khoan (id, ten_dang_nhap, mat_khau, vai_tro) VALUES
(1, 'admin',  '123456', 'ADMIN'),
(2, 'nv01',   '123456', 'NHAN_VIEN'),
(3, 'kh01',   '123456', 'KHACH_HANG');

INSERT INTO nhan_vien (ma_nhan_vien, ho_ten, gioi_tinh, so_dien_thoai, email, tai_khoan_id)
VALUES ('NV01', 'Nguyễn Văn A', 1, '0900000001', 'nva@f6s.vn', 2);

INSERT INTO khach_hang (ma_khach_hang, ho_ten, gioi_tinh, so_dien_thoai, email, dia_chi, tai_khoan_id)
VALUES ('KH01', 'Trần Thị B', 0, '0900000002', 'ttb@gmail.com', 'Tây Hồ, Hà Nội', 3);

INSERT INTO gio_hang (khach_hang_id) VALUES (1);

INSERT INTO danh_muc (ten_danh_muc) VALUES ('Giày chạy bộ'), ('Giày bóng đá'), ('Giày bóng rổ'), ('Giày sneaker');

INSERT INTO san_pham (ma_san_pham, ten_san_pham, thuong_hieu, gia_ban, danh_muc_id) VALUES
('SP01', 'Nike Air Zoom Pegasus', 'Nike', 2800000, 1),
('SP02', 'Adidas Predator Elite', 'Adidas', 3500000, 2);

INSERT INTO san_pham_chi_tiet (san_pham_id, kich_co, mau_sac, so_luong_ton) VALUES
(1, '40', 'Đen', 20), (1, '41', 'Trắng', 15), (2, '42', 'Đỏ', 10);

INSERT INTO dot_giam_gia (ma_dot, ten_dot, phan_tram_giam, ngay_bat_dau, ngay_ket_thuc)
VALUES ('DGG01', 'Khai trương F6S', 10, '2026-10-01 00:00:00', '2026-10-31 23:59:59');

INSERT INTO dot_giam_gia_san_pham VALUES (1, 1);

INSERT INTO phieu_giam_gia (ma_phieu, ten_phieu, loai_giam, gia_tri_giam, giam_toi_da, don_toi_thieu, so_luong, ngay_bat_dau, ngay_ket_thuc)
VALUES ('VC50K', 'Giảm 50K', 'TIEN_MAT', 50000, NULL, 500000, 100, '2026-10-01 00:00:00', '2026-12-31 23:59:59');

-- BEGIN IMPORTED SOURCE SEED
-- Additive seed: select f6s_shop first; no DROP DATABASE.
SET NAMES utf8mb4;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `banner` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `active` bit(1) DEFAULT NULL,
  `created_date` datetime(6) DEFAULT NULL,
  `display_order` int DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `link_url` varchar(255) DEFAULT NULL,
  `page_name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `update_date` datetime(6) DEFAULT NULL,
  `banner_type` enum('NORMAL','SLIDER') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `blog` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` longtext,
  `created_date` datetime(6) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `image_banner` varchar(255) DEFAULT NULL,
  `meta_description` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `num_view` int DEFAULT NULL,
  `seo_title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `update_date` datetime(6) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKkr2fy24puc3x3sdnla4r1iok1` (`user_id`),
  CONSTRAINT `FKkr2fy24puc3x3sdnla4r1iok1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `carts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` datetime(6) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `update_date` datetime(6) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `product_detail_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK5qqlwln52o0l6o17r3awg39ap` (`user_id`,`product_detail_id`),
  KEY `FKmdnywg3iwer4982fw0ftydg2d` (`product_detail_id`),
  CONSTRAINT `FKmdnywg3iwer4982fw0ftydg2d` FOREIGN KEY (`product_detail_id`) REFERENCES `product_detail` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` datetime(6) DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `update_date` datetime(6) DEFAULT NULL,
  `parent_category_id` bigint DEFAULT NULL,
  `is_parent` bit(1) DEFAULT NULL,
  `category_parent` bigint DEFAULT NULL,
  `position` int DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKdi4x1yrvivfjqs0vsh9ux99dv` (`parent_category_id`),
  KEY `FKr1xsxlrwmvkn7l7tvhhhbfk6n` (`category_parent`),
  CONSTRAINT `FKdi4x1yrvivfjqs0vsh9ux99dv` FOREIGN KEY (`parent_category_id`) REFERENCES `parent_category` (`id`),
  CONSTRAINT `FKr1xsxlrwmvkn7l7tvhhhbfk6n` FOREIGN KEY (`category_parent`) REFERENCES `category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `chatting` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `created_date` datetime(6) DEFAULT NULL,
  `type` enum('STAFF','USER') DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9tb33e2hjail6s43sc004tg8c` (`user_id`),
  CONSTRAINT `FK9tb33e2hjail6s43sc004tg8c` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `cloud_key` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `api_key` varchar(255) DEFAULT NULL,
  `api_secret` varchar(255) DEFAULT NULL,
  `cloud_name` varchar(255) DEFAULT NULL,
  `created_date` datetime(6) DEFAULT NULL,
  `is_primary` bit(1) DEFAULT NULL,
  `gmail` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `color` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `contact` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `created_date` datetime(6) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `discount_product` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` datetime(6) DEFAULT NULL,
  `discount_product_type` enum('FIXED','PERCENT') DEFAULT NULL,
  `discount_value` double DEFAULT NULL,
  `end_date` datetime(6) DEFAULT NULL,
  `max_discount_value` double DEFAULT NULL,
  `start_date` datetime(6) DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKi9j126a6ufxbtntwm4xkr7xlh` (`product_id`),
  KEY `FKmvy3dc5qp9693j2u76qltlphe` (`user_id`),
  CONSTRAINT `FKi9j126a6ufxbtntwm4xkr7xlh` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FKmvy3dc5qp9693j2u76qltlphe` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `history_invoice_status` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `created_date` datetime(6) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `invoice_id` bigint DEFAULT NULL,
  `invoice_status` enum('DANG_CHO_VAN_CHUYEN','DA_DOI_HANG','DA_HUY','DA_VAN_CHUYEN','HOAN_THANH','KHONG_NHAN_DUOC_HANG','TRA_VE','YEU_CAU_DOI_HANG') DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7apv8t606rwsilnfpr386llqk` (`invoice_id`),
  CONSTRAINT `FK7apv8t606rwsilnfpr386llqk` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `history_pay` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` date DEFAULT NULL,
  `created_time` time(6) DEFAULT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `request_id` varchar(255) DEFAULT NULL,
  `total_amount` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `invoice` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `address_detail` varchar(255) DEFAULT NULL,
  `created_date` datetime(6) DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `ship_cost` double DEFAULT NULL,
  `total_amount` double DEFAULT NULL,
  `update_date` datetime(6) DEFAULT NULL,
  `ward_code` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `pay_type` enum('COD','MOMO','VNPAY') DEFAULT NULL,
  `province_code` varchar(255) DEFAULT NULL,
  `province_name` varchar(255) DEFAULT NULL,
  `tracking_code` varchar(255) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `ward_name` varchar(255) DEFAULT NULL,
  `weight` float DEFAULT NULL,
  `voucher_code` varchar(255) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `invoice_status` enum('DANG_CHO_VAN_CHUYEN','DA_DOI_HANG','DA_HUY','DA_VAN_CHUYEN','HOAN_THANH','KHONG_NHAN_DUOC_HANG','TRA_VE','YEU_CAU_DOI_HANG') DEFAULT NULL,
  `invoice_type` enum('ONLINE','TAI_QUAY','FACEBOOK') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `completed_date` datetime(6) DEFAULT NULL,
  `district_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `invoice_detail` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `id_invoice` bigint DEFAULT NULL,
  `id_product_detail` bigint DEFAULT NULL,
  `price` double DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `color_name` varchar(255) DEFAULT NULL,
  `product_image` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `size_name` varchar(255) DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `legacy_sku` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `key_telegram` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `active` bit(1) DEFAULT NULL,
  `chat_id` bigint DEFAULT NULL,
  `created_date` datetime(6) DEFAULT NULL,
  `group_name` varchar(255) DEFAULT NULL,
  `key_active` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `order_detail_draft` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `color_name` varchar(255) DEFAULT NULL,
  `id_product_detail` bigint DEFAULT NULL,
  `price` double DEFAULT NULL,
  `product_image` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `size_name` varchar(255) DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `order_draft_id` bigint DEFAULT NULL,
  `weight` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1koigceex111hcfsfyecx3jd6` (`order_draft_id`),
  CONSTRAINT `FK1koigceex111hcfsfyecx3jd6` FOREIGN KEY (`order_draft_id`) REFERENCES `order_draft` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `order_draft` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `address_detail` varchar(255) DEFAULT NULL,
  `created_date` datetime(6) DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `province_code` varchar(255) DEFAULT NULL,
  `province_name` varchar(255) DEFAULT NULL,
  `ship_cost` double DEFAULT NULL,
  `total_amount` double DEFAULT NULL,
  `update_date` datetime(6) DEFAULT NULL,
  `voucher_code` varchar(255) DEFAULT NULL,
  `ward_code` varchar(255) DEFAULT NULL,
  `ward_name` varchar(255) DEFAULT NULL,
  `created_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKgj3np37929dj2hbx42ysise47` (`created_by_id`),
  CONSTRAINT `FKgj3np37929dj2hbx42ysise47` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `otp_codes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `expiry_time` datetime(6) NOT NULL,
  `used` bit(1) NOT NULL,
  `local_date_time` datetime(6) DEFAULT NULL,
  `otp_type` enum('REGISTER_OTP','RESET_PASS') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `parent_category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` datetime(6) DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `update_date` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `product` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `active` bit(1) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) DEFAULT NULL,
  `meta_description` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `short_description` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `ole_price` double DEFAULT NULL,
  `sold` bigint DEFAULT NULL,
  `weight` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `product_category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `category_id` bigint DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKkud35ls1d40wpjb5htpp14q4e` (`category_id`),
  KEY `FK2k3smhbruedlcrvu6clued06x` (`product_id`),
  CONSTRAINT `FK2k3smhbruedlcrvu6clued06x` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FKkud35ls1d40wpjb5htpp14q4e` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=384 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `product_color_image` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `color_id` bigint DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `product_detail` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `active` bit(1) DEFAULT NULL,
  `color_id` bigint DEFAULT NULL,
  `old_price` double DEFAULT NULL,
  `price` double DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  `size_id` bigint DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `stock` int DEFAULT NULL,
  `color` bigint DEFAULT NULL,
  `size` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKt0bufofieb9x0kkqksxne62x` (`color`),
  KEY `FKaaygyla1v780j4xvyj225h0ar` (`size`),
  CONSTRAINT `FKaaygyla1v780j4xvyj225h0ar` FOREIGN KEY (`size`) REFERENCES `size` (`id`),
  CONSTRAINT `FKt0bufofieb9x0kkqksxne62x` FOREIGN KEY (`color`) REFERENCES `color` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=427 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Prepare the alias column before importing variants into an existing schema.
SET @ddl = IF(EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='product_detail' AND column_name='legacy_sku'), 'SELECT 1', 'ALTER TABLE product_detail ADD COLUMN legacy_sku VARCHAR(255) NULL');
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `product_image` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `link_image` varchar(255) DEFAULT NULL,
  `product_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6oo0cvcdtb6qmwsga468uuukk` (`product_id`),
  CONSTRAINT `FK6oo0cvcdtb6qmwsga468uuukk` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=170 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `product_view_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `last_viewed_at` datetime(6) DEFAULT NULL,
  `product_id` bigint NOT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `view_count` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pvh_user` (`user_id`),
  KEY `idx_pvh_product` (`product_id`),
  KEY `idx_pvh_session` (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `province` (
  `code` varchar(255) NOT NULL,
  `administrative_level` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `shopee_key` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `key_token` varchar(255) DEFAULT NULL,
  `local_date_time` datetime(6) DEFAULT NULL,
  `shop_name` varchar(255) DEFAULT NULL,
  `updated_date` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `size` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `actived` bit(1) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created_date` datetime(6) DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `remember_key` varchar(255) DEFAULT NULL,
  `role` enum('ROLE_ADMIN','ROLE_EMPLOYEE','ROLE_USER') DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `is_google_user` bit(1) DEFAULT NULL,
  `activation_status` bit(1) DEFAULT NULL,
  `account_non_locked` bit(1) NOT NULL,
  `failed_attempts` int NOT NULL,
  `lock_time` datetime(6) DEFAULT NULL,
  `user_type` enum('FACEBOOK','GOOGLE','NORMAL') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `voucher` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `block` bit(1) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `created_date` datetime(6) DEFAULT NULL,
  `discount` int DEFAULT NULL,
  `min_amount` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `update_date` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `wards` (
  `code` varchar(255) NOT NULL,
  `administrative_level` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `province_code` varchar(255) DEFAULT NULL,
  `province_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


SET FOREIGN_KEY_CHECKS=0;
START TRANSACTION;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

INSERT  IGNORE INTO `users` VALUES (1,0x01,NULL,'2025-09-01 16:07:00.000000',0x00,'admin@gmail.com','ADMIN','$2a$10$.VIihhdGDaZOJY9xzjwzVeepgVxwx2EkZaoMrCVoWtBIbltUJouWa',NULL,NULL,'ROLE_ADMIN',NULL,0x00,0x01,0x01,0,NULL,'NORMAL'),(14,0x01,'','2026-03-10 22:10:58.567557',0x00,'nhanvien@gmail.com','Nhân viên A','$2a$10$YmbYHGDaUhv.nVWlodmrMOQJu72zhYJF1oZiWnkB4nGf1rvPtbd9W','0976123123',NULL,'ROLE_EMPLOYEE',NULL,0x00,0x01,0x01,0,NULL,'NORMAL'),(20,0x01,'HN','2026-05-16 16:07:28.688315',0x00,'employee@gmail.com','Nguyễn Đức Anh','$2a$10$FqMC3trlFszp2MfsfYw8FeLnZx8kt7LL1zn0iSoOq/8d4fcA/o/k6','0962092970',NULL,'ROLE_EMPLOYEE',NULL,0x00,0x01,0x01,0,NULL,'NORMAL');
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

INSERT  IGNORE INTO `parent_category` VALUES (1,'2025-08-31 21:27:35.293191',0x00,'Đồ nam','do-nam','2025-08-31 21:27:35.309184'),(2,'2025-08-31 21:27:46.886944',0x00,'Đồ nữ','do-nu','2025-08-31 21:27:46.887944'),(3,'2025-08-31 21:28:58.692201',0x00,'Unisex','unisex','2025-08-31 21:28:58.692200'),(4,'2025-08-31 21:29:17.841603',0x00,'Combo','combo','2025-08-31 21:29:17.842601');
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

INSERT  IGNORE INTO `category` VALUES (1,NULL,0x00,NULL,'ADIDAS','adidas','2026-03-12 11:09:37.723175',NULL,0x00,8,NULL,''),(2,NULL,0x00,NULL,'WIKA','wika','2026-03-12 11:11:11.337657',NULL,0x00,9,NULL,''),(5,NULL,0x00,NULL,'ZOCKER','zocker','2026-03-12 11:11:35.269773',NULL,0x00,9,NULL,''),(6,'2025-07-14 15:24:47.431286',0x00,NULL,'Giầy Futsal','giay-futsal','2026-03-12 11:05:47.696090',NULL,0x01,NULL,3,''),(8,'2025-08-31 21:56:37.079508',0x00,NULL,'Giầy cỏ tự nhiên','giay-co-tu-nhien','2026-03-12 11:04:50.081691',NULL,0x01,NULL,1,''),(9,'2025-08-31 22:08:55.475160',0x00,NULL,'Giầy cỏ nhân tạo','giay-co-nhan-tao','2026-03-12 11:05:10.895653',NULL,0x01,NULL,2,''),(10,'2025-08-31 22:09:14.100192',0x00,NULL,'Adidas F50 Messi ','adidas-f50-messi-','2026-05-10 17:48:09.071607',NULL,0x00,13,2,''),(11,'2025-08-31 22:14:19.952263',0x00,NULL,'NIKE','nike','2026-03-12 11:12:45.965457',NULL,0x00,8,NULL,''),(12,'2025-08-31 22:14:31.938002',0x00,NULL,'JOMA','joma','2026-03-12 11:12:04.353010',NULL,0x00,6,NULL,''),(13,'2025-08-31 22:42:45.646524',0x00,NULL,'Hàng mới về','hang-moi-ve','2025-09-03 11:56:14.010156',NULL,0x01,NULL,5,NULL),(14,'2025-08-31 22:44:24.999063',0x00,NULL,'MIDUNO','miduno','2026-03-12 11:10:22.904835',NULL,0x00,8,NULL,''),(19,'2026-05-10 17:48:40.072260',0x00,NULL,'Nike Zoom Mercurial','nike-zoom-mercurial','2026-05-10 17:48:40.090225',NULL,0x00,13,1,'');
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

INSERT  IGNORE INTO `color` VALUES (1,'#111ed4','Xanh biển',0x00),(2,'#ffffff','Trắng',0x00),(3,'#000000','Đen',0x00),(4,'#6e5247','Nâu',0x00),(5,'#3d4846','Xanh than',0x00),(6,'#7ea19d','Xanh ngọc',0x00),(8,'#bfbfbf','Xám',0x00),(9,'#fff308','Vàng',0x00),(10,'#F5F5DC','Be',0x00),(11,'#FFC0CB','Hồng',0x00),(12,'#4B0082','Tím than',0x00),(13,'#ff0008','Đỏ',0x00),(14,'#00ff0d','Xanh lá',0x00),(15,'#ff7b00','Cam',0x00);
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

INSERT  IGNORE INTO `size` VALUES (5,'S',0x00),(6,'M',0x00),(7,'L',0x00),(8,'XL',0x00),(9,'XXL',0x00),(10,'28',0x00),(11,'29',0x00),(12,'30',0x00),(13,'31',0x00),(14,'32',0x00),(15,'33',0x00),(16,'34',0x00);
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

INSERT  IGNORE INTO `product` (`id`,`active`,`created_at`,`description`,`image`,`meta_description`,`meta_title`,`name`,`price`,`short_description`,`slug`,`updated_at`,`ole_price`,`sold`,`weight`) VALUES (31,0x01,'2026-03-14 22:07:23.018063','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1773500839/iypozhuuhadazdzfs8on.jpg','Tốc độ hơn với X30. Bám dính siêu tốt','ADIDAS X30','ADIDAS X30',200000,NULL,'adidas-x30','2026-05-16 19:52:53.697790',350000,2,0.5),(32,0x01,'2026-03-16 19:50:18.721817','<p>Trả g&oacute;p dễ d&agrave;ng c&ugrave;ng Fundiin &mdash; Đa dạng thương hiệu. Lu&ocirc;n cập nhật mẫu m&atilde; mới. Nhiều phụ kiện&nbsp;<em>b&oacute;ng đ&aacute;</em>&nbsp;ch&iacute;nh h&atilde;ng. Mua ngay. Gi&uacute;p bạn thỏa m&atilde;n đam m&ecirc; s&acirc;n cỏ c&ugrave;ng c&aacute;c sản phẩm&nbsp;<em>gi&agrave;y đ&aacute; b&oacute;ng</em>&nbsp;ch&iacute;nh h&atilde;ng chất lượng nhất.</p>','http://res.cloudinary.com/dt2g4oabz/image/upload/v1773665415/ot3adtsyjlk77akxlxiv.jpg','Bám sân tốt, không bong chóc. phù hợp đá sân cỏ tự nhiên, sân nhân tạo.','NIKE Donimo B40','NIKE Donimo B40',200000,NULL,'nike-donimo-b40','2026-03-16 19:50:18.733769',350000,0,0.5),(33,0x01,'2026-03-16 20:03:14.339387','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1773666190/xtfvoshavbluvonupwot.jpg','','NIKE Donimo B52','NIKE Donimo B52',200000,NULL,'nike-donimo-b52','2026-03-16 20:03:14.339386',350000,0,0.5),(35,0x01,'2026-03-16 20:06:14.676221','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1773666371/buvumiwj4imkwvivheh2.jpg','','JOMA 2025 X12','JOMA 2025 X12',500000,NULL,'joma-2025-x12','2026-03-16 20:06:14.676220',100000,0,0.5),(36,0x01,'2026-03-16 20:08:42.235171','<p>M&ugrave;a giải mới đang đến gần v&agrave; Nike đ&atilde; sẵn s&agrave;ng \"thổi b&ugrave;ng\" tinh thần thi đấu của c&aacute;c cầu thủ với bộ sưu tập&nbsp;<strong>\"Mad Ambition\" Pack</strong>&nbsp;đầy ấn tượng. Lấy cảm hứng từ kh&aacute;t vọng chinh phục m&atilde;nh liệt, Nike đ&atilde; kho&aacute;c&nbsp;l&ecirc;n những đ&ocirc;i gi&agrave;y đ&igrave;nh đ&aacute;m như Air Zoom Mercurial, Phantom v&agrave; Tiempo những m&agrave;u sắc xanh đầy sức sống, hứa hẹn mang đến trải nghiệm thi đấu đỉnh cao cho c&aacute;c ng&ocirc;i sao s&acirc;n cỏ.</p>\n<p>Mẫu gi&agrave;y được mệnh danh l&agrave; \"Best Seller\" của nh&agrave; Nike tại thị trường Việt Nam. Mỗi đợt ph&aacute;t h&agrave;nh lu&ocirc;n tạo n&ecirc;n sức h&uacute;t cực kỳ lớn.&nbsp;</p>','http://res.cloudinary.com/dt2g4oabz/image/upload/v1773666519/sbvl4pasli4iuv4r3rcd.png','','WIKA A20 Siêu Phẩm','WIKA A20 Siêu Phẩm',350000,NULL,'wika-a20-sieu-pham','2026-05-16 19:50:17.610133',500000,1,0.5),(37,0x01,'2026-03-16 21:33:40.083003','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1773671617/xodmpdzxmghggxak1bbj.jpg','','ADIDAS','ADIDAS',200000,NULL,'adidas','2026-05-16 19:50:17.614281',350000,1,0.5),(38,0x01,'2026-05-03 00:19:41.071423','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777742377/jnx0szkiaxitxkddkvvm.jpg','','Nemeziz','Nemeziz',1500000,NULL,'nemeziz','2026-05-03 00:19:41.072418',1950000,0,0.2),(39,0x01,'2026-05-03 00:20:54.496482','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777742449/wki3rhlavnenqfrx9auf.webp','','Predator Edge+ Firm Ground Boots HR1560','Predator Edge+ Firm Ground Boots HR1560',6300000,NULL,'predator-edge-firm-ground-boots-hr1560','2026-05-16 19:50:17.615279',7500000,1,0.26),(40,0x01,'2026-05-03 00:21:59.449898','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777742516/wc3ycue9jqcb6g71rluz.jpg','','X Speedportal.3 TF Beyond Fast Pack GW8486','X Speedportal.3 TF Beyond Fast Pack GW8486',1650000,NULL,'x-speedportal3-tf-beyond-fast-pack-gw8486','2026-05-16 19:50:17.616282',1950000,1,0.21),(41,0x01,'2026-05-03 00:24:38.067428','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777742672/yfh6f6pnvnc6aafigfyl.jpg','','Predator Freak.3 Low TF Superspectral FW7520','Predator Freak.3 Low TF Superspectral FW7520',1890000,NULL,'predator-freak3-low-tf-superspectral-fw7520','2026-05-03 00:24:38.067427',2500000,0,0.23),(42,0x01,'2026-05-03 00:26:22.831325','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777742779/gpx0eip5izoeo7v5j3gh.jpg','','X Ghosted.1 TF EG8175 Precision To Blur','X Ghosted.1 TF EG8175 Precision To Blur',2590000,NULL,'x-ghosted1-tf-eg8175-precision-to-blur','2026-05-03 00:26:22.831324',2900000,0,0.2),(43,0x01,'2026-05-03 00:36:48.305134','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777743405/f8lecqljjujxodj6nsil.jpg','Special Adidas','Firm Ground X Speedportal.1 GZ5108','Firm Ground X Speedportal.1 GZ5108',1900000,NULL,'firm-ground-x-speedportal1-gz5108','2026-05-16 20:31:13.111699',2500000,0,0.22),(44,0x01,'2026-05-03 00:47:17.361937','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777744033/bvijt4aim7cnsy0gym1b.jpg','','NIKE PHANTOM VENOM ACADEMY FG GAME OVER - BRIGHT CRIMSON/BLACK','NIKE PHANTOM VENOM ACADEMY FG GAME OVER - BRIGHT CRIMSON/BLACK',550000,NULL,'nike-phantom-venom-academy-fg-game-over-bright-crimsonblack','2026-05-03 00:47:17.370842',2495000,0,0.2),(45,0x01,'2026-05-03 00:51:22.418052','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777744279/zrcjn2rgnpxh8j9wqlef.jpg','','Nike Air Zoom Mercurial Vapor 16 Academy TF Shadow - Black/Deep Jungle FQ8449-002','Nike Air Zoom Mercurial Vapor 16 Academy TF Shadow - Black/Deep Jungle FQ8449-002',1990000,NULL,'nike-air-zoom-mercurial-vapor-16-academy-tf-shadow-blackdeep-jungle-fq8449-002','2026-05-03 00:51:22.418051',2600000,0,0.2),(46,0x01,'2026-05-03 00:52:37.671135','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777744354/i9pn2uenzhovnh7yzjzw.jpg','','Nike Air Zoom Mercurial Superfly 9 Academy TF Mbappé Personal Edition - Baltic Blue/White','Nike Air Zoom Mercurial Superfly 9 Academy TF Mbappé Personal Edition - Baltic Blue/White',1700000,NULL,'nike-air-zoom-mercurial-superfly-9-academy-tf-mbappe-personal-edition-baltic-bluewhite','2026-05-20 08:20:28.702867',3100000,1,0.26),(47,0x01,'2026-05-03 00:55:07.180165','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777744503/kv11fuc1fru0xqlpm8em.jpg','','Nike Air Zoom Mercurial Vapor 15 Academy TF Dream Speed 7 - Lite Crimson/Pale Ivory/Bright Mandarin','Nike Air Zoom Mercurial Vapor 15 Academy TF Dream Speed 7 - Lite Crimson/Pale Ivory/Bright Mandarin',1500000,NULL,'nike-air-zoom-mercurial-vapor-15-academy-tf-dream-speed-7-lite-crimsonpale-ivorybright-mandarin','2026-05-03 00:55:07.180164',2900000,0,0.2),(48,0x01,'2026-05-03 00:56:59.897504','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777744616/znapqxoadqm3wqcriccf.jpg','','Nike Air Zoom Mercurial Vapor 15 Academy TF XXV - Metallic Silver/Volt/Black','Nike Air Zoom Mercurial Vapor 15 Academy TF XXV - Metallic Silver/Volt/Black',1490000,NULL,'nike-air-zoom-mercurial-vapor-15-academy-tf-xxv-metallic-silvervoltblack','2026-05-03 00:56:59.899853',2699000,0,0.3),(49,0x01,'2026-05-03 01:00:06.597513','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777744803/ys5o168kmiq61pvafnij.jpg','','Nike Air Zoom Mercurial Vapor 16 Elite FG Mbappé Personal Edition - Grand Purple/Pale Ivory FQ8683-500','Nike Air Zoom Mercurial Vapor 16 Elite FG Mbappé Personal Edition - Grand Purple/Pale Ivory FQ8683-500',5790000,NULL,'nike-air-zoom-mercurial-vapor-16-elite-fg-mbappe-personal-edition-grand-purplepale-ivory-fq8683-500','2026-05-20 08:22:09.020144',7902000,1,0.22),(50,0x01,'2026-05-03 01:02:27.376115','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777744944/un0o0d37tnqbvtefuelv.jpg','','Nike Air Zoom Mercurial Vapor 16 Pro FG Attack - Racer Blue/White FQ8685-446','Nike Air Zoom Mercurial Vapor 16 Pro FG Attack - Racer Blue/White FQ8685-446',3690000,NULL,'nike-air-zoom-mercurial-vapor-16-pro-fg-attack-racer-bluewhite-fq8685-446','2026-05-03 01:02:27.376114',4490000,0,0.32),(51,0x01,'2026-05-04 21:07:29.642419','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777903647/wxnh6t4d0evabbrbumy8.jpg','','JOMA TOP FLEX REBOUND IN 2602 - TORS2602IN','JOMA TOP FLEX REBOUND IN 2602 - TORS2602IN',1790000,NULL,'joma-top-flex-rebound-in-2602-tors2602in','2026-05-04 21:07:29.649878',2000000,0,0.2),(52,0x01,'2026-05-04 21:11:07.354375','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777903866/azn75kein1tyvjx9zyob.jpg','','JOMA TOP FLEX REBOUND IN 2304','JOMA TOP FLEX REBOUND IN 2304',1550000,NULL,'joma-top-flex-rebound-in-2304','2026-05-04 21:11:07.358594',1750000,0,0.25),(53,0x01,'2026-05-04 21:12:35.346824','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777903954/obdcw9xsiybyix5delil.jpg','','JOMA TOP FLEX AMANDINHA IN 2572','JOMA TOP FLEX AMANDINHA IN 2572',1750000,NULL,'joma-top-flex-amandinha-in-2572','2026-05-04 21:12:35.347825',2000000,0,0.22),(54,0x01,'2026-05-04 21:13:29.740466','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777904009/hktfaxwgtj5unnlej5am.jpg','','JOMA TOP FLEX REBOUND IN HEXA 2552','JOMA TOP FLEX REBOUND IN HEXA 2552',1950000,NULL,'joma-top-flex-rebound-in-hexa-2552','2026-05-04 21:13:29.740465',2500000,0,0.26),(55,0x01,'2026-05-04 21:14:50.721976','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777904089/egxt5lttxkj5guwefpg3.jpg','','JOMA TOP FLEX IN 2428 ','JOMA TOP FLEX IN 2428 ',1000000,NULL,'joma-top-flex-in-2428-','2026-05-04 21:14:50.722976',1500000,0,0.22),(56,0x01,'2026-05-04 21:15:52.842028','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777904152/qv0tmdsmjxxciafpglnj.jpg','','JOMA REGATE REBOUND IN 2202','JOMA REGATE REBOUND IN 2202',1550000,NULL,'joma-regate-rebound-in-2202','2026-05-04 21:15:52.843027',1750000,0,0.22),(57,0x01,'2026-05-04 21:17:02.431878','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777904221/gg23i8mkmsevia1oqbwh.jpg','','JOMA TOP FLEX PLUS IN 2605 - TOUS2605IN','JOMA TOP FLEX PLUS IN 2605 - TOUS2605IN',1850000,NULL,'joma-top-flex-plus-in-2605-tous2605in','2026-05-04 21:17:02.432879',2000000,0,0.2),(58,0x01,'2026-05-04 21:39:04.502841','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777905543/z34gnnbadytmsfretnuc.png','','Mizuno Alpha III Elite FG Unity Sky- Blue/ White P1GA266225','Mizuno Alpha III Elite FG Unity Sky- Blue/ White P1GA266225',6200000,NULL,'mizuno-alpha-iii-elite-fg-unity-sky-blue-white-p1ga266225','2026-05-04 21:39:04.567330',7000000,0,0.3),(59,0x01,'2026-05-04 21:41:12.610294','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777905671/e5c4ikssilvw5q7laybj.png','','Mizuno Morelia Sala Club TF màu đen/ trắng Q1GB261631','Mizuno Morelia Sala Club TF màu đen/ trắng Q1GB261631',1650000,NULL,'mizuno-morelia-sala-club-tf-mau-den-trang-q1gb261631','2026-05-04 21:41:12.612293',1700000,0,0.31),(60,0x01,'2026-05-04 21:43:07.058224','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777905786/fmbt8wo6mucp3jngueac.png','','Mizuno Morelia Sala Japan TF Red Ruby màu đỏ Made In Japan Q1GB250260','Mizuno Morelia Sala Japan TF Red Ruby màu đỏ Made In Japan Q1GB250260',3750000,NULL,'mizuno-morelia-sala-japan-tf-red-ruby-mau-do-made-in-japan-q1gb250260','2026-05-04 21:43:07.059226',4300000,0,0.24),(61,0x01,'2026-05-04 21:46:06.015432','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777905965/kzmjvlvnvukhujeroehb.png','','Mizuno Morelia Neo IV Pro TF White/ Gold P1GD263550','Mizuno Morelia Neo IV Pro TF White/ Gold P1GD263550',2720000,NULL,'mizuno-morelia-neo-iv-pro-tf-white-gold-p1gd263550','2026-05-04 21:46:06.019866',2800000,0,0.23),(62,0x01,'2026-05-04 21:48:29.997131','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777906109/stzxk0xyfdz7ylmj3atd.png','','Mizuno Alpha Elite AS TF màu xanh biển – Mugen pack – P1GD246227','Mizuno Alpha Elite AS TF màu xanh biển – Mugen pack – P1GD246227',2850000,NULL,'mizuno-alpha-elite-as-tf-mau-xanh-bien-mugen-pack-p1gd246227','2026-05-04 21:48:29.999620',4300000,0,0.22),(63,0x01,'2026-05-04 21:49:47.181685','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777906186/pwvokditzlrsjly1orbm.png','','Mizuno Alpha III Select AS TF- trắng/ hồng P1GD266564','Mizuno Alpha III Select AS TF- trắng/ hồng P1GD266564',1800000,NULL,'mizuno-alpha-iii-select-as-tf-trang-hong-p1gd266564','2026-05-04 21:49:47.182733',2500000,0,0.26),(64,0x01,'2026-05-04 21:51:40.836101','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777906300/gqr8hnq6bbqojqsjmtvk.png','','Mizuno Alpha II Elite TF Frontier Pack trắng bạc P1GD256209','Mizuno Alpha II Elite TF Frontier Pack trắng bạc P1GD256209',3300000,NULL,'mizuno-alpha-ii-elite-tf-frontier-pack-trang-bac-p1gd256209','2026-05-04 21:51:40.837103',4500000,0,0.21),(65,0x01,'2026-05-04 21:55:14.935947','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777906514/pgiu2apn7d97xpleztyw.webp','','Zocker Inspire PRO Xanh Ngọc','Zocker Inspire PRO Xanh Ngọc',729000,NULL,'zocker-inspire-pro-xanh-ngoc','2026-05-04 21:55:14.940722',1200000,0,0.2),(66,0x01,'2026-05-04 21:56:24.323404','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777906583/r5z21qrodhbqkgdi7m8k.webp','','Zocker Inspire Pro Gen 2 Đen','Zocker Inspire Pro Gen 2 Đen',759000,NULL,'zocker-inspire-pro-gen-2-den','2026-05-04 21:56:24.323403',1500000,0,0.22),(67,0x01,'2026-05-04 21:57:51.496797','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777906670/vqxblbv1t9ubvbmtmuk5.webp','','Zocker Pioneer Trắng','Zocker Pioneer Trắng',1390000,NULL,'zocker-pioneer-trang','2026-05-04 21:57:51.502833',1500000,0,0.23),(68,0x01,'2026-05-04 21:59:09.598905','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777906748/lxnq9pnmzrfmk4afh3cu.webp','','Zocker Inspire Pro Gen 2 Tím','Zocker Inspire Pro Gen 2 Tím',759000,NULL,'zocker-inspire-pro-gen-2-tim','2026-05-04 21:59:09.599904',1299000,0,0.2),(69,0x01,'2026-05-04 22:00:08.863241','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777906808/qvxz1qe10vtfr1jyfrjx.webp','','Zocker Inspire Pro Gen 2 Cam','Zocker Inspire Pro Gen 2 Cam',759000,NULL,'zocker-inspire-pro-gen-2-cam','2026-05-04 22:00:08.863240',1000000,0,0.2),(70,0x01,'2026-05-04 22:02:47.271930','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777906966/oyossxyxffvniwgiku1n.webp','','Zocker Winner Energy - Đỏ','Zocker Winner Energy - Đỏ',659000,NULL,'zocker-winner-energy-do','2026-05-04 22:02:47.273928',750000,0,0.22),(71,0x01,'2026-05-04 22:03:58.363128','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777907037/zkmm4bxcyjepsltynj7t.webp','','Zocker Inspire PRO Rose Red/Green','Zocker Inspire PRO Rose Red/Green',729000,NULL,'zocker-inspire-pro-rose-redgreen','2026-05-16 19:52:53.702000',799000,2,0.23),(72,0x01,'2026-05-04 22:07:00.445520','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777907219/zlzgp8yglrt9ubaxa3li.jpg','','Wika Thunder màu navy','Wika Thunder màu navy',599000,NULL,'wika-thunder-mau-navy','2026-05-16 19:52:53.701000',529000,2,0.2),(73,0x01,'2026-05-04 22:08:30.138449','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777907309/ubuayhepxtm27l2bwr6h.jpg','','Wika Thunder màu trắng','Wika Thunder màu trắng',529000,NULL,'wika-thunder-mau-trang','2026-05-04 22:08:30.139110',599000,0,0.26),(74,0x01,'2026-05-04 22:09:46.082292','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777907385/agatxepbpybakjlty7il.jpg','','Wika Galaxy Light xanh ngọc','Wika Galaxy Light xanh ngọc',499000,NULL,'wika-galaxy-light-xanh-ngoc','2026-05-10 18:06:30.040602',699000,0,0.22),(75,0x01,'2026-05-04 22:10:50.819694','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777907450/s9uwm4hol4k2jwbxaeh3.jpg','','Wika HĐ14 Hoàng Đức hồng','Wika HĐ14 Hoàng Đức hồng',499000,NULL,'wika-hd14-hoang-duc-hong','2026-05-04 22:10:50.821557',510000,0,0.22),(76,0x01,'2026-05-04 22:11:50.475078','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777907509/cft3kopomgmrn01qzzj0.jpg','','Wika HĐ14 Hoàng Đức navy','Wika HĐ14 Hoàng Đức navy',499000,NULL,'wika-hd14-hoang-duc-navy','2026-05-04 22:11:50.477594',510000,0,0.22),(77,0x01,'2026-05-04 22:15:14.028037','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777907713/fy1vibn0mcynscg6ahsw.jpg','','Wika Blade đỏ vàng','Wika Blade đỏ vàng',499000,NULL,'wika-blade-do-vang','2026-05-04 22:15:14.030078',600000,0,0.22),(78,0x01,'2026-05-04 22:17:25.359120','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777907844/frsqwrxfvhlakutyfts5.jpg','','Wika Galaxy Light navy','Wika Galaxy Light navy',499000,NULL,'wika-galaxy-light-navy','2026-05-04 22:17:25.363015',699000,0,0.22),(79,0x01,'2026-05-04 22:18:26.582616','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777907905/ghzrl0el6atvj5wjhgc2.jpg','','Wika Galaxy Light bạc','Wika Galaxy Light bạc',499000,NULL,'wika-galaxy-light-bac','2026-05-04 22:18:26.582615',700000,0,0.22),(80,0x01,'2026-05-10 00:46:44.864915','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1778348803/flff5fwqvp7pp9qui2wz.png','','Adidas F50 Elite Messi FG','Adidas F50 Elite Messi FG',5900000,NULL,'adidas-f50-elite-messi-fg','2026-05-10 00:46:44.951811',7500000,0,0.22),(81,0x01,'2026-05-10 00:55:39.019996','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1778349338/whayhebyjul7vtghq6cs.webp','','Nike Zoom Mercurial Superfly 10 Elite FG \'Mad Energy Pack\'','Nike Zoom Mercurial Superfly 10 Elite FG \'Mad Energy Pack\'',9500000,NULL,'nike-zoom-mercurial-superfly-10-elite-fg-mad-energy-pack','2026-05-16 19:52:53.700001',10000000,2,0.2);
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

INSERT  IGNORE INTO `product_category` VALUES (257,11,32),(258,11,33),(276,6,35),(277,13,35),(278,12,35),(279,13,80),(280,10,80),(284,9,78),(285,2,78),(286,9,77),(287,2,77),(288,9,76),(289,2,76),(290,9,79),(291,2,79),(292,9,75),(293,2,75),(294,9,74),(295,2,74),(296,9,73),(297,2,73),(298,9,72),(299,2,72),(300,9,71),(301,5,71),(302,9,70),(303,5,70),(304,9,69),(305,5,69),(306,9,68),(307,5,68),(308,9,67),(309,5,67),(310,9,66),(311,5,66),(312,9,65),(313,5,65),(314,8,64),(315,14,64),(316,8,63),(317,14,63),(318,8,62),(319,14,62),(320,8,61),(321,14,61),(322,8,60),(323,14,60),(324,8,59),(325,14,59),(326,8,58),(327,14,58),(328,6,57),(329,12,57),(330,6,56),(331,12,56),(332,6,55),(333,12,55),(334,6,54),(335,12,54),(336,6,53),(337,12,53),(338,6,52),(339,12,52),(340,6,51),(341,12,51),(342,8,50),(343,11,50),(346,8,48),(347,11,48),(348,8,47),(349,11,47),(350,8,46),(351,11,46),(354,8,45),(355,11,45),(356,8,44),(357,11,44),(360,8,42),(361,1,42),(362,8,41),(363,1,41),(364,8,40),(365,1,40),(366,8,39),(367,1,39),(368,8,38),(369,1,38),(370,13,37),(371,1,37),(372,8,31),(373,13,31),(374,1,31),(375,13,81),(376,11,81),(377,19,81),(378,6,36),(379,2,36),(380,8,49),(381,11,49),(382,8,43),(383,1,43);
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

INSERT  IGNORE INTO `product_detail` (`id`,`active`,`color_id`,`old_price`,`price`,`product_id`,`size_id`,`legacy_sku`,`stock`,`color`,`size`) VALUES (239,0x01,2,400000,200000,31,11,'AX-29-TRANG',19,2,11),(240,0x01,2,400000,200000,31,12,'AX-30-TRANG',20,2,12),(241,0x01,2,400000,200000,31,13,'AX-31-TRANG',20,2,13),(242,0x01,2,400000,200000,31,14,'AX-32-TRANG',20,2,14),(243,0x01,9,400000,200000,31,13,'AX-31-VANG',18,9,13),(244,0x01,9,400000,200000,31,12,'AX-30-VANG',20,9,12),(245,0x01,9,400000,200000,31,12,'AX-30-VANG',20,9,12),(246,0x01,1,350000,200000,32,11,'NDB-29-XANHBIEN',10,1,11),(247,0x01,1,350000,200000,32,12,'NDB-30-XANHBIEN',10,1,12),(248,0x01,1,350000,200000,32,13,'NDB-31-XANHBIEN',10,1,13),(249,0x01,1,350000,200000,32,14,'NDB-32-XANHBIEN',10,1,14),(250,0x01,9,350000,200000,32,11,'NDB-29-VANG',10,9,11),(251,0x01,9,350000,200000,32,12,'NDB-30-VANG',10,9,12),(252,0x01,9,350000,200000,32,13,'NDB-31-VANG',10,9,13),(253,0x01,9,350000,200000,32,14,'NDB-32-VANG',10,9,14),(254,0x01,5,350000,200000,33,11,'NDB-29-XANHTHAN',50,5,11),(255,0x01,5,350000,200000,33,12,'NDB-30-XANHTHAN',50,5,12),(256,0x01,5,350000,200000,33,13,'NDB-31-XANHTHAN',50,5,13),(257,0x01,5,350000,200000,33,14,'NDB-32-XANHTHAN',50,5,14),(270,0x01,2,100000,500000,35,10,'J2025X-28-TRANG',100,2,10),(271,0x01,2,100000,500000,35,11,'J2025X-29-TRANG',100,2,11),(272,0x01,2,100000,500000,35,12,'J2025X-30-TRANG',100,2,12),(273,0x01,2,100000,500000,35,13,'J2025X-31-TRANG',100,2,13),(274,0x01,5,100000,500000,35,10,'J2025X-28-XANHTHAN',100,5,10),(275,0x01,5,100000,500000,35,11,'J2025X-29-XANHTHAN',100,5,11),(276,0x01,5,100000,500000,35,12,'J2025X-30-XANHTHAN',100,5,12),(277,0x01,5,100000,500000,35,13,'J2025X-31-XANHTHAN',100,5,13),(278,0x01,6,100000,500000,35,10,'J2025X-28-XANHNGOC',100,6,10),(279,0x01,6,100000,500000,35,11,'J2025X-29-XANHNGOC',100,6,11),(280,0x01,6,100000,500000,35,12,'J2025X-30-XANHNGOC',100,6,12),(281,0x01,6,100000,500000,35,13,'J2025X-31-XANHNGOC',100,6,13),(282,0x01,6,500000,350000,36,11,'WASP-29-XANHNGOC',99,6,11),(283,0x01,6,500000,350000,36,12,'WASP-30-XANHNGOC',100,6,12),(284,0x01,6,500000,350000,36,13,'WASP-31-XANHNGOC',97,6,13),(285,0x01,6,500000,350000,36,14,'WASP-32-XANHNGOC',100,6,14),(286,0x01,1,350000,200000,37,11,'A-29-XANHBIEN',10,1,11),(287,0x01,1,350000,200000,37,12,'A-30-XANHBIEN',10,1,12),(288,0x01,1,350000,200000,37,13,'A-31-XANHBIEN',10,1,13),(289,0x01,2,350000,200000,37,11,'A-29-TRANG',10,2,11),(290,0x01,2,350000,200000,37,12,'A-30-TRANG',10,2,12),(291,0x01,2,350000,200000,37,13,'A-31-TRANG',10,2,13),(292,0x01,3,350000,200000,37,11,'A-29-EN',9,3,11),(293,0x01,3,350000,200000,37,12,'A-30-EN',10,3,12),(294,0x01,3,350000,200000,37,13,'A-31-EN',10,3,13),(295,0x01,13,NULL,9500000,81,7,'NZMS10EF\'EP-L-O',6,13,7),(296,0x01,2,NULL,5900000,80,7,'AFEMF-L-TRANG',10,2,7),(297,0x01,2,NULL,499000,79,6,'WGLB-M-TRANG',10,2,6),(298,0x01,2,NULL,499000,79,7,'WGLB-L-TRANG',10,2,7),(299,0x01,2,NULL,499000,79,8,'WGLB-XL-TRANG',10,2,8),(300,0x01,5,NULL,499000,78,6,'WGLN-M-XANHTHAN',10,5,6),(301,0x01,5,NULL,499000,78,7,'WGLN-L-XANHTHAN',10,5,7),(302,0x01,5,NULL,499000,78,8,'WGLN-XL-XANHTHAN',10,5,8),(303,0x01,13,NULL,499000,77,6,'WBĐV-M-O',10,13,6),(304,0x01,13,NULL,499000,77,7,'WBĐV-L-O',10,13,7),(305,0x01,13,NULL,499000,77,8,'WBĐV-XL-O',10,13,8),(306,0x01,13,NULL,499000,77,9,'WBĐV-XXL-O',10,13,9),(307,0x01,1,NULL,499000,76,6,'WHHĐN-M-XANHBIEN',10,1,6),(308,0x01,1,NULL,499000,76,7,'WHHĐN-L-XANHBIEN',10,1,7),(309,0x01,1,NULL,499000,76,8,'WHHĐN-XL-XANHBIEN',10,1,8),(310,0x01,11,NULL,499000,75,6,'WHHĐH-M-HONG',10,11,6),(311,0x01,11,NULL,499000,75,7,'WHHĐH-L-HONG',10,11,7),(312,0x01,11,NULL,499000,75,8,'WHHĐH-XL-HONG',10,11,8),(313,0x01,6,NULL,499000,74,6,'WGLXN-M-XANHNGOC',10,6,6),(314,0x01,6,NULL,499000,74,7,'WGLXN-L-XANHNGOC',10,6,7),(315,0x01,6,NULL,499000,74,8,'WGLXN-XL-XANHNGOC',10,6,8),(316,0x01,2,NULL,529000,73,6,'WTMT-M-TRANG',10,2,6),(317,0x01,2,NULL,529000,73,7,'WTMT-L-TRANG',10,2,7),(318,0x01,2,NULL,529000,73,8,'WTMT-XL-TRANG',10,2,8),(319,0x01,5,NULL,599000,72,5,'WTMN-S-XANHTHAN',8,5,5),(320,0x01,5,NULL,599000,72,6,'WTMN-M-XANHTHAN',10,5,6),(321,0x01,5,NULL,599000,72,7,'WTMN-L-XANHTHAN',10,5,7),(322,0x01,5,NULL,599000,72,8,'WTMN-XL-XANHTHAN',10,5,8),(323,0x01,11,NULL,729000,71,6,'ZIPRR-M-HONG',8,11,6),(324,0x01,11,NULL,729000,71,7,'ZIPRR-L-HONG',10,11,7),(325,0x01,11,NULL,729000,71,8,'ZIPRR-XL-HONG',10,11,8),(326,0x01,13,NULL,659000,70,6,'ZWE-Đ-M-O',10,13,6),(327,0x01,13,NULL,659000,70,7,'ZWE-Đ-L-O',10,13,7),(328,0x01,13,NULL,659000,70,8,'ZWE-Đ-XL-O',10,13,8),(329,0x01,15,NULL,759000,69,6,'ZIPG2C-M-CAM',10,15,6),(330,0x01,15,NULL,759000,69,7,'ZIPG2C-L-CAM',10,15,7),(331,0x01,15,NULL,759000,69,8,'ZIPG2C-XL-CAM',10,15,8),(332,0x01,12,NULL,759000,68,5,'ZIPG2T-S-TIMTHAN',10,12,5),(333,0x01,12,NULL,759000,68,6,'ZIPG2T-M-TIMTHAN',10,12,6),(334,0x01,12,NULL,759000,68,7,'ZIPG2T-L-TIMTHAN',10,12,7),(335,0x01,12,NULL,759000,68,8,'ZIPG2T-XL-TIMTHAN',10,12,8),(336,0x01,2,NULL,1390000,67,6,'ZPT-M-TRANG',10,2,6),(337,0x01,2,NULL,1390000,67,7,'ZPT-L-TRANG',10,2,7),(338,0x01,2,NULL,1390000,67,8,'ZPT-XL-TRANG',10,2,8),(339,0x01,3,NULL,759000,66,6,'ZIPG2Đ-M-EN',20,3,6),(340,0x01,3,NULL,759000,66,7,'ZIPG2Đ-L-EN',20,3,7),(341,0x01,3,NULL,759000,66,8,'ZIPG2Đ-XL-EN',20,3,8),(342,0x01,1,NULL,729000,65,5,'ZIPXN-S-XANHBIEN',10,1,5),(343,0x01,1,NULL,729000,65,6,'ZIPXN-M-XANHBIEN',10,1,6),(344,0x01,1,NULL,729000,65,7,'ZIPXN-L-XANHBIEN',10,1,7),(345,0x01,1,NULL,729000,65,8,'ZIPXN-XL-XANHBIEN',10,1,8),(346,0x01,8,NULL,3300000,64,6,'MAIETFPTBP-M-XAM',10,8,6),(347,0x01,8,NULL,3300000,64,7,'MAIETFPTBP-L-XAM',10,8,7),(348,0x01,8,NULL,3300000,64,8,'MAIETFPTBP-XL-XAM',10,8,8),(349,0x01,11,NULL,1800000,63,6,'MAISATTHP-M-HONG',10,11,6),(350,0x01,11,NULL,1800000,63,7,'MAISATTHP-L-HONG',10,11,7),(351,0x01,11,NULL,1800000,63,8,'MAISATTHP-XL-HONG',10,11,8),(352,0x01,1,NULL,2850000,62,6,'MAEATMXB–MP–P-M-XANHBIEN',10,1,6),(353,0x01,1,NULL,2850000,62,7,'MAEATMXB–MP–P-L-XANHBIEN',10,1,7),(354,0x01,1,NULL,2850000,62,8,'MAEATMXB–MP–P-XL-XANHBIEN',10,1,8),(355,0x01,2,NULL,2720000,61,6,'MMNIPTWGP-M-TRANG',10,2,6),(356,0x01,2,NULL,2720000,61,7,'MMNIPTWGP-L-TRANG',10,2,7),(357,0x01,2,NULL,2720000,61,8,'MMNIPTWGP-XL-TRANG',10,2,8),(358,0x01,13,NULL,3750000,60,6,'MMSJTRRMĐMIJQ-M-O',10,13,6),(359,0x01,13,NULL,3750000,60,7,'MMSJTRRMĐMIJQ-L-O',10,13,7),(360,0x01,13,NULL,3750000,60,8,'MMSJTRRMĐMIJQ-XL-O',10,13,8),(361,0x01,3,NULL,1650000,59,6,'MMSCTMĐTQ-M-EN',10,3,6),(362,0x01,3,NULL,1650000,59,7,'MMSCTMĐTQ-L-EN',10,3,7),(363,0x01,3,NULL,1650000,59,8,'MMSCTMĐTQ-XL-EN',10,3,8),(364,0x01,6,NULL,6200000,58,6,'MAIEFUSBWP-M-XANHNGOC',10,6,6),(365,0x01,6,NULL,6200000,58,7,'MAIEFUSBWP-L-XANHNGOC',10,6,7),(366,0x01,6,NULL,6200000,58,8,'MAIEFUSBWP-XL-XANHNGOC',10,6,8),(367,0x01,8,NULL,1850000,57,5,'JTFPI2605-T-S-XAM',10,8,5),(368,0x01,8,NULL,1850000,57,6,'JTFPI2605-T-M-XAM',10,8,6),(369,0x01,8,NULL,1850000,57,7,'JTFPI2605-T-L-XAM',10,8,7),(370,0x01,8,NULL,1850000,57,8,'JTFPI2605-T-XL-XAM',10,8,8),(371,0x01,2,NULL,1550000,56,6,'JRRI2202-M-TRANG',10,2,6),(372,0x01,2,NULL,1550000,56,7,'JRRI2202-L-TRANG',10,2,7),(373,0x01,9,NULL,1000000,55,5,'JTFI2428-S-VANG',10,9,5),(374,0x01,9,NULL,1000000,55,6,'JTFI2428-M-VANG',10,9,6),(375,0x01,9,NULL,1000000,55,7,'JTFI2428-L-VANG',10,9,7),(376,0x01,9,NULL,1000000,55,8,'JTFI2428-XL-VANG',10,9,8),(377,0x01,2,NULL,1950000,54,6,'JTFRIH2552-M-TRANG',10,2,6),(378,0x01,2,NULL,1950000,54,7,'JTFRIH2552-L-TRANG',10,2,7),(379,0x01,2,NULL,1950000,54,8,'JTFRIH2552-XL-TRANG',10,2,8),(380,0x01,2,NULL,1750000,53,6,'JTFAI2572-M-TRANG',10,2,6),(381,0x01,2,NULL,1750000,53,7,'JTFAI2572-L-TRANG',10,2,7),(382,0x01,2,NULL,1750000,53,8,'JTFAI2572-XL-TRANG',10,2,8),(383,0x01,1,NULL,1550000,52,6,'JTFRI2304-M-XANHBIEN',10,1,6),(384,0x01,1,NULL,1550000,52,7,'JTFRI2304-L-XANHBIEN',10,1,7),(385,0x01,1,NULL,1550000,52,8,'JTFRI2304-XL-XANHBIEN',10,1,8),(386,0x01,2,NULL,1790000,51,6,'JTFRI2602-T-M-TRANG',10,2,6),(387,0x01,2,NULL,1790000,51,7,'JTFRI2602-T-L-TRANG',10,2,7),(388,0x01,2,NULL,1790000,51,8,'JTFRI2602-T-XL-TRANG',10,2,8),(389,0x01,1,NULL,3690000,50,6,'NAZMV16PFA-RBF-M-XANHBIEN',10,1,6),(390,0x01,1,NULL,3690000,50,7,'NAZMV16PFA-RBF-L-XANHBIEN',10,1,7),(391,0x01,1,NULL,3690000,50,8,'NAZMV16PFA-RBF-XL-XANHBIEN',10,1,8),(392,0x01,12,NULL,5790000,49,7,'NAZMV16EFMPE-GPIF-L-TIMTHAN',10,12,7),(393,0x01,12,NULL,5790000,49,8,'NAZMV16EFMPE-GPIF-XL-TIMTHAN',9,12,8),(394,0x01,8,NULL,1490000,48,6,'NAZMV15ATX-MS-M-XAM',10,8,6),(395,0x01,8,NULL,1490000,48,7,'NAZMV15ATX-MS-L-XAM',10,8,7),(396,0x01,8,NULL,1490000,48,8,'NAZMV15ATX-MS-XL-XAM',10,8,8),(397,0x01,15,NULL,1500000,47,6,'NAZMV15ATDS7-LCIM-M-CAM',10,15,6),(398,0x01,15,NULL,1500000,47,7,'NAZMV15ATDS7-LCIM-L-CAM',10,15,7),(399,0x01,15,NULL,1500000,47,8,'NAZMV15ATDS7-LCIM-XL-CAM',10,15,8),(400,0x01,6,NULL,1700000,46,6,'NAZMS9ATMPE-BB-M-XANHNGOC',10,6,6),(401,0x01,6,NULL,1700000,46,7,'NAZMS9ATMPE-BB-L-XANHNGOC',6,6,7),(402,0x01,6,NULL,1700000,46,8,'NAZMS9ATMPE-BB-XL-XANHNGOC',10,6,8),(403,0x01,3,NULL,NULL,45,6,'NAZMV16ATS-BJF-M-EN',10,3,6),(404,0x01,3,NULL,NULL,45,7,'NAZMV16ATS-BJF-L-EN',10,3,7),(405,0x01,3,NULL,NULL,45,8,'NAZMV16ATS-BJF-XL-EN',10,3,8),(406,0x01,13,NULL,550000,44,6,'NPVAFGO-BC-M-O',10,13,6),(407,0x01,13,NULL,550000,44,7,'NPVAFGO-BC-L-O',10,13,7),(408,0x01,13,NULL,550000,44,8,'NPVAFGO-BC-XL-O',10,13,8),(409,0x01,11,NULL,1900000,43,6,'FGXSG-M-HONG',10,11,6),(410,0x01,11,NULL,1900000,43,7,'FGXSG-L-HONG',4,11,7),(411,0x01,11,NULL,1900000,43,8,'FGXSG-XL-HONG',10,11,8),(412,0x01,14,NULL,2590000,42,6,'XGTEPTB-M-XANHLA',10,14,6),(413,0x01,14,NULL,2590000,42,7,'XGTEPTB-L-XANHLA',10,14,7),(414,0x01,14,NULL,2590000,42,8,'XGTEPTB-XL-XANHLA',10,14,8),(415,0x01,11,NULL,1890000,41,6,'PFLTSF-M-HONG',10,11,6),(416,0x01,11,NULL,1890000,41,7,'PFLTSF-L-HONG',10,11,7),(417,0x01,11,NULL,1890000,41,8,'PFLTSF-XL-HONG',10,11,8),(418,0x01,8,NULL,1650000,40,6,'XSTBFPG-M-XAM',9,8,6),(419,0x01,8,NULL,1650000,40,7,'XSTBFPG-L-XAM',10,8,7),(420,0x01,8,NULL,1650000,40,8,'XSTBFPG-XL-XAM',10,8,8),(421,0x01,8,NULL,6300000,39,6,'PEFGBH-M-XAM',9,8,6),(422,0x01,8,NULL,6300000,39,7,'PEFGBH-L-XAM',10,8,7),(423,0x01,8,NULL,6300000,39,8,'PEFGBH-XL-XAM',10,8,8),(424,0x01,1,NULL,1500000,38,6,'N-M-XANHBIEN',10,1,6),(425,0x01,1,NULL,1500000,38,7,'N-L-XANHBIEN',10,1,7),(426,0x01,1,NULL,1500000,38,8,'N-XL-XANHBIEN',10,1,8);
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

INSERT  IGNORE INTO `product_image` VALUES (143,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773500841/hfimgdjp1sln8br86m8n.jpg',31),(144,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773500841/bl18yj4vocokgdldn1al.jpg',31),(145,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773500842/yjx78ld35siigpohnvbb.jpg',31),(146,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773500842/updxfenhjk43ye0hxa4z.jpg',31),(147,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773665417/hk8i01cqtp2zxfqf1rcs.jpg',32),(148,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773665417/fuievwlcchylfzz2dqmy.jpg',32),(149,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773665418/kkyagw8mzgbbsyeau5ty.jpg',32),(150,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773665418/v9kdbith4atmuovek1yi.jpg',32),(151,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773666192/vhzwpzxminztnxxnwpbd.jpg',33),(152,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773666192/ztg9alskcthprylgwzup.jpg',33),(153,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773666192/zdp3zrvzkcuuumcveg7o.jpg',33),(154,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773666192/rz5pp0tb9kmh84raibzg.jpg',33),(158,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773666373/wpxcnkyqvfiifk1basc0.jpg',35),(159,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773666373/wz74ljtq0u0brhtyzq53.jpg',35),(160,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773666374/nc7bof4uafomnfjpspfb.jpg',35),(161,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773666520/hdupdz2ovkdflzkfkonn.jpg',36),(162,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773666520/s914ov6mocglsplgdsmm.jpg',36),(163,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773666521/dk6o9gq5al8ev8z6kd0b.jpg',36),(164,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773666521/btopwkmlpayrcnzsg3hm.jpg',36),(165,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773666521/pwr2op9j60gsij6rbjjn.jpg',36),(166,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773666521/eaqeewsl426hvk9hzl0s.jpg',36),(167,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773671619/qqevawyuntlmus2ksnyf.jpg',37),(168,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773671619/vghlpbt4cdnl7awhdvm0.jpg',37),(169,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1773671619/gqczpmjp6lns4enu9emw.jpg',37);
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

INSERT  IGNORE INTO `product_color_image` VALUES (1,2,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1756982282/wagooyhknohdmv74eg5h.jpg',21),(2,6,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1756981713/k4qcdthul6xvw8gcagrd.jpg',21),(3,10,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1756982136/xr0thttvqqc42fzdphqt.jpg',21),(4,12,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1756982232/qbpc4fb36ti08psabwq9.jpg',21),(5,3,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756698923/xrshcflfkjbvdwu6gele.jpg',20),(6,4,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756698923/xqokqit38tesinrgr9h6.jpg',20),(7,1,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756698670/yoyoa4rljiur0jfi2buw.jpg',19),(8,4,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756698670/lzmpldiztlbj6ija2is4.jpg',19),(9,12,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756698670/ppueonndmjp7jxlkjxal.jpg',19),(10,1,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756698029/igtzr3bnlrh0nxdy4yg7.jpg',18),(11,11,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756698029/cc854p7fj5kyrcyi7olz.jpg',18),(12,12,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756698029/eifxa7jysjykgnremczo.jpg',18),(13,3,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756697835/nwe7ekazrq6ka8x8olxa.jpg',17),(14,5,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756697835/wzitcnglr2q7efeufven.jpg',17),(15,8,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756697835/obbixjagbgrecawcfz5l.jpg',17),(16,2,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756697514/ge5qfgyuyashkexyeuyz.jpg',16),(17,5,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756697514/tusd6g7eebngkeir25yf.jpg',16),(18,11,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756697514/vc8v1vykwhpeql6n8ym2.jpg',16),(19,2,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756693373/yxdrlqpjypxhmuuu1k63.jpg',14),(20,1,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756693373/f23zrw0yjg21fprcrtqh.jpg',14),(21,6,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756693373/owrso3x2c5irf3oorykx.jpg',14),(22,1,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756693073/swnaklput6tfk9m9co4a.jpg',13),(23,10,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756692783/urcc3wtl20lcb3ld7odi.jpg',12),(24,8,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756692782/cs56kgvyza2egxaranx1.jpg',12),(25,4,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756692783/q9uxsddfcoyxsumtuux2.jpg',12),(26,1,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756692396/foa1uhqpldat9q9ahy36.jpg',11),(27,11,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756692396/hrleciluqixvsg5bfkvc.jpg',11),(28,2,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756690235/wszfysypkssghcee72rb.jpg',10),(29,6,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756690235/k1w4pzsdwnexcwo7oefx.jpg',10),(30,1,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756689436/wpnom7qcjqsczarq5mh9.jpg',9),(31,3,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756689436/pguixiiqzoesjff8xinz.jpg',9),(33,1,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756635264/kcao1x3vlzs0lkfgbghv.jpg',7),(34,2,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756635264/gqj2yxi1p0vr7jp2rrl3.jpg',7),(35,2,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756633808/voxosqkcxdu2cxi8v5oz.jpg',6),(36,5,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756633808/whq3dj1j3trwhpy4ne25.jpg',6),(37,4,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756633808/rkx77wdsjwhxwnuf6ddj.jpg',6),(38,1,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756632053/rxkmleihc6xgfo1ny1ut.jpg',5),(39,3,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756632053/bjdkyk2oxft2nvtabnsw.jpg',5),(40,5,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756632053/rxkmleihc6xgfo1ny1ut.jpg',5),(41,2,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1752921682/tgleuxnucsxvz9lglkbl.jpg',2),(42,4,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1752835321/nwwki8skyrjfselrdbwc.webp',2),(43,1,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1752835321/rkzuhmqjnxqtr1twbf5o.webp',2),(44,4,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756635727/ns4igmtgt38tqe9tddjm.jpg',8),(50,3,'http://res.cloudinary.com/dyhy5jhmp/image/upload/v1756635727/ywwji4twhohkaedgvsar.jpg',8),(51,2,NULL,22),(52,6,NULL,22),(53,12,NULL,22),(54,5,NULL,23),(55,11,NULL,23),(56,12,NULL,23),(57,1,NULL,24),(58,2,NULL,24),(59,1,NULL,25),(60,2,NULL,25),(61,5,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1757844888/ly5yw25n98yb9yxabym6.jpg',26),(62,11,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1757844888/w7dzovbzmg7spymvc1nw.jpg',26),(63,12,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1757844888/bvoxuokwe0tnusqcruhx.jpg',26),(64,2,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1758772778/opwrz1fmhncnyqg7m9bj.jpg',27),(65,3,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1758772778/fit0cdkzafnmjqyp2lkc.jpg',27),(66,4,'http://res.cloudinary.com/dt2g4oabz/image/upload/v1758772778/evdjpjrxphppdlb30kj2.jpg',27),(67,11,NULL,29),(68,11,NULL,30),(69,2,NULL,31),(70,9,NULL,31),(71,1,NULL,32),(72,9,NULL,32),(73,5,NULL,33),(74,2,NULL,34),(75,5,NULL,34),(76,6,NULL,34),(77,2,NULL,35),(78,5,NULL,35),(79,6,NULL,35),(80,6,NULL,36),(81,1,NULL,37),(82,2,NULL,37),(83,3,NULL,37),(84,13,NULL,81),(85,2,NULL,80),(86,2,NULL,79),(87,5,NULL,78),(88,13,NULL,77),(89,1,NULL,76),(90,11,NULL,75),(91,6,NULL,74),(92,2,NULL,73),(93,5,NULL,72),(94,11,NULL,71),(95,13,NULL,70),(96,15,NULL,69),(97,12,NULL,68),(98,2,NULL,67),(99,3,NULL,66),(100,1,NULL,65),(101,8,NULL,64),(102,11,NULL,63),(103,1,NULL,62),(104,2,NULL,61),(105,13,NULL,60),(106,3,NULL,59),(107,6,NULL,58),(108,8,NULL,57),(109,2,NULL,56),(110,9,NULL,55),(111,2,NULL,54),(112,2,NULL,53),(113,1,NULL,52),(114,2,NULL,51),(115,1,NULL,50),(116,12,NULL,49),(117,8,NULL,48),(118,15,NULL,47),(119,6,NULL,46),(120,3,NULL,45),(121,13,NULL,44),(122,11,NULL,43),(123,14,NULL,42),(124,11,NULL,41),(125,8,NULL,40),(126,8,NULL,39),(127,1,NULL,38);
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

INSERT  IGNORE INTO `blog` VALUES (1,'<blockquote>\r\n<h3>2.1. Đ&uacute;ng mặt s&acirc;n</h3>\r\n<p>Mặt s&acirc;n quyết định loại đinh gi&agrave;y. Chọn sai mặt s&acirc;n l&agrave; c&ocirc;ng thức &ldquo;chuẩn&rdquo; cho trơn trượt hoặc chấn thương:</p>\r\n<ul>\r\n<li><strong>TF</strong>: Đế đinh thấp, d&agrave;y &ndash; chuy&ecirc;n cho s&acirc;n cỏ nh&acirc;n tạo 5/7 người.</li>\r\n<li><strong>AG</strong>: Đế đinh cao hơn TF, chuy&ecirc;n cho cỏ nh&acirc;n tạo chuẩn, mật độ đinh tối ưu.</li>\r\n<li><strong>FG</strong>: Đinh d&agrave;i, thưa, d&ugrave;ng cho s&acirc;n cỏ tự nhi&ecirc;n kh&ocirc;, chắc.</li>\r\n<li><strong>SG</strong>: Đinh kim loại/nhựa d&agrave;i, d&ugrave;ng cho s&acirc;n cỏ tự nhi&ecirc;n mềm, trơn.</li>\r\n<li><strong>IC/Futsal</strong>: Đế bằng, d&ugrave;ng cho s&acirc;n trong nh&agrave;, xi măng, gỗ, futsal.</li>\r\n</ul>\r\n<p>Nếu chưa r&otilde; sự kh&aacute;c nhau, bạn c&oacute; thể đọc th&ecirc;m b&agrave;i tổng hợp về mặt s&acirc;n v&agrave; loại đinh:&nbsp;<a href=\"https://thegioibongda.net/cach-chon-giay-bong-da-phu-hop-voi-tung-mat-san-thi-dau-n59220.html\" target=\"_blank\" rel=\"noreferrer noopener\">C&aacute;ch chọn gi&agrave;y b&oacute;ng đ&aacute; ph&ugrave; hợp với từng mặt s&acirc;n thi đấu&nbsp;</a>.</p>\r\n<h3>2.2. Đ&uacute;ng form ch&acirc;n</h3>\r\n<p>Ch&acirc;n mỗi người kh&aacute;c nhau: c&oacute; anh em ch&acirc;n b&egrave;, c&oacute; người ch&acirc;n thon, mu d&agrave;y, mu mỏng. Một đ&ocirc;i gi&agrave;y &ldquo;hot&rdquo; chưa chắc đ&atilde; hợp với ch&acirc;n bạn. Đ&uacute;ng form ch&acirc;n sẽ gi&uacute;p:</p>\r\n<ul>\r\n<li>Giảm đau g&oacute;t, đau mu b&agrave;n ch&acirc;n, hạn chế phồng rộp.</li>\r\n<li>&Ocirc;m ch&acirc;n vừa đủ để bứt tốc, đổi hướng tự tin.</li>\r\n<li>Tăng cảm gi&aacute;c b&oacute;ng v&igrave; b&agrave;n ch&acirc;n kh&ocirc;ng bị &ldquo;bơi&rdquo; trong gi&agrave;y.</li>\r\n</ul>\r\n<h3>2.3. Đ&uacute;ng nhu cầu &amp; ng&acirc;n s&aacute;ch</h3>\r\n<p>Kh&ocirc;ng phải ai cũng cần đ&ocirc;i gi&agrave;y v&agrave;i triệu. Nếu bạn đ&aacute; 1&ndash;2 buổi/tuần, chơi phong tr&agrave;o, c&oacute; thể chọn ph&acirc;n kh&uacute;c vừa t&uacute;i tiền nhưng vẫn đảm bảo độ bền, độ &ocirc;m v&agrave; b&aacute;m s&acirc;n tốt. Ngược lại, nếu bạn đ&aacute; nhiều, tham gia giải, ghiền cảm gi&aacute;c b&oacute;ng thật, h&atilde;y đầu tư ph&acirc;n kh&uacute;c cao hơn &ndash; đ&ocirc;i gi&agrave;y sẽ &ldquo;trả lại&rdquo; bạn bằng trải nghiệm rất kh&aacute;c.</p>\r\n</blockquote>','2025-09-01 21:03:19.096135','Một đôi giày phù hợp không biến bạn thành cầu thủ chuyên nghiệp sau một đêm, nhưng chắc chắn giúp bạn chạy tự tin hơn, chạm bóng chắc hơn và giảm tối đa khó chịu ở chân','http://res.cloudinary.com/dt2g4oabz/image/upload/v1773384967/djrzjz1yme4wt51feyxg.jpg','Một đôi giày phù hợp không biến bạn thành cầu thủ chuyên nghiệp sau một đêm, nhưng chắc chắn giúp bạn chạy tự tin hơn, chạm bóng chắc hơn và giảm tối đa khó chịu ở chân',0,' Giới thiệu: Vì sao chọn giày đá bóng lại quan trọng?','-gioi-thieu-vi-sao-chon-giay-a-bong-lai-quan-trong',' Giới thiệu: Vì sao chọn giày đá bóng lại quan trọng?','2026-03-13 13:57:44.498660',NULL),(3,'<h2><span id=\"cau-chuyen\">2. C&acirc;u chuyện Messi v&agrave; F50 &ndash; Tốc độ c&oacute; kiểm so&aacute;t</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260226_Lv55c6jl.jpg\" alt=\"Adidas F50 Messi 3\" width=\"1000\" height=\"573\" />\r\n<figcaption>Adidas F50 Messi</figcaption>\r\n</figure>\r\n<p>Trong giai đoạn đỉnh cao sự nghiệp, Messi từng gắn b&oacute; với F50 v&agrave; tạo n&ecirc;n những m&ugrave;a giải b&ugrave;ng nổ. Nhưng điều đặc biệt l&agrave; Messi kh&ocirc;ng phải mẫu cầu thủ &ldquo;chạy thẳng v&agrave; bứt ph&aacute;&rdquo; thuần tốc độ.</p>\r\n<p>Phong c&aacute;ch của anh l&agrave; giữ b&oacute;ng s&aacute;t ch&acirc;n, r&ecirc; trong kh&ocirc;ng gian hẹp, tăng tốc ngắn li&ecirc;n tục v&agrave; đổi hướng cực nhanh. Ch&iacute;nh v&igrave; vậy, F50 Messi kh&ocirc;ng chỉ cần nhẹ &ndash; m&agrave; phải phản hồi nhanh v&agrave; giữ được cảm gi&aacute;c b&oacute;ng ch&iacute;nh x&aacute;c.</p>\r\n<p>Triết l&yacute; đ&oacute; được t&aacute;i hiện tr&ecirc;n thế hệ F50 Messi mới: speed nhưng kh&ocirc;ng đ&aacute;nh đổi khả năng kiểm so&aacute;t.</p>\r\n<h2><span id=\"cong-nghe\">3. C&ocirc;ng nghệ tr&ecirc;n Adidas F50 Messi thế hệ mới</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260226_eljRvukJ.jpg\" alt=\"Adidas F50 Messi 4\" width=\"1000\" height=\"725\" />\r\n<figcaption>Adidas F50 Messi</figcaption>\r\n</figure>\r\n<h3>Fibertouch Upper</h3>\r\n<p>Upper Fibertouch dạng mesh tổng hợp cho cảm gi&aacute;c b&oacute;ng trực diện. Khi r&ecirc; b&oacute;ng ở tốc độ cao, lớp vật liệu n&agrave;y gi&uacute;p phản hồi nhanh v&agrave; r&otilde; lực.</p>\r\n<h3>Sprintweb Texturing</h3>\r\n<p>Bề mặt phủ v&acirc;n nổi Sprintweb tăng ma s&aacute;t khi xử l&yacute; b&oacute;ng, hỗ trợ những pha đảo hướng nhanh &ndash; đ&uacute;ng phong c&aacute;ch Messi.</p>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260226_6Bm3hqNC.jpg\" alt=\"Adidas F50 Messi 5\" width=\"1000\" height=\"725\" />\r\n<figcaption>Adidas F50 Messi</figcaption>\r\n</figure>\r\n<h3>Sprintframe 360</h3>\r\n<p>Bộ đế Sprintframe 360 với cấu tr&uacute;c đinh b&aacute;n n&oacute;n kết hợp lưỡi dao hỗ trợ xoay trụ đa hướng. Điều n&agrave;y đặc biệt hữu &iacute;ch khi r&ecirc; b&oacute;ng v&agrave; cắt v&agrave;o trung lộ.</p>\r\n<p>Một số phi&ecirc;n bản cao cấp c&ograve;n t&iacute;ch hợp Lightstrike Pro ở phần forefoot gi&uacute;p tăng độ bật khi tăng tốc ngắn.</p>\r\n<p>Tổng thể, F50 Messi vẫn giữ DNA speed boot, nhưng cảm gi&aacute;c b&oacute;ng c&oacute; xu hướng &ldquo;mềm&rdquo; v&agrave; kiểm so&aacute;t hơn so với nhiều speed boot thuần kh&aacute;c.</p>\r\n<h2><span id=\"so-sanh\">4. So s&aacute;nh F50 Messi Elite &ndash; Pro &ndash; League</span></h2>\r\n<h3>F50 Messi Elite</h3>\r\n<p>Phi&ecirc;n bản cao cấp nhất, ho&agrave;n thiện chi tiết tốt nhất, upper mỏng v&agrave; phản hồi r&otilde;. Ph&ugrave; hợp người chơi cường độ cao, muốn cảm gi&aacute;c locked-in tối đa.</p>\r\n<h3>F50 Messi Pro</h3>\r\n<p>Giữ lại phần lớn nền tảng c&ocirc;ng nghệ nhưng tối ưu gi&aacute; th&agrave;nh. Tương tự như triết l&yacute; của&nbsp;<a href=\"https://thegioibongda.net/adidas-f50-pro-tf-pc566123.html\">Adidas F50 Pro</a>, đ&acirc;y thường l&agrave; lựa chọn c&acirc;n bằng giữa hiệu năng v&agrave; ng&acirc;n s&aacute;ch.</p>\r\n<h3>F50 Messi League</h3>\r\n<p>Phi&ecirc;n bản dễ tiếp cận hơn, ph&ugrave; hợp học sinh &ndash; sinh vi&ecirc;n hoặc người chơi phong tr&agrave;o. C&aacute;ch ph&acirc;n cấp tương tự d&ograve;ng&nbsp;<a href=\"https://thegioibongda.net/adidas-f50-league-tf-pc566124.html\">Adidas F50 League</a>, nhưng mang thiết kế Messi.</p>\r\n<p>Trong c&aacute;c buổi tư vấn thực tế tại cửa h&agrave;ng, phi&ecirc;n bản Pro thường l&agrave; lựa chọn hợp l&yacute; nhất cho s&acirc;n 7 Việt Nam &ndash; vừa đủ c&ocirc;ng nghệ, vừa tối ưu chi ph&iacute;.</p>\r\n<h2><span id=\"phu-hop\">5. Ai n&ecirc;n chọn Adidas F50 Messi?</span></h2>\r\n<ul>\r\n<li>Cầu thủ r&ecirc; dắt, th&iacute;ch xử l&yacute; b&oacute;ng trong phạm vi hẹp</li>\r\n<li>Người chơi đ&aacute; bi&ecirc;n hoặc tiền đạo nhỏ con thi&ecirc;n kỹ thuật</li>\r\n<li>Anh em th&iacute;ch cảm gi&aacute;c b&oacute;ng r&otilde;, phản hồi nhanh</li>\r\n</ul>\r\n<p>Kh&ocirc;ng ph&ugrave; hợp nếu:</p>\r\n<ul>\r\n<li>Bạn c&oacute; b&agrave;n ch&acirc;n qu&aacute; b&egrave; ngang</li>\r\n<li>Ưu ti&ecirc;n độ &ecirc;m d&agrave;y như d&ograve;ng kiểm so&aacute;t truyền thống</li>\r\n</ul>\r\n<p>Nếu đang t&igrave;m một đ&ocirc;i&nbsp;<a href=\"https://thegioibongda.net/\">gi&agrave;y b&oacute;ng đ&aacute;</a>&nbsp;thi&ecirc;n về kỹ thuật v&agrave; tăng tốc ngắn, F50 Messi l&agrave; lựa chọn rất đ&aacute;ng c&acirc;n nhắc.</p>\r\n<h2><span id=\"ket-noi-silo\">6. C&aacute;c b&agrave;i chi tiết về F50 Messi</span></h2>\r\n<ul>\r\n<li>Đ&aacute;nh gi&aacute; chi tiết F50 Messi Elite</li>\r\n<li>Ph&acirc;n t&iacute;ch hiệu năng F50 Messi Pro s&acirc;n 7</li>\r\n<li>Cảm nhận thực tế F50 Messi League phong tr&agrave;o</li>\r\n<li>So s&aacute;nh F50 Messi v&agrave; F50 thường</li>\r\n</ul>','2025-09-03 14:22:46.775864','Nhiều anh em nghĩ F50 Messi chỉ khác ở phối màu. Thực tế, đây là phiên bản mang dấu ấn cá nhân của Lionel Messi, từ thiết kế đồ họa, màu sắc đến tinh thần chơi bóng mà đôi giày hướng tới.','http://res.cloudinary.com/dt2g4oabz/image/upload/v1773385157/rxmgrzwbvdv5t1bqdpmw.jpg','Nhiều anh em nghĩ F50 Messi chỉ khác ở phối màu. Thực tế, đây là phiên bản mang dấu ấn cá nhân của Lionel Messi, từ thiết kế đồ họa, màu sắc đến tinh thần chơi bóng mà đôi giày hướng tới.',0,'Adidas F50 Messi – Di sản tốc độ mang dấu ấn của một huyền thoại','adidas-f50-messi-di-san-toc-o-mang-dau-an-cua-mot-huyen-thoai','Adidas F50 Messi – Di sản tốc độ mang dấu ấn của một huyền thoại','2026-03-13 13:59:46.200364',NULL),(5,'<section class=\"right-content col-lg-9 col-12 mx-auto\">\r\n<article class=\"article-main\">\r\n<div class=\"article-details\">\r\n<div class=\"article-content js-toc-content\">\r\n<div id=\"ega-uti-editable-content\" class=\"rte\" data-platform=\"haravan\" data-id=\"1002600538\" data-blog-id=\"1000950832\">\r\n<h1 style=\"text-align: center;\">Mizuno &lsquo;Blazing Flair&rsquo; Pack &ndash; &ldquo;Ignite The Pitch&rdquo; v&agrave; sắc hồng kiểu Nhật</h1>\r\n<div class=\"title-main-home\">\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260222_1pTdHK18.jpg\" alt=\"Mizuno &lsquo;Blazing Flair&rsquo; Pack\" width=\"1000\" height=\"437\" />\r\n<figcaption>Mizuno &lsquo;Blazing Flair&rsquo; Pack</figcaption>\r\n</figure>\r\n<div id=\"toc_container\" class=\"no_bullets\">\r\n<p class=\"toc_title\" style=\"text-align: center;\"><strong>Mục lục</strong></p>\r\n<p style=\"text-align: center;\">1. Giới thiệu Blazing Flair Pack</p>\r\n<p style=\"text-align: center;\">2. Concept &ldquo;Ignite The Pitch&rdquo;: hiệu ứng bản đồ nhiệt v&agrave; tinh thần bứt ph&aacute;</p>\r\n<p style=\"text-align: center;\">3. M&agrave;u sắc White/Pink Tetra/Fuchsia Purple: nổi bật nhưng kh&ocirc;ng &ldquo;lố&rdquo;</p>\r\n<p style=\"text-align: center;\">4. Alpha 3: nhanh, &ocirc;m ch&acirc;n v&agrave; sinh ra cho những pha tăng tốc</p>\r\n<p style=\"text-align: center;\">5. Morelia Neo 4: Kaizen &ndash; tinh chỉnh từng chi tiết, giữ chất K-Leather</p>\r\n<p style=\"text-align: center;\">6. Gợi &yacute; chọn nhanh: bạn hợp Alpha hay Morelia Neo?</p>\r\n</div>\r\n<h2><span id=\"gioi-thieu\">1. Giới thiệu Blazing Flair Pack</span></h2>\r\n<div>\r\n<p style=\"text-align: center;\"><iframe src=\"https://www.youtube.com/embed/STx-qafhxFw\" width=\"1000\" height=\"700\" frameborder=\"0\" data-mce-fragment=\"1\"></iframe></p>\r\n</div>\r\n<p>Mizuno vừa &ldquo;đ&aacute;nh thức&rdquo; s&acirc;n cỏ với bộ sưu tập mới mang t&ecirc;n&nbsp;<strong>Blazing Flair</strong>&nbsp;&ndash; một pack đ&uacute;ng kiểu&nbsp;<strong>mạnh năng lượng, mạnh c&aacute; t&iacute;nh</strong>, nhưng vẫn giữ c&aacute;i chất rất Mizuno: vừa c&oacute; di sản, vừa c&oacute; hiệu năng, v&agrave; ho&agrave;n thiện tỉ mỉ đến mức kh&oacute; bắt bẻ.</p>\r\n<p>Blazing Flair quy tụ hai d&ograve;ng được quan t&acirc;m nhất hiện tại của Mizuno:&nbsp;<strong>Alpha 3</strong>&nbsp;(thi&ecirc;n về tốc độ) v&agrave;&nbsp;<strong>Morelia Neo 4</strong>&nbsp;(thi&ecirc;n cảm gi&aacute;c b&oacute;ng &ndash; di sản). Nếu bạn đang t&igrave;m một đ&ocirc;i&nbsp;gi&agrave;y đ&aacute; b&oacute;ng Mizuno&nbsp;nổi bật khi ra s&acirc;n nhưng vẫn &ldquo;đ&uacute;ng b&agrave;i&rdquo; để đ&aacute; thật, pack n&agrave;y l&agrave; c&aacute;i t&ecirc;n rất đ&aacute;ng thử.</p>\r\n<h2><span id=\"concept\">2. Concept &ldquo;Ignite The Pitch&rdquo;: hiệu ứng bản đồ nhiệt v&agrave; tinh thần bứt ph&aacute;</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260222_KX47xSH9.jpg\" alt=\"Mizuno &lsquo;Blazing Flair&rsquo; Pack 2\" width=\"1000\" height=\"725\" />\r\n<figcaption>Mizuno &lsquo;Blazing Flair&rsquo; Pack</figcaption>\r\n</figure>\r\n<p>Điểm khiến Blazing Flair &ldquo;c&oacute; hồn&rdquo; kh&ocirc;ng chỉ nằm ở phối m&agrave;u, m&agrave; ở concept Mizuno x&acirc;y dựng cho cả pack:&nbsp;<strong>IGNITE THE PITCH</strong>. Hiểu đơn giản, đ&acirc;y l&agrave; c&acirc;u chuyện về&nbsp;<strong>nhiệt lượng</strong>&nbsp;&ndash; nhiệt của cơ thể, nhiệt của nhịp độ trận đấu, v&agrave; nhiệt của tham vọng khi bạn tăng tốc.</p>\r\n<p>Mizuno d&ugrave;ng cảm hứng&nbsp;<strong>infrared (hồng ngoại)</strong>&nbsp;để tạo cảm gi&aacute;c như một&nbsp;<strong>heat mapping</strong>&nbsp;(bản đồ nhiệt): mỗi bước chạy l&agrave; một lần &ldquo;đốt&rdquo; s&acirc;n, c&agrave;ng v&agrave;o trận c&agrave;ng n&oacute;ng, c&agrave;ng gắt, c&agrave;ng b&ugrave;ng. V&agrave; khi game l&ecirc;n cao tr&agrave;o, pack n&agrave;y nhắc bạn một điều:&nbsp;<strong>đừng n&eacute; nhiệt &ndash; h&atilde;y embrace the heat</strong>.</p>\r\n<p>Blazing Flair cũng l&agrave; một&nbsp;<strong>fiery statement</strong>&nbsp;d&agrave;nh cho những cầu thủ th&iacute;ch ph&aacute; giới hạn: d&aacute;m thể hiện, d&aacute;m kh&aacute;c biệt, d&aacute;m đ&aacute; theo c&aacute;ch của m&igrave;nh. M&agrave;u hồng &ndash; cam &ndash; t&iacute;m kh&ocirc;ng chỉ để nổi bật, m&agrave; để phản chiếu tinh thần&nbsp;<strong>fearless pursuit</strong>: theo đuổi sự tốt hơn một c&aacute;ch kh&ocirc;ng sợ h&atilde;i.</p>\r\n<h2><span id=\"mau-sac\">3. M&agrave;u sắc White/Pink Tetra/Fuchsia Purple: nổi bật nhưng kh&ocirc;ng &ldquo;lố&rdquo;</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260222_8j5fzCNn.jpg\" alt=\"Mizuno &lsquo;Blazing Flair&rsquo; Pack 3\" width=\"1000\" height=\"725\" />\r\n<figcaption>Mizuno &lsquo;Blazing Flair&rsquo; Pack</figcaption>\r\n</figure>\r\n<p>Blazing Flair xuất hiện trong bảng m&agrave;u&nbsp;<strong>White/Pink Tetra/Fuchsia Purple</strong>: nền trắng s&aacute;ng, phủ l&ecirc;n c&aacute;c mảng chuyển sắc hồng &ndash; t&iacute;m kiểu &ldquo;ch&aacute;y nhiệt&rdquo;. Nh&igrave;n ngo&agrave;i đời sẽ c&oacute; cảm gi&aacute;c&nbsp;<strong>ăn đ&egrave;n rất tốt</strong>, đặc biệt khi đ&aacute; s&acirc;n tối hoặc s&acirc;n c&oacute; đ&egrave;n mạnh.</p>\r\n<p>Điều hay l&agrave; Mizuno giữ được sự c&acirc;n bằng. D&ugrave; m&agrave;u nổi, tổng thể vẫn sạch v&agrave; dễ phối đồ s&acirc;n. Quan trọng hơn: mỗi silo &ldquo;dịch&rdquo; bảng m&agrave;u theo c&aacute;ch ri&ecirc;ng: Alpha 3 nh&igrave;n hiện đại, tốc độ; Morelia Neo 4 vẫn tối giản cổ điển nhưng được n&acirc;ng mood r&otilde; rệt.</p>\r\n<h2><span id=\"alpha-3\">4. Alpha 3: nhanh, &ocirc;m ch&acirc;n v&agrave; sinh ra cho những pha tăng tốc</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260222_9JzKdH9b.jpg\" alt=\"Mizuno &lsquo;Blazing Flair&rsquo; Pack Alpha 3\" width=\"1000\" height=\"505\" />\r\n<figcaption>Mizuno &lsquo;Blazing Flair&rsquo; Pack Alpha 3</figcaption>\r\n</figure>\r\n<p>T&acirc;m điểm của pack l&agrave;&nbsp;<strong>Alpha 3</strong>&nbsp;&ndash; d&ograve;ng &ldquo;fast&rdquo; của Mizuno với triết l&yacute; rất thẳng: đ&ocirc;i gi&agrave;y phải&nbsp;<strong>&ocirc;m ch&acirc;n như một phần cơ thể</strong>&nbsp;để bạn tăng tốc, đổi hướng tự nhi&ecirc;n v&agrave; gọn hơn.</p>\r\n<p>Điểm n&acirc;ng cấp đ&aacute;ng ch&uacute; &yacute; l&agrave;&nbsp;<strong>upper knit mới</strong>, được Mizuno ph&aacute;t triển để tạo cảm gi&aacute;c nhẹ, mềm v&agrave; &ldquo;adapt&rdquo; tốt khi ch&acirc;n hoạt động li&ecirc;n tục. Upper được gia cố bằng c&aacute;c đường kh&acirc;u ch&iacute;nh x&aacute;c, gi&uacute;p giữ form &ocirc;m v&agrave; hỗ trợ vừa đủ khi bạn bứt hoặc quặt gấp.</p>\r\n<p>Ở ph&iacute;a dưới, lớp đệm&nbsp;<strong>Mizuno Enerzy</strong>&nbsp;gi&uacute;p đ&ocirc;i gi&agrave;y c&oacute; độ &ecirc;m v&agrave; độ nảy dễ chịu hơn, đặc biệt hữu &iacute;ch với anh em đ&aacute; tốc độ cao nhưng vẫn muốn ch&acirc;n kh&ocirc;ng bị &ldquo;gắt&rdquo; sau 60&ndash;90 ph&uacute;t.</p>\r\n<p>Nếu bạn l&agrave; kiểu cầu thủ chạy c&aacute;nh, tiền đạo, hoặc đ&aacute; s&acirc;n 7 cần pressing v&agrave; di chuyển rộng, Alpha 3 l&agrave; lựa chọn rất hợp &ldquo;nhịp&rdquo; &ndash; kiểu gi&agrave;y mang cảm gi&aacute;c&nbsp;<strong>gọn, nhanh, d&iacute;nh ch&acirc;n</strong>.</p>\r\n<h2><span id=\"morelia-neo-4\">5. Morelia Neo 4: Kaizen &ndash; tinh chỉnh từng chi tiết, giữ chất K-Leather</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260222_ZkSc7Mzl.jpg\" alt=\"Mizuno &lsquo;Blazing Flair&rsquo; Pack Neo 4\" width=\"1000\" height=\"522\" />\r\n<figcaption>Mizuno &lsquo;Blazing Flair&rsquo; Pack Neo 4</figcaption>\r\n</figure>\r\n<p>Song h&agrave;nh với Alpha 3 l&agrave;&nbsp;<strong>Morelia Neo 4</strong>&nbsp;&ndash; đ&ocirc;i gi&agrave;y thể hiện r&otilde; triết l&yacute;&nbsp;<strong>KAIZEN</strong>&nbsp;của Mizuno: cải tiến li&ecirc;n tục, tốt hơn từng ch&uacute;t một, tinh chỉnh đến từng chi tiết nhỏ.</p>\r\n<p>Neo 4 tiếp tục giữ &ldquo;vũ kh&iacute;&rdquo; l&agrave;m n&ecirc;n t&ecirc;n tuổi: cảm gi&aacute;c chạm b&oacute;ng tự nhi&ecirc;n, &ocirc;m ch&acirc;n kiểu &ldquo;second-skin&rdquo; v&agrave; độ ho&agrave;n thiện rất Nhật. Mizuno kết hợp vật liệu hiện đại của thập kỷ mới c&ugrave;ng&nbsp;<strong>K-Leather trứ danh</strong>&nbsp;để tạo ra cảm gi&aacute;c mềm, thật ch&acirc;n nhưng vẫn theo kịp b&oacute;ng đ&aacute; hiện đại.</p>\r\n<p>Nếu bạn ưu ti&ecirc;n chạm b&oacute;ng, xoay trở trong kh&ocirc;ng gian hẹp, chuyền &ndash; nhận &ndash; giữ nhịp, v&agrave; th&iacute;ch một đ&ocirc;i gi&agrave;y mềm nhưng chắc, Neo 4 l&agrave; lựa chọn cực hợp để chơi tr&ecirc;n&nbsp;s&acirc;n cỏ nh&acirc;n tạo.</p>\r\n<h2><span id=\"goi-y-chon\">6. Gợi &yacute; chọn nhanh: bạn hợp Alpha hay Morelia Neo?</span></h2>\r\n<p>Chọn nhanh theo lối chơi để khỏi lăn tăn:</p>\r\n<ul>\r\n<li><strong>Chọn Alpha 3</strong>&nbsp;nếu bạn đ&aacute; thi&ecirc;n tốc độ, bứt tăng tốc nhiều, chạy c&aacute;nh &ndash; tiền đạo, th&iacute;ch cảm gi&aacute;c &ldquo;gọn &ndash; &ocirc;m &ndash; nhanh&rdquo;, ra s&acirc;n l&agrave; muốn chơi &ldquo;n&oacute;ng&rdquo; ngay.</li>\r\n<li><strong>Chọn Morelia Neo 4</strong>&nbsp;nếu bạn đặt cảm gi&aacute;c b&oacute;ng l&ecirc;n h&agrave;ng đầu, th&iacute;ch chạm thật, kiểm so&aacute;t b&oacute;ng chắc, form &ocirc;m mềm mại, v&agrave; m&ecirc; kiểu chất cổ điển nhưng vẫn rất hiệu quả.</li>\r\n</ul>\r\n<p>D&ugrave; bạn chọn silo n&agrave;o, Blazing Flair vẫn mang chung một th&ocirc;ng điệp:&nbsp;<strong>h&atilde;y embrace the heat</strong>&nbsp;&ndash; c&agrave;ng v&agrave;o trận c&agrave;ng gắt, c&agrave;ng b&ugrave;ng. Đ&acirc;y l&agrave; pack d&agrave;nh cho cầu thủ kh&ocirc;ng ngại thể hiện bản th&acirc;n, kh&ocirc;ng ngại đẩy giới hạn v&agrave; muốn để đ&ocirc;i gi&agrave;y n&oacute;i l&ecirc;n c&aacute; t&iacute;nh.</p>\r\n<p>Nếu bạn đang c&acirc;n nhắc đổi gi&agrave;y để ra s&acirc;n &ldquo;s&aacute;ng&rdquo; hơn, chơi tự tin hơn, Blazing Flair l&agrave; lựa chọn đ&aacute;ng thử b&ecirc;n cạnh c&aacute;c d&ograve;ng phổ biến từ&nbsp;adidas&nbsp;hay&nbsp;Nike. V&agrave; nếu vẫn ph&acirc;n v&acirc;n, cứ gh&eacute; cửa h&agrave;ng &ndash; thử l&ecirc;n ch&acirc;n sẽ ra đ&aacute;p &aacute;n nhanh nhất.</p>\r\n<h2><span id=\"he-thong-the-gioi-bong-da\">Hệ thống cửa h&agrave;ng Beyond</span></h2>\r\n<p>C&aacute;c nhận định v&agrave; trải nghiệm trong b&agrave;i được tổng hợp từ thực tế tư vấn, thử gi&agrave;y v&agrave; phản hồi của kh&aacute;ch h&agrave;ng tại hệ thống cửa h&agrave;ng Thế Giới B&oacute;ng Đ&aacute; &ndash; chuy&ecirc;n gi&agrave;y đ&aacute; b&oacute;ng ch&iacute;nh h&atilde;ng.</p>\r\n<p>Tại cửa h&agrave;ng, kh&aacute;ch h&agrave;ng c&oacute; thể thử trực tiếp từng d&ograve;ng gi&agrave;y theo form ch&acirc;n, được tư vấn size ph&ugrave; hợp v&agrave; hỗ trợ đổi size nếu chưa vừa khi sử dụng thực tế.</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</article>\r\n</section>','2025-09-03 14:24:40.865207','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777606841/lk9ahsojumb6mw29wbmf.jpg','',0,'Mizuno ‘Blazing Flair’ Pack – “Ignite The Pitch” và sắc hồng','mizuno-blazing-flair-pack-ignite-the-pitch-va-sac-hong','Mizuno ‘Blazing Flair’ Pack – “Ignite The Pitch” và sắc hồng','2026-05-01 11:18:52.295881',NULL),(12,'<h2><span id=\"concept\">1 Concept &ldquo;Ignite The Pitch&rdquo;: hiệu ứng bản đồ nhiệt v&agrave; tinh thần bứt ph&aacute;</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260222_KX47xSH9.jpg\" alt=\"Mizuno &lsquo;Blazing Flair&rsquo; Pack 2\" width=\"1000\" height=\"725\" />\r\n<figcaption>Mizuno &lsquo;Blazing Flair&rsquo; Pack</figcaption>\r\n</figure>\r\n<p>Điểm khiến Blazing Flair &ldquo;c&oacute; hồn&rdquo; kh&ocirc;ng chỉ nằm ở phối m&agrave;u, m&agrave; ở concept Mizuno x&acirc;y dựng cho cả pack: <strong>IGNITE THE PITCH</strong>. Hiểu đơn giản, đ&acirc;y l&agrave; c&acirc;u chuyện về&nbsp;<strong>nhiệt lượng</strong>&nbsp;&ndash; nhiệt của cơ thể, nhiệt của nhịp độ trận đấu, v&agrave; nhiệt của tham vọng khi bạn tăng tốc.</p>\r\n<p>Mizuno d&ugrave;ng cảm hứng&nbsp;<strong>infrared (hồng ngoại)</strong>&nbsp;để tạo cảm gi&aacute;c như một&nbsp;<strong>heat mapping</strong>&nbsp;(bản đồ nhiệt): mỗi bước chạy l&agrave; một lần &ldquo;đốt&rdquo; s&acirc;n, c&agrave;ng v&agrave;o trận c&agrave;ng n&oacute;ng, c&agrave;ng gắt, c&agrave;ng b&ugrave;ng. V&agrave; khi game l&ecirc;n cao tr&agrave;o, pack n&agrave;y nhắc bạn một điều:&nbsp;<strong>đừng n&eacute; nhiệt &ndash; h&atilde;y embrace the heat</strong>.</p>\r\n<p>Blazing Flair cũng l&agrave; một&nbsp;<strong>fiery statement</strong>&nbsp;d&agrave;nh cho những cầu thủ th&iacute;ch ph&aacute; giới hạn: d&aacute;m thể hiện, d&aacute;m kh&aacute;c biệt, d&aacute;m đ&aacute; theo c&aacute;ch của m&igrave;nh. M&agrave;u hồng &ndash; cam &ndash; t&iacute;m kh&ocirc;ng chỉ để nổi bật, m&agrave; để phản chiếu tinh thần&nbsp;<strong>fearless pursuit</strong>: theo đuổi sự tốt hơn một c&aacute;ch kh&ocirc;ng sợ h&atilde;i.</p>\r\n<h2><span id=\"mau-sac\">3. M&agrave;u sắc White/Pink Tetra/Fuchsia Purple: nổi bật nhưng kh&ocirc;ng &ldquo;lố&rdquo;</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260222_8j5fzCNn.jpg\" alt=\"Mizuno &lsquo;Blazing Flair&rsquo; Pack 3\" width=\"1000\" height=\"725\" />\r\n<figcaption>Mizuno &lsquo;Blazing Flair&rsquo; Pack</figcaption>\r\n</figure>\r\n<p>Blazing Flair xuất hiện trong bảng m&agrave;u&nbsp;<strong>White/Pink Tetra/Fuchsia Purple</strong>: nền trắng s&aacute;ng, phủ l&ecirc;n c&aacute;c mảng chuyển sắc hồng &ndash; t&iacute;m kiểu &ldquo;ch&aacute;y nhiệt&rdquo;. Nh&igrave;n ngo&agrave;i đời sẽ c&oacute; cảm gi&aacute;c&nbsp;<strong>ăn đ&egrave;n rất tốt</strong>, đặc biệt khi đ&aacute; s&acirc;n tối hoặc s&acirc;n c&oacute; đ&egrave;n mạnh.</p>\r\n<p>Điều hay l&agrave; Mizuno giữ được sự c&acirc;n bằng. D&ugrave; m&agrave;u nổi, tổng thể vẫn sạch v&agrave; dễ phối đồ s&acirc;n. Quan trọng hơn: mỗi silo &ldquo;dịch&rdquo; bảng m&agrave;u theo c&aacute;ch ri&ecirc;ng: Alpha 3 nh&igrave;n hiện đại, tốc độ; Morelia Neo 4 vẫn tối giản cổ điển nhưng được n&acirc;ng mood r&otilde; rệt.</p>\r\n<h2><span id=\"alpha-3\">4. Alpha 3: nhanh, &ocirc;m ch&acirc;n v&agrave; sinh ra cho những pha tăng tốc</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260222_9JzKdH9b.jpg\" alt=\"Mizuno &lsquo;Blazing Flair&rsquo; Pack Alpha 3\" width=\"1000\" height=\"505\" />\r\n<figcaption>Mizuno &lsquo;Blazing Flair&rsquo; Pack Alpha 3</figcaption>\r\n</figure>\r\n<p>T&acirc;m điểm của pack l&agrave;&nbsp;<strong>Alpha 3</strong>&nbsp;&ndash; d&ograve;ng &ldquo;fast&rdquo; của Mizuno với triết l&yacute; rất thẳng: đ&ocirc;i gi&agrave;y phải&nbsp;<strong>&ocirc;m ch&acirc;n như một phần cơ thể</strong>&nbsp;để bạn tăng tốc, đổi hướng tự nhi&ecirc;n v&agrave; gọn hơn.</p>\r\n<p>Điểm n&acirc;ng cấp đ&aacute;ng ch&uacute; &yacute; l&agrave;&nbsp;<strong>upper knit mới</strong>, được Mizuno ph&aacute;t triển để tạo cảm gi&aacute;c nhẹ, mềm v&agrave; &ldquo;adapt&rdquo; tốt khi ch&acirc;n hoạt động li&ecirc;n tục. Upper được gia cố bằng c&aacute;c đường kh&acirc;u ch&iacute;nh x&aacute;c, gi&uacute;p giữ form &ocirc;m v&agrave; hỗ trợ vừa đủ khi bạn bứt hoặc quặt gấp.</p>\r\n<p>Ở ph&iacute;a dưới, lớp đệm&nbsp;<strong>Mizuno Enerzy</strong>&nbsp;gi&uacute;p đ&ocirc;i gi&agrave;y c&oacute; độ &ecirc;m v&agrave; độ nảy dễ chịu hơn, đặc biệt hữu &iacute;ch với anh em đ&aacute; tốc độ cao nhưng vẫn muốn ch&acirc;n kh&ocirc;ng bị &ldquo;gắt&rdquo; sau 60&ndash;90 ph&uacute;t.</p>\r\n<p>Nếu bạn l&agrave; kiểu cầu thủ chạy c&aacute;nh, tiền đạo, hoặc đ&aacute; s&acirc;n 7 cần pressing v&agrave; di chuyển rộng, Alpha 3 l&agrave; lựa chọn rất hợp &ldquo;nhịp&rdquo; &ndash; kiểu gi&agrave;y mang cảm gi&aacute;c&nbsp;<strong>gọn, nhanh, d&iacute;nh ch&acirc;n</strong>.</p>\r\n<h2><span id=\"morelia-neo-4\">5. Morelia Neo 4: Kaizen &ndash; tinh chỉnh từng chi tiết, giữ chất K-Leather</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260222_ZkSc7Mzl.jpg\" alt=\"Mizuno &lsquo;Blazing Flair&rsquo; Pack Neo 4\" width=\"1000\" height=\"522\" />\r\n<figcaption>Mizuno &lsquo;Blazing Flair&rsquo; Pack Neo 4</figcaption>\r\n</figure>\r\n<p>Song h&agrave;nh với Alpha 3 l&agrave;&nbsp;<strong>Morelia Neo 4</strong>&nbsp;&ndash; đ&ocirc;i gi&agrave;y thể hiện r&otilde; triết l&yacute;&nbsp;<strong>KAIZEN</strong>&nbsp;của Mizuno: cải tiến li&ecirc;n tục, tốt hơn từng ch&uacute;t một, tinh chỉnh đến từng chi tiết nhỏ.</p>\r\n<p>Neo 4 tiếp tục giữ &ldquo;vũ kh&iacute;&rdquo; l&agrave;m n&ecirc;n t&ecirc;n tuổi: cảm gi&aacute;c chạm b&oacute;ng tự nhi&ecirc;n, &ocirc;m ch&acirc;n kiểu &ldquo;second-skin&rdquo; v&agrave; độ ho&agrave;n thiện rất Nhật. Mizuno kết hợp vật liệu hiện đại của thập kỷ mới c&ugrave;ng&nbsp;<strong>K-Leather trứ danh</strong>&nbsp;để tạo ra cảm gi&aacute;c mềm, thật ch&acirc;n nhưng vẫn theo kịp b&oacute;ng đ&aacute; hiện đại.</p>\r\n<p>Nếu bạn ưu ti&ecirc;n chạm b&oacute;ng, xoay trở trong kh&ocirc;ng gian hẹp, chuyền &ndash; nhận &ndash; giữ nhịp, v&agrave; th&iacute;ch một đ&ocirc;i gi&agrave;y mềm nhưng chắc, Neo 4 l&agrave; lựa chọn cực hợp để chơi tr&ecirc;n&nbsp;<a href=\"https://thegioibongda.net/giay-da-bong-san-co-nhan-tao-pc200642.html\">s&acirc;n cỏ nh&acirc;n tạo</a>.</p>\r\n<h2><span id=\"goi-y-chon\">6. Gợi &yacute; chọn nhanh: bạn hợp Alpha hay Morelia Neo?</span></h2>\r\n<p>Chọn nhanh theo lối chơi để khỏi lăn tăn:</p>\r\n<ul>\r\n<li><strong>Chọn Alpha 3</strong>&nbsp;nếu bạn đ&aacute; thi&ecirc;n tốc độ, bứt tăng tốc nhiều, chạy c&aacute;nh &ndash; tiền đạo, th&iacute;ch cảm gi&aacute;c &ldquo;gọn &ndash; &ocirc;m &ndash; nhanh&rdquo;, ra s&acirc;n l&agrave; muốn chơi &ldquo;n&oacute;ng&rdquo; ngay.</li>\r\n<li><strong>Chọn Morelia Neo 4</strong>&nbsp;nếu bạn đặt cảm gi&aacute;c b&oacute;ng l&ecirc;n h&agrave;ng đầu, th&iacute;ch chạm thật, kiểm so&aacute;t b&oacute;ng chắc, form &ocirc;m mềm mại, v&agrave; m&ecirc; kiểu chất cổ điển nhưng vẫn rất hiệu quả.</li>\r\n</ul>\r\n<p>D&ugrave; bạn chọn silo n&agrave;o, Blazing Flair vẫn mang chung một th&ocirc;ng điệp:&nbsp;<strong>h&atilde;y embrace the heat</strong>&nbsp;&ndash; c&agrave;ng v&agrave;o trận c&agrave;ng gắt, c&agrave;ng b&ugrave;ng. Đ&acirc;y l&agrave; pack d&agrave;nh cho cầu thủ kh&ocirc;ng ngại thể hiện bản th&acirc;n, kh&ocirc;ng ngại đẩy giới hạn v&agrave; muốn để đ&ocirc;i gi&agrave;y n&oacute;i l&ecirc;n c&aacute; t&iacute;nh.</p>\r\n<p>Nếu bạn đang c&acirc;n nhắc đổi gi&agrave;y để ra s&acirc;n &ldquo;s&aacute;ng&rdquo; hơn, chơi tự tin hơn, Blazing Flair l&agrave; lựa chọn đ&aacute;ng thử b&ecirc;n cạnh c&aacute;c d&ograve;ng phổ biến từ&nbsp;<a href=\"https://thegioibongda.net/giay-da-bong-adidas-pc386022.html\">adidas</a>&nbsp;hay&nbsp;<a href=\"https://thegioibongda.net/giay-da-bong-nike-pc386013.html\">Nike</a>. V&agrave; nếu vẫn ph&acirc;n v&acirc;n, cứ gh&eacute; cửa h&agrave;ng &ndash; thử l&ecirc;n ch&acirc;n sẽ ra đ&aacute;p &aacute;n nhanh nhất.</p>','2026-03-13 14:02:26.274014','Blazing Flair quy tụ hai dòng được quan tâm nhất hiện tại của Mizuno','http://res.cloudinary.com/dt2g4oabz/image/upload/v1773385315/lsjgazbpcxmmg9duke17.jpg','Blazing Flair quy tụ hai dòng được quan tâm nhất hiện tại của Mizuno',0,'Mizuno ‘Blazing Flair’ Pack – “Ignite The Pitch” và sắc hồng kiểu Nhật','mizuno-blazing-flair-pack-ignite-the-pitch-va-sac-hong-kieu-nhat','Mizuno ‘Blazing Flair’ Pack – “Ignite The Pitch” và sắc hồng kiểu Nhật','2026-03-13 14:02:26.280862',NULL),(13,'<blockquote><header class=\"entry-header\">\r\n<div class=\"entry-header-text entry-header-text-top text-left\">\r\n<h1 class=\"entry-title\">Quy tr&igrave;nh sản xuất gi&agrave;y đ&aacute; b&oacute;ng tại Wika như thế n&agrave;o?</h1>\r\n</div>\r\n</header>\r\n<div class=\"entry-content single-page\">\r\n<p>Sản xuất giầy đ&aacute; b&oacute;ng th&igrave; c&oacute; mấy c&ocirc;ng đoạn? Chắc hẳn c&aacute;c bạn lu&ocirc;n thắc mắc quy tr&igrave;nh sản xuất gi&agrave;y tại Wika như thế n&agrave;o? B&agrave;i viết h&ocirc;m nay ch&uacute;ng t&ocirc;i xin giới thiệu tới c&aacute;c bạn quy tr&igrave;nh sản xuất gi&agrave;y v&agrave; c&aacute;c c&ocirc;ng nghệ ti&ecirc;n tiến nhất được sử dụng với đ&ocirc;i gi&agrave;y mang thương hiệu Wika.</p>\r\n</div>\r\n</blockquote>\r\n<blockquote>\r\n<div class=\"entry-content single-page\">\r\n<div id=\"ez-toc-container\" class=\"ez-toc-v2_0_63 counter-hierarchy ez-toc-counter ez-toc-grey ez-toc-container-direction\">\r\n<div class=\"ez-toc-title-container\">\r\n<p class=\"ez-toc-title \">Nội Dung</p>\r\n</div>\r\n<nav>\r\n<ul class=\"ez-toc-list ez-toc-list-level-1 \">\r\n<li class=\"ez-toc-page-1 ez-toc-heading-level-2\">Quy tr&igrave;nh sản xuất giầy đ&aacute; b&oacute;ng tại Wika\r\n<ul class=\"ez-toc-list-level-3\">\r\n<li class=\"ez-toc-heading-level-3\">Bước 1: Thiết kế v&agrave; sản xuất gi&agrave;y da</li>\r\n<li class=\"ez-toc-page-1 ez-toc-heading-level-3\">Bước 2: May v&agrave; sản xuất đế gi&agrave;y</li>\r\n<li class=\"ez-toc-page-1 ez-toc-heading-level-3\">Bước 3: Lắp gi&aacute;p v&agrave; ho&agrave;n thiện</li>\r\n</ul>\r\n</li>\r\n<li class=\"ez-toc-page-1 ez-toc-heading-level-2\">C&ocirc;ng nghệ sản xuất giầy đ&aacute; b&oacute;ng\r\n<ul class=\"ez-toc-list-level-3\">\r\n<li class=\"ez-toc-heading-level-3\">C&ocirc;ng nghệ E.V.A Carbon</li>\r\n<li class=\"ez-toc-page-1 ez-toc-heading-level-3\">C&ocirc;ng nghệ đế gi&agrave;y 2 lớp</li>\r\n<li class=\"ez-toc-page-1 ez-toc-heading-level-3\">C&ocirc;ng nghệ Microfiber</li>\r\n</ul>\r\n</li>\r\n<li class=\"ez-toc-page-1 ez-toc-heading-level-2\">Tiềm lực t&agrave;i ch&iacute;nh &amp; khả năng sản xuất</li>\r\n</ul>\r\n</nav></div>\r\n<h2>Quy tr&igrave;nh sản xuất giầy đ&aacute; b&oacute;ng tại Wika</h2>\r\n<h3>Bước 1: Thiết kế v&agrave; sản xuất gi&agrave;y da</h3>\r\n<p>C&aacute;c miếng da l&agrave;m gi&agrave;y sẽ được cắt ra v&agrave; đ&aacute;nh dấu trong qu&aacute; tr&igrave;nh dập để tr&aacute;nh nhầm lẫn. Một khi c&aacute;c miếng da đ&atilde; được đ&oacute;ng dấu, c&aacute;c điểm tr&ecirc;n mỗi miếng da sau đ&oacute; sẽ được gắn với những miếng da kh&aacute;c cũng được đ&aacute;nh dấu tương tự. Để bước n&agrave;y c&oacute; thể thực hiện dễ d&agrave;ng th&igrave; c&aacute;c cạnh của mỗi mảnh da phải mỏng. C&aacute;c địa điểm cần đục lỗ cũng được đ&aacute;nh dấu. Nếu muốn gi&agrave;y c&oacute; họa tiết đục lỗ trang tr&iacute; phải đ&aacute;nh dấu v&agrave; đục lỗ tr&ecirc;n da trước.</p>\r\n<figure id=\"attachment_322\" class=\"wp-caption aligncenter\" style=\"text-align: center;\" aria-describedby=\"caption-attachment-322\"><img class=\"wp-image-322 size-full entered lazyloaded\" src=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-3_optimized.jpg\" sizes=\"(max-width: 1280px) 100vw, 1280px\" srcset=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-3_optimized.jpg 1280w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-3_optimized-600x338.jpg 600w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-3_optimized-300x169.jpg 300w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-3_optimized-1024x576.jpg 1024w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-3_optimized-768x432.jpg 768w\" alt=\"quy-trinh-san-xuat-giay-da-bong-wika-3_optimized\" width=\"1280\" height=\"720\" data-lazy-srcset=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-3_optimized.jpg 1280w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-3_optimized-600x338.jpg 600w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-3_optimized-300x169.jpg 300w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-3_optimized-1024x576.jpg 1024w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-3_optimized-768x432.jpg 768w\" data-lazy-sizes=\"(max-width: 1280px) 100vw, 1280px\" data-lazy-src=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-3_optimized.jpg\" data-ll-status=\"loaded\" />\r\n<figcaption id=\"caption-attachment-322\" class=\"wp-caption-text\">D&acirc;y chuyền kh&eacute;p k&iacute;n tại xưởng may của Wika</figcaption>\r\n</figure>\r\n<p><strong>Thiết kế v&agrave; t&aacute;ch chi tiết gi&agrave;y</strong>: đ&acirc;y l&agrave; c&ocirc;ng đoạn quan trọng của sản xu&acirc;t gi&agrave;y da. C&aacute;c c&ocirc;ng đoạn sau cũng đều phụ thuộc v&agrave;o qu&aacute; tr&igrave;nh n&agrave;y.</p>\r\n<p><strong>Cắt chi tiết</strong>: &Aacute;p những bản vẽ chi tiết l&ecirc;n bề mặt da thuộc v&agrave; phải cắt tỉa sao cho đ&uacute;ng k&iacute;ch cỡ c&oacute; sẵn. C&ocirc;ng đoạn n&agrave;y đ&ograve;i hỏi một c&aacute;ch tỷ mỉ để đảm bảo độ ch&iacute;nh x&aacute;c về số đo v&agrave; nhằm tiết kiệm da thuộc nhưng vẫn đảm bảo chất lượng k&iacute;ch thước của kiểu d&aacute;ng gi&agrave;y.</p>\r\n<p><strong>D&atilde;y chi tiết</strong>: gh&eacute;p c&aacute;c chi tiết v&agrave;o với nhau sao cho hợp l&yacute; nhất đảm bảo t&iacute;nh thẩm mỹ của gi&agrave;y.</p>\r\n<h3>Bước 2: May v&agrave; sản xuất đế gi&agrave;y</h3>\r\n<p><strong>May c&aacute;c chi tiết</strong>: c&aacute;c chi tiết được may t&aacute;ch biệt nhau sao cho ph&ugrave; hợp với kiểu d&aacute;ng của gi&agrave;y.</p>\r\n<center>\r\n<div class=\"rll-youtube-player\" data-src=\"https://www.youtube.com/embed/8xXXvagaEb0\" data-id=\"8xXXvagaEb0\" data-query=\"\" data-alt=\"YouTube video player\">\r\n<div data-id=\"8xXXvagaEb0\" data-query=\"\" data-src=\"https://www.youtube.com/embed/8xXXvagaEb0\"><img class=\"entered lazyloaded\" src=\"https://i.ytimg.com/vi/8xXXvagaEb0/hqdefault.jpg\" alt=\"YouTube video player\" width=\"480\" height=\"360\" data-lazy-src=\"https://i.ytimg.com/vi/8xXXvagaEb0/hqdefault.jpg\" data-ll-status=\"loaded\" /></div>\r\n</div>\r\n</center><center>May c&aacute;c chi tiết</center>\r\n<p><strong>Ho&agrave;n thiện chi tiết</strong>: C&aacute;c chi tiết sau khi đ&atilde; được thiết kế, cắt, gấp, may. Ch&iacute;nh l&agrave; gh&eacute;p c&aacute;c chi tiết theo bản thiết kế đ&atilde; c&oacute; sẵn.</p>\r\n<figure id=\"attachment_323\" class=\"wp-caption aligncenter\" aria-describedby=\"caption-attachment-323\"><img class=\"wp-image-323 size-full entered lazyloaded\" src=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-4_optimized.jpg\" sizes=\"(max-width: 1280px) 100vw, 1280px\" srcset=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-4_optimized.jpg 1280w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-4_optimized-600x338.jpg 600w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-4_optimized-300x169.jpg 300w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-4_optimized-1024x576.jpg 1024w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-4_optimized-768x432.jpg 768w\" alt=\"quy-trinh-san-xuat-giay-da-bong-wika-4\" width=\"1280\" height=\"720\" data-lazy-srcset=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-4_optimized.jpg 1280w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-4_optimized-600x338.jpg 600w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-4_optimized-300x169.jpg 300w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-4_optimized-1024x576.jpg 1024w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-4_optimized-768x432.jpg 768w\" data-lazy-sizes=\"(max-width: 1280px) 100vw, 1280px\" data-lazy-src=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-4_optimized.jpg\" data-ll-status=\"loaded\" />\r\n<figcaption id=\"caption-attachment-323\" class=\"wp-caption-text\">Đế gi&agrave;y cao su non</figcaption>\r\n</figure>\r\n<p>Trong giai đoạn may, c&aacute;c miếng da đ&atilde; được cắt sẵn ra sẽ được kh&acirc;u với nhau. Đầu ti&ecirc;n, c&aacute;c miếng gh&eacute;p phần tr&ecirc;n sẽ được kh&acirc;u lại, sau đ&oacute; l&agrave; lớp l&oacute;t. Gi&agrave;y được gia cố th&ecirc;m ở phần ng&oacute;n ch&acirc;n v&agrave; đệm l&oacute;t gi&agrave;y. Để tr&aacute;nh việc những mảnh da bị trượt đi, ban đầu ch&uacute;ng được chấm keo l&ecirc;n c&aacute;c cạnh v&agrave; gắn lại với nhau. Phần tr&ecirc;n gi&agrave;y sẽ được kh&acirc;u lại trước, sau đ&oacute; l&agrave; phần l&oacute;t. Sau khi đ&atilde; kh&acirc;u hai phần n&agrave;y, c&aacute;c đường may cũng được l&agrave;m gọn. Đế gi&agrave;y phải trải qua c&ocirc;ng đoạn g&ograve; trước khi đem đi gi&aacute;p v&agrave;o phần mũ gi&agrave;y, thường được l&agrave;m bằng m&aacute;y.</p>\r\n<h3>Bước 3: Lắp gi&aacute;p v&agrave; ho&agrave;n thiện</h3>\r\n<p>Sau khi đế gi&agrave;y đ&atilde; được g&ograve; xong th&igrave; sẽ tiến h&agrave;nh đến phần gi&aacute;p đế. Qu&eacute;t keo l&ecirc;n mặt sau để d&aacute;n v&agrave;o cốt gi&agrave;y. Phần mũ gi&agrave;y v&agrave; phần đế gi&agrave;y sẽ được gi&aacute;p lại với nhau bằng c&aacute;c m&aacute;y chuy&ecirc;n dụng.</p>\r\n<figure id=\"attachment_318\" class=\"wp-caption aligncenter\" aria-describedby=\"caption-attachment-318\"><img class=\"wp-image-318 size-full entered lazyloaded\" src=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-1_optimized.jpg\" sizes=\"(max-width: 1280px) 100vw, 1280px\" srcset=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-1_optimized.jpg 1280w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-1_optimized-600x338.jpg 600w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-1_optimized-300x169.jpg 300w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-1_optimized-1024x576.jpg 1024w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-1_optimized-768x432.jpg 768w\" alt=\"quy-trinh-san-xuat-giay-da-bong-wika-1_optimized\" width=\"1280\" height=\"720\" data-lazy-srcset=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-1_optimized.jpg 1280w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-1_optimized-600x338.jpg 600w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-1_optimized-300x169.jpg 300w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-1_optimized-1024x576.jpg 1024w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-1_optimized-768x432.jpg 768w\" data-lazy-sizes=\"(max-width: 1280px) 100vw, 1280px\" data-lazy-src=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-1_optimized.jpg\" data-ll-status=\"loaded\" />\r\n<figcaption id=\"caption-attachment-318\" class=\"wp-caption-text\">Bộ phận ho&agrave;n thiện sản phẩm</figcaption>\r\n</figure>\r\n<p>Ở mỗi kh&acirc;u kh&aacute;c nhau đều c&oacute; những người thơ đảm nhận nhiệm vụ ri&ecirc;ng của m&igrave;nh. Cuối c&ugrave;ng, bộ phận ho&agrave;n thiện sẽ thực hiện những c&ocirc;ng đoạn cuối như: luồn d&acirc;y gi&agrave;y, kiểm tra đường may, đ&aacute;nh b&oacute;ng .. Th&agrave;nh phẩm sẽ được đ&oacute;ng hộp v&agrave; gửi đến c&aacute;c nh&agrave; ph&acirc;n phối, đại l&yacute;.</p>\r\n<figure id=\"attachment_324\" class=\"wp-caption aligncenter\" aria-describedby=\"caption-attachment-324\"><img class=\"wp-image-324 size-full entered lazyloaded\" src=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-5_optimized.jpg\" sizes=\"(max-width: 1280px) 100vw, 1280px\" srcset=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-5_optimized.jpg 1280w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-5_optimized-600x338.jpg 600w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-5_optimized-300x169.jpg 300w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-5_optimized-1024x576.jpg 1024w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-5_optimized-768x432.jpg 768w\" alt=\"quy-trinh-san-xuat-giay-da-bong-wika-5\" width=\"1280\" height=\"720\" data-lazy-srcset=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-5_optimized.jpg 1280w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-5_optimized-600x338.jpg 600w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-5_optimized-300x169.jpg 300w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-5_optimized-1024x576.jpg 1024w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-5_optimized-768x432.jpg 768w\" data-lazy-sizes=\"(max-width: 1280px) 100vw, 1280px\" data-lazy-src=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-5_optimized.jpg\" data-ll-status=\"loaded\" />\r\n<figcaption id=\"caption-attachment-324\" class=\"wp-caption-text\">Th&agrave;nh phẩm được đ&oacute;ng g&oacute;i full box</figcaption>\r\n</figure>\r\n<h2>C&ocirc;ng nghệ sản xuất giầy đ&aacute; b&oacute;ng</h2>\r\n<p><img class=\"aligncenter wp-image-327 size-full entered lazyloaded\" src=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-8_optimized.jpg\" sizes=\"(max-width: 1280px) 100vw, 1280px\" srcset=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-8_optimized.jpg 1280w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-8_optimized-600x338.jpg 600w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-8_optimized-300x169.jpg 300w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-8_optimized-1024x576.jpg 1024w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-8_optimized-768x432.jpg 768w\" alt=\"quy-trinh-san-xuat-giay-da-bong-wika-8\" width=\"1280\" height=\"720\" data-lazy-srcset=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-8_optimized.jpg 1280w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-8_optimized-600x338.jpg 600w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-8_optimized-300x169.jpg 300w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-8_optimized-1024x576.jpg 1024w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-8_optimized-768x432.jpg 768w\" data-lazy-sizes=\"(max-width: 1280px) 100vw, 1280px\" data-lazy-src=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-8_optimized.jpg\" data-ll-status=\"loaded\" /></p>\r\n<h3>C&ocirc;ng nghệ E.V.A Carbon</h3>\r\n<p>Wika sử dụng c&ocirc;ng nghệ l&oacute;t gi&agrave;y E.V.A Carbon kết hợp với c&aacute;c hạt nhựa đặc biệt gi&uacute;p hấp thụ chấn động cực tốt v&agrave; đ&agrave;n hồi giảm chấn thương, chống trượt, &ecirc;m ch&acirc;n v&agrave; đặc biệt tho&aacute;ng kh&iacute; gi&uacute;p hạn chế mồ h&ocirc;i ch&acirc;n khi chơi thể thao.<img class=\"aligncenter wp-image-328 size-full entered lazyloaded\" src=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-9_optimized.jpg\" sizes=\"(max-width: 1280px) 100vw, 1280px\" srcset=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-9_optimized.jpg 1280w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-9_optimized-600x338.jpg 600w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-9_optimized-300x169.jpg 300w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-9_optimized-1024x576.jpg 1024w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-9_optimized-768x432.jpg 768w\" alt=\"quy-trinh-san-xuat-giay-da-bong-wika-9\" width=\"1280\" height=\"720\" data-lazy-srcset=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-9_optimized.jpg 1280w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-9_optimized-600x338.jpg 600w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-9_optimized-300x169.jpg 300w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-9_optimized-1024x576.jpg 1024w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-9_optimized-768x432.jpg 768w\" data-lazy-sizes=\"(max-width: 1280px) 100vw, 1280px\" data-lazy-src=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-9_optimized.jpg\" data-ll-status=\"loaded\" /></p>\r\n<h3>C&ocirc;ng nghệ đế gi&agrave;y 2 lớp</h3>\r\n<p><img class=\"aligncenter wp-image-325 size-full entered lazyloaded\" src=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-10_optimized.jpg\" sizes=\"(max-width: 1280px) 100vw, 1280px\" srcset=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-10_optimized.jpg 1280w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-10_optimized-600x338.jpg 600w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-10_optimized-300x169.jpg 300w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-10_optimized-1024x576.jpg 1024w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-10_optimized-768x432.jpg 768w\" alt=\"quy-trinh-san-xuat-giay-da-bong-wika-10\" width=\"1280\" height=\"720\" data-lazy-srcset=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-10_optimized.jpg 1280w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-10_optimized-600x338.jpg 600w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-10_optimized-300x169.jpg 300w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-10_optimized-1024x576.jpg 1024w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-10_optimized-768x432.jpg 768w\" data-lazy-sizes=\"(max-width: 1280px) 100vw, 1280px\" data-lazy-src=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-10_optimized.jpg\" data-ll-status=\"loaded\" /></p>\r\n<p>Đế gi&agrave;y cao su 2 lớp được Wika thiết kế lần đầu ti&ecirc;n tại Việt Nam gi&uacute;p việc di chuyển tr&ecirc;n s&acirc;n linh hoạt, mềm mại hơn. Form gi&agrave;y chuẩn Việt cực &ocirc;m ch&acirc;n hỗ trợ khả năng tăng tốc, xoay sở trong phạm vi hẹp, giảm chấn thương.</p>\r\n<h3>C&ocirc;ng nghệ Microfiber</h3>\r\n<p>Mũi gi&agrave;y sử dụng c&ocirc;ng nghệ da Microfiber, l&agrave; chất liệu cao cấp nhất tr&ecirc;n thị trường gi&agrave;y đ&aacute; b&oacute;ng hiện nay (vượt xa so với chất liệu PU loại 1,2,3,4). Microfiber thực chất l&agrave; một loại sợi c&oacute; cấu tr&uacute;c rất nhỏ, chỉ bằng 1/5 đường k&iacute;nh sợi t&oacute;c của ch&uacute;ng ta, được tạo ra từ 2 chất Polyester v&agrave; Polyamide n&ecirc;n đ&atilde; thừa hưởng được những ưu điểm của 2 loại sợi n&agrave;y.</p>\r\n<p><img class=\"wp-image-326 size-full aligncenter entered lazyloaded\" src=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-7_optimized.jpg\" sizes=\"(max-width: 1280px) 100vw, 1280px\" srcset=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-7_optimized.jpg 1280w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-7_optimized-600x338.jpg 600w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-7_optimized-300x169.jpg 300w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-7_optimized-1024x576.jpg 1024w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-7_optimized-768x432.jpg 768w\" alt=\"quy-trinh-san-xuat-giay-da-bong-wika-7\" width=\"1280\" height=\"720\" data-lazy-srcset=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-7_optimized.jpg 1280w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-7_optimized-600x338.jpg 600w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-7_optimized-300x169.jpg 300w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-7_optimized-1024x576.jpg 1024w, https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-7_optimized-768x432.jpg 768w\" data-lazy-sizes=\"(max-width: 1280px) 100vw, 1280px\" data-lazy-src=\"https://wikasports.com/wp-content/uploads/2021/06/quy-trinh-san-xuat-giay-da-bong-wika-7_optimized.jpg\" data-ll-status=\"loaded\" /></p>\r\n<p>Nếu như Polyester mang lại độ bền v&agrave; độ cứng cần thiết th&igrave; sợi Polyamide cung cấp khả năng hấp thụ chấn động cho chất liệu n&agrave;y. Sợi Microfiber thể hiện m&igrave;nh c&oacute; rất nhiều c&aacute;c t&iacute;nh năng từ sự mềm dẻo, hấp thụ đến khả năng chống thấm nước, tĩnh điện v&agrave; lọc khuẩn v&agrave; l&agrave; chất liệu l&yacute; tưởng để tạo ra một đ&ocirc;i gi&agrave;y ho&agrave;n hảo gi&uacute;p bạn thể hiện được tối đa kỹ năng tr&ecirc;n s&acirc;n cỏ.</p>\r\n<h2>Tiềm lực t&agrave;i ch&iacute;nh &amp; khả năng sản xuất</h2>\r\n<p><strong>Wika</strong>&nbsp;l&agrave; một thương hiệu của Cty TNHH TM &amp; SX Thể Thao Ho&agrave;ng Phong, một trong những doanh nghiệp đứng đầu ng&agrave;nh c&ocirc;ng nghiệp gi&agrave;y tại Việt Nam.</p>\r\n<p>Với số vốn đầu tư ban đầu l&agrave; 500.000 USD cho đến nay tổng số vốn doanh nghiệp hiện c&oacute; đạt 20 triệu USD v&agrave; gần 20 năm kinh nghiệm.&nbsp;</p>\r\n<p><strong>Wika</strong>&nbsp;c&oacute; nh&agrave; m&aacute;y sản xuất tại Việt Nam với tầm nh&igrave;n, năng lực ti&ecirc;u chuẩn quốc tế v&agrave; chiến lược kinh doanh lu&ocirc;n lấy lợi &iacute;ch kh&aacute;ch h&agrave;ng l&agrave;m ưu ti&ecirc;n h&agrave;ng đầu. Năng lực sản xuất quy m&ocirc; lớn: sở hữu d&acirc;y chuyền sản xuất kh&eacute;p k&iacute;n, chuy&ecirc;n nghiệp, c&ocirc;ng nghệ cao. Nguồn nh&acirc;n lực dồi d&agrave;o, đam m&ecirc;, đo&agrave;n kết v&agrave; s&aacute;ng tạo với 10.000 c&aacute;n bộ, c&ocirc;ng nh&acirc;n vi&ecirc;n v&agrave; 8 ph&acirc;n xưởng, 20 d&acirc;y chuyền sản xuất với năng lực hiện tại 10.000 đ&ocirc;i gi&agrave;y/ ng&agrave;y.</p>\r\n<p>Tr&ecirc;n đ&acirc;y, c&aacute;c bạn đ&atilde; kh&aacute;m ph&aacute; ra 3 c&ocirc;ng đoạn để sản xuất ra 1 chiếc&nbsp;<strong>giầy đ&aacute; b&oacute;ng</strong>&nbsp;ho&agrave;n chỉnh, th&ecirc;m v&agrave;o đ&oacute; l&agrave; c&aacute;c c&ocirc;ng nghệ hiện đại m&agrave; Wika đ&atilde; sử dụng. Nếu thấy hay h&atilde;y chia sẻ v&agrave; ủng hộ&nbsp;sản phẩm gi&agrave;y đ&aacute; b&oacute;ng&nbsp;tại Wika nha!</p>\r\n</div>\r\n</blockquote>','2025-09-01 21:03:19.096135','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777608359/es5ozvjvjxlmut8sgy39.jpg','',0,'Quy trình sản xuất giày đá bóng tại Wika như thế nào?','quy-trinh-san-xuat-giay-a-bong-tai-wika-nhu-the-nao','Quy trình sản xuất giày đá bóng tại Wika như thế nào?','2026-05-01 11:20:41.986054',NULL),(14,'<section class=\"right-content col-lg-9 col-12 mx-auto\">\r\n<article class=\"article-main\">\r\n<div class=\"article-details\">\r\n<div class=\"article-content js-toc-content\">\r\n<div id=\"ega-uti-editable-content\" class=\"rte\" data-platform=\"haravan\" data-id=\"1002742863\" data-blog-id=\"1000950832\">\r\n<blockquote>\r\n<h1 style=\"text-align: center;\">GI&Agrave;Y Đ&Aacute; B&Oacute;NG JOMA TOP FLEX: CHỌN SAO CHO Đ&Uacute;NG?</h1>\r\n<div class=\"art-body\">\r\n<div class=\"art-summary\">&nbsp;</div>\r\n<div class=\"art-date\">12/04/2026</div>\r\n<div class=\"art-text\">\r\n<p>Trong Futsal, c&aacute;i t&ecirc;n&nbsp;Joma Top Flex từ l&acirc;u đ&atilde; trở th&agrave;nh biểu tượng của sự bền bỉ v&agrave; thoải m&aacute;i. Tuy nhi&ecirc;n, với sự đa dạng của c&aacute;c phi&ecirc;n bản hiện nay, kh&ocirc;ng &iacute;t anh em cảm thấy ph&acirc;n v&acirc;n khi lựa chọn.</p>\r\n<p>Trước khi quyết định \"xuống tiền\" cho c&aacute;c mẫu gi&agrave;y s&acirc;n s&agrave;n Joma y&ecirc;u th&iacute;ch, h&atilde;y c&ugrave;ng Beyond điểm qua 3 lưu &yacute; mấu chốt dưới đ&acirc;y để chọn được đ&ocirc;i gi&agrave;y đ&aacute; b&oacute;ng chuẩn nhất cho đ&ocirc;i ch&acirc;n của m&igrave;nh.</p>\r\n<h3><strong>1. Ph&acirc;n cấp c&aacute;c phi&ecirc;n bản của gi&agrave;y đ&aacute; b&oacute;ng&nbsp;Joma Top Flex</strong></h3>\r\n<p>Thương hiệu đến từ T&acirc;y Ban Nha đ&atilde; rất t&acirc;m l&yacute; khi chia d&ograve;ng gi&agrave;y Futsal Joma Top Flex th&agrave;nh nhiều ph&acirc;n kh&uacute;c dựa tr&ecirc;n phần đệm l&oacute;t:</p>\r\n<ul>\r\n<li>\r\n<p><strong>Joma Top Flex (Bản thường)</strong>: Đ&acirc;y l&agrave; phi&ecirc;n bản cơ bản v&agrave; kinh điển nhất. Gi&agrave;y sở hữu upper từ da heo hoặc da nh&acirc;n tạo, đi c&ugrave;ng bộ đệm EVA truyền thống mang lại sự linh hoạt tối đa.</p>\r\n</li>\r\n<li>\r\n<p><strong>Joma Top Flex Rebound</strong>: Giữ nguy&ecirc;n c&aacute;c ưu điểm về phom d&aacute;ng của bản thường nhưng được n&acirc;ng cấp bộ đệm Rebound. Điều n&agrave;y mang lại cảm gi&aacute;c &ecirc;m &aacute;i v&agrave; độ đ&agrave;n hồi tốt hơn hẳn trong từng bước chạy.</p>\r\n</li>\r\n<li>\r\n<p><strong>Joma Top Flex Plus</strong>: Tiếp tục đẩy mạnh khả năng giảm chấn với bộ đệm d&agrave;y dặn, gi&uacute;p bảo vệ khớp gối tuyệt vời cho những anh em c&oacute; cường độ thi đấu cao.</p>\r\n</li>\r\n<li>\r\n<p><strong>Joma Top Flex Ultimate</strong>: Đ&acirc;y l&agrave; phi&ecirc;n bản cao cấp nhất hiện tại. Mẫu gi&agrave;y Futsal Joma n&agrave;y hội tụ đầy đủ những c&ocirc;ng nghệ t&acirc;n tiến nhất, mang đến hiệu năng thi đấu đỉnh cao.</p>\r\n</li>\r\n</ul>\r\n<div>\r\n<p><img class=\"dt-width-auto\" src=\"https://cdn.hstatic.net/200000278317/file/ong-joma-top-flex-chon-sao-cho-dung-1_c09b8aa7a4774cc08638c487cf13f01f.jpg\" alt=\"GI&Agrave;Y Đ&Aacute; B&Oacute;NG JOMA TOP FLEX: CHỌN SAO CHO Đ&Uacute;NG?\" width=\"600\" height=\"600\" /></p>\r\n</div>\r\n<h3><strong>2. Độ cao đế gi&agrave;y - Yếu tố quyết định cảm gi&aacute;c b&oacute;ng</strong></h3>\r\n<p>Độ cao đế l&agrave; điểm cực kỳ quan trọng, ảnh hưởng trực tiếp đến cảm gi&aacute;c chạm b&oacute;ng v&agrave; khả năng xoay trở của anh em tr&ecirc;n mặt s&acirc;n s&agrave;n.</p>\r\n<ul>\r\n<li>\r\n<p>Thứ tự độ cao từ thấp đến cao:&nbsp;<strong>Bản Thường &lt; Ultimate &lt; Rebound &lt; Plu</strong>s (cao nhất).</p>\r\n</li>\r\n<li>\r\n<p>Lựa chọn theo lối chơi: Nếu anh em th&iacute;ch cảm gi&aacute;c đế mỏng, dễ v&ecirc; gầm v&agrave; trọng t&acirc;m thấp để tiếp x&uacute;c gần mặt s&acirc;n, th&igrave; gi&agrave;y đ&aacute; b&oacute;ng Futsal Joma Top Flex bản thường v&agrave; Ultimate ch&iacute;nh l&agrave; \"ch&acirc;n &aacute;i\".</p>\r\n</li>\r\n<li>\r\n<p>Hỗ trợ khớp gối: Ngược lại, nếu anh em cần một bộ đệm d&agrave;y để hỗ trợ giảm chấn cho khớp gối trong c&aacute;c pha bứt tốc hay đặt trụ xoay trở, th&igrave; Rebound v&agrave; Plus sẽ l&agrave; lựa chọn tối ưu nhất.</p>\r\n</li>\r\n</ul>\r\n<div>\r\n<p><img class=\"dt-width-auto\" src=\"https://cdn.hstatic.net/200000278317/file/ong-joma-top-flex-chon-sao-cho-dung-2_a52bcd5c712e4249a283ac64c5efb768.jpg\" alt=\"GI&Agrave;Y Đ&Aacute; B&Oacute;NG JOMA TOP FLEX: CHỌN SAO CHO Đ&Uacute;NG?\" width=\"600\" height=\"600\" /></p>\r\n</div>\r\n<h3><strong>3. Form d&aacute;ng v&agrave; độ &ocirc;m ch&acirc;n thực tế</strong></h3>\r\n<p>D&ugrave; cả 4 phi&ecirc;n bản đều được mệnh danh l&agrave; \"cứu tinh\" cho anh em ch&acirc;n b&egrave;, nhưng cảm gi&aacute;c thực tế của d&ograve;ng gi&agrave;y Futsal Joma Top Flex vẫn c&oacute; sự kh&aacute;c biệt nhỏ:</p>\r\n<ul>\r\n<li>\r\n<p><strong>Bản Thường, Rebound v&agrave; Plus</strong>: Ba phi&ecirc;n bản n&agrave;y c&oacute; phom d&aacute;ng kh&aacute; tương đồng, mang lại cảm gi&aacute;c cực kỳ thoải m&aacute;i v&agrave; tho&aacute;ng ch&acirc;n, đặc biệt ph&ugrave; hợp cho những ai c&oacute; b&agrave;n ch&acirc;n to ngang đặc trưng của người Việt.</p>\r\n</li>\r\n<li>\r\n<p><strong>Bản Ultimate</strong>: D&ugrave; vẫn d&agrave;nh cho ch&acirc;n b&egrave; nhưng thiết kế của Ultimate c&oacute; phần thon gọn v&agrave; hiện đại hơn. N&oacute; mang lại độ &ocirc;m ch&acirc;n kh&iacute;t hơn một ch&uacute;t so với 3 phi&ecirc;n bản c&ograve;n lại, ph&ugrave; hợp cho anh em th&iacute;ch sự gọn g&agrave;ng nhưng vẫn kh&ocirc;ng bị b&oacute; tức.</p>\r\n</li>\r\n</ul>\r\n<div>\r\n<p><img class=\"dt-width-auto\" src=\"https://cdn.hstatic.net/200000278317/file/ong-joma-top-flex-chon-sao-cho-dung-3_10dec36ae86c4807a4be72ceb647b908.jpg\" alt=\"GI&Agrave;Y Đ&Aacute; B&Oacute;NG JOMA TOP FLEX: CHỌN SAO CHO Đ&Uacute;NG?\" width=\"600\" height=\"600\" /></p>\r\n</div>\r\n<h3><strong>KẾT LUẬN</strong></h3>\r\n<p>D&ograve;ng gi&agrave;y Futsal&nbsp;Joma n&oacute;i chung v&agrave; c&aacute;c silo Top Flex n&oacute;i ri&ecirc;ng vẫn lu&ocirc;n l&agrave; lựa chọn h&agrave;ng đầu nhờ sự đa dạng v&agrave; chất lượng vượt trội. Hy vọng b&agrave;i viết n&agrave;y đ&atilde; gi&uacute;p anh em hiểu r&otilde; hơn về c&aacute;c ph&acirc;n kh&uacute;c của gi&agrave;y đ&aacute; b&oacute;ng Futsal Joma Top Flex để tự tin chốt đơn đ&ocirc;i gi&agrave;y ph&ugrave; hợp nhất.</p>\r\n<p>Gh&eacute; ngay Beyond để trải nghiệm thực tế v&agrave; nhận tư vấn chi tiết nhất nh&eacute;!</p>\r\n<p>Được ra đời từ năm 2013,&nbsp;Beyond&nbsp;tự h&agrave;o l&agrave; một trong những nh&agrave; b&aacute;n lẻ h&agrave;ng đầu trong mảng sản phẩm gi&agrave;y đ&aacute; b&oacute;ng ch&iacute;nh h&atilde;ng tại Việt Nam.&nbsp;</p>\r\n<p>Đội ngũ Beyond đ&atilde; v&agrave; đang nỗ lực nhằm đem lại cho kh&aacute;ch h&agrave;ng những trải nghiệm tốt nhất về chất lượng sản phẩm v&agrave; dịch vụ, cũng như đưa ra những tư vấn tận t&acirc;m để kh&aacute;ch h&agrave;ng c&oacute; thể chọn lựa được cho m&igrave;nh những đ&ocirc;i gi&agrave;y đ&aacute; banh ph&ugrave; hợp nhất, ưng &yacute; nhất mỗi khi ra s&acirc;n.</p>\r\n<p>Đối với mỗi đ&ocirc;i&nbsp;gi&agrave;y đ&aacute; b&oacute;ng&nbsp;mua tại Beyond, anh em sẽ được tặng 1 balo mini đựng gi&agrave;y, 1 đ&ocirc;i tất đ&aacute; b&oacute;ng hoặc 1 &aacute;o mưa mang nh&atilde;n hiệu THF.</p>\r\n<p>Ngo&agrave;i ra, Beyond c&ograve;n hỗ trợ trả g&oacute;p tại cửa h&agrave;ng hoặc online th&ocirc;ng qua Fundiin.</p>\r\n<p>Đối với c&aacute;c đơn gi&agrave;y đ&aacute; banh đặt mua online, Beyond hỗ trợ giao h&agrave;ng tận nơi v&agrave; freeship to&agrave;n quốc.</p>\r\n</div>\r\n</div>\r\n</blockquote>\r\n</div>\r\n</div>\r\n</div>\r\n</article>\r\n</section>','2025-09-03 14:15:40.685581','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777608024/o0njgls0oypukek3asai.jpg','',0,'GIÀY ĐÁ BÓNG JOMA TOP FLEX: CHỌN SAO CHO ĐÚNG?','giay-a-bong-joma-top-flex-chon-sao-cho-ung','GIÀY ĐÁ BÓNG JOMA TOP FLEX: CHỌN SAO CHO ĐÚNG?','2026-05-01 11:20:16.359025',NULL),(15,'<h1 style=\"text-align: center;\">Nike Air Zoom Mercurial Cosmic Speed : Sự trở lại đầy b&ugrave;ng nổ</h1>\r\n<div class=\"title-main-home\">\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20241120_iWwnRQ4Y.jpg\" alt=\"20241120_iWwnRQ4Y.jpg\" width=\"1000\" height=\"573\" /></figure>\r\n<p>Sau khi d&ograve;ng&nbsp;<strong>Dream Speed</strong>&nbsp;kh&eacute;p lại h&agrave;nh tr&igrave;nh lừng lẫy từ năm 2019, Nike kh&ocirc;ng để người h&acirc;m mộ phải chờ l&acirc;u khi ngay lập tức cho ra mắt bộ sưu tập mới đầy t&aacute;o bạo mang t&ecirc;n<strong>&nbsp;Mercurial Cosmic Speed</strong>. Được ra mắt v&agrave;o th&aacute;ng 9 năm nay,&nbsp;<strong>Nike Air Zoom Cosmic Speed</strong>&nbsp;nhanh ch&oacute;ng trở th&agrave;nh biểu tượng mới, kế thừa v&agrave; ph&aacute;t triển những gi&aacute; trị tinh hoa của d&ograve;ng&nbsp;<strong>Mercurial</strong>&nbsp;huyền thoại, đặc biệt l&agrave; kế thừa MDS để trở th&agrave;nh một trong những biểu tượng kinh điển của d&ograve;ng gi&agrave;y b&oacute;ng đ&aacute; tốc độ.</p>\r\n<p>Thế hệ thứ hai của&nbsp;<strong>Cosmic Speed</strong>&nbsp;đ&atilde; ch&iacute;nh thức tr&igrave;nh l&agrave;ng với hai phối m&agrave;u độc đ&aacute;o d&agrave;nh cho&nbsp;<strong>Air Zoom Mercurial Vapor 16</strong><strong>&nbsp;</strong>v&agrave;&nbsp;<strong>Superfly 10</strong>, hứa hẹn sẽ khuấy đảo s&acirc;n cỏ to&agrave;n cầu với thiết kế đột ph&aacute; v&agrave; c&ocirc;ng nghệ ti&ecirc;n tiến.</p>\r\n<h2>Sự chuyển giao từ&nbsp;<strong>Dream Speed</strong>&nbsp;sang&nbsp;<strong>Cosmic Speed</strong></h2>\r\n<p style=\"text-align: center;\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20241120_FiA01wu5.jpg\" alt=\"Dream Speed sang Cosmic Speed 1\" width=\"1000\" height=\"573\" /></p>\r\n<p style=\"text-align: center;\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20241120_Ao7muYvI.jpg\" alt=\"Dream Speed sang Cosmic Speed 2\" width=\"1000\" height=\"573\" /></p>\r\n<p>D&ograve;ng&nbsp;<strong>Dream Speed</strong>&nbsp;từng l&agrave; biểu tượng đặc biệt d&agrave;nh cho Nike Mercurial từ năm 2019, với mỗi phi&ecirc;n bản đều mang đến thiết kế ri&ecirc;ng biệt, nổi bật v&agrave; đậm chất s&aacute;ng tạo. Từ đ&ocirc;i Dream Speed 001 đầu ti&ecirc;n đến phi&ecirc;n bản Dream Speed 009 kh&eacute;p lại chu kỳ v&agrave;o th&aacute;ng 11 năm nay, d&ograve;ng sản phẩm n&agrave;y lu&ocirc;n đồng h&agrave;nh c&ugrave;ng những ng&ocirc;i sao tốc độ h&agrave;ng đầu thế giới như&nbsp;<strong>Cristiano Ronaldo</strong>&nbsp;hay&nbsp;<strong>Kylian Mbappe</strong>.</p>\r\n<p>Tuy nhi&ecirc;n, sự ra đời của Cosmic Speed kh&ocirc;ng chỉ l&agrave; một bước chuyển m&igrave;nh m&agrave; c&ograve;n l&agrave; minh chứng cho khả năng s&aacute;ng tạo kh&ocirc;ng ngừng của Nike. Phi&ecirc;n bản đầu ti&ecirc;n của bộ sưu tập Cosmic Speed đ&atilde; g&acirc;y ch&uacute; &yacute; với phong c&aacute;ch tối giản, &aacute;nh kim đặc trưng. Tuy nhi&ecirc;n, sang tới phối m&agrave;u lần n&agrave;y, Nike lại b&ugrave;ng nổ bằng c&aacute;ch mang đến c&aacute;c phối m&agrave;u rực rỡ, tri &acirc;n những huyền thoại của Mercurial nhưng vẫn giữ n&eacute;t đương đại đầy cuốn h&uacute;t.</p>\r\n<hr />\r\n<div class=\"elfsight-app-fbb3cf8a-c3a2-4c1e-9c9b-cd027da02df5\" data-miwrid=\"a8dc074a-dfd8-41f7-860e-c7a2914f36fb\">\r\n<div id=\"eapps-photo-gallery-fbb3cf8a-c3a2-4c1e-9c9b-cd027da02df5\" class=\"widget__RootComponent-sc-5c2dec5b-0 lgONPl RootLayout__RootComponent-sc eapps-photo-gallery-fbb3cf8a-c3a2-4c1e-9c9b-cd027da02df5-custom-css-root\">\r\n<div class=\"EmbedRoot__Root-sc-615452d5-0 hnFxvH es-embed-root widget__StyledEmbedRoot-sc-5c2dec5b-2 bmFbzV eapp-photo-gallery-photo-gallery-component\">\r\n<div class=\"widget__HeadingContainer-sc-5c2dec5b-1 ffHmuR eapp-photo-gallery-photo-gallery-heading\" style=\"text-align: center;\"><strong>NIKE MERCURIAL</strong></div>\r\n<div>\r\n<div class=\"Masonry__Container-sc-74f10eca-0 daqNnz eapp-photo-gallery-masonry-component\">\r\n<div class=\"ItemGrid__Grid-sc-b8313d44-0 eNUwyX eapp-photo-gallery-item-grid-component\">\r\n<div class=\"MasonryItem__Item-sc-a17d32ab-0 kXgGzo eapp-photo-gallery-masonry-item-item\" style=\"text-align: center;\">\r\n<div class=\"MasonryItem__Content-sc-a17d32ab-1 gBvKHj eapp-photo-gallery-masonry-item-content\">\r\n<div class=\"ItemData__Container-sc-fe2b9e06-4 lfFjav eapp-photo-gallery-item-data-component\" tabindex=\"0\" role=\"button\" aria-label=\"Visit linked content\">\r\n<div class=\"ItemData__ImageContainer-sc-fe2b9e06-5 KVTni eapp-photo-gallery-item-data-imageContainer eapp-photo-gallery-masonry-item-imageContainer\">\r\n<div class=\"ItemData__ImageBackground-sc-fe2b9e06-1 NBKrO eapp-photo-gallery-item-data-imageBackground\">&nbsp;</div>\r\n</div>\r\n<div class=\"WatermarkLogo__Wrapper-sc-98c7adfb-0 jyOHFJ eapp-photo-gallery-item-data-watermarkLogoWrapper\">\r\n<div class=\"WatermarkLogo__LogoContainer-sc-98c7adfb-1 fYgucl eapp-photo-gallery-item-data-watermarkLogo eapp-photo-gallery-item-data-watermarkPosition-undefined\">&nbsp;</div>\r\n</div>\r\n<div class=\"ItemData__InfoWrapper-sc-fe2b9e06-2 dITMsh eapp-photo-gallery-item-data-info\">\r\n<div class=\"Info__Container-sc-13d2405c-0 cSRluY eapp-photo-gallery-info-component\">\r\n<div class=\"Info__Title-sc-13d2405c-1 DwfVd eapp-photo-gallery-info-title\">Mercurial Vapor 16 Pro TF - Trắng/Xanh - FQ8687 - 400</div>\r\n<div class=\"Info__Description-sc-13d2405c-2 hHHVyA eapp-photo-gallery-info-description\">2.520.000đ</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"MasonryItem__Item-sc-a17d32ab-0 kXgGzo eapp-photo-gallery-masonry-item-item\" style=\"text-align: center;\">\r\n<div class=\"MasonryItem__Content-sc-a17d32ab-1 gBvKHj eapp-photo-gallery-masonry-item-content\">\r\n<div class=\"ItemData__Container-sc-fe2b9e06-4 lfFjav eapp-photo-gallery-item-data-component\" tabindex=\"0\" role=\"button\" aria-label=\"Visit linked content\">\r\n<div class=\"ItemData__ImageContainer-sc-fe2b9e06-5 KVTni eapp-photo-gallery-item-data-imageContainer eapp-photo-gallery-masonry-item-imageContainer\">\r\n<div class=\"ItemData__ImageBackground-sc-fe2b9e06-1 NBKrO eapp-photo-gallery-item-data-imageBackground\">&nbsp;</div>\r\n</div>\r\n<div class=\"WatermarkLogo__Wrapper-sc-98c7adfb-0 jyOHFJ eapp-photo-gallery-item-data-watermarkLogoWrapper\">\r\n<div class=\"WatermarkLogo__LogoContainer-sc-98c7adfb-1 fYgucl eapp-photo-gallery-item-data-watermarkLogo eapp-photo-gallery-item-data-watermarkPosition-undefined\">&nbsp;</div>\r\n</div>\r\n<div class=\"ItemData__InfoWrapper-sc-fe2b9e06-2 dITMsh eapp-photo-gallery-item-data-info\">\r\n<div class=\"Info__Container-sc-13d2405c-0 cSRluY eapp-photo-gallery-info-component\">\r\n<div class=\"Info__Title-sc-13d2405c-1 DwfVd eapp-photo-gallery-info-title\">Vapor 16 Pro tf - Xanh dạ quang - FQ8687 - 700</div>\r\n<div class=\"Info__Description-sc-13d2405c-2 hHHVyA eapp-photo-gallery-info-description\">2,450,000đ</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"MasonryItem__Item-sc-a17d32ab-0 kXgGzo eapp-photo-gallery-masonry-item-item\" style=\"text-align: center;\">\r\n<div class=\"MasonryItem__Content-sc-a17d32ab-1 gBvKHj eapp-photo-gallery-masonry-item-content\">\r\n<div class=\"ItemData__Container-sc-fe2b9e06-4 lfFjav eapp-photo-gallery-item-data-component\" tabindex=\"0\" role=\"button\" aria-label=\"Visit linked content\">\r\n<div class=\"ItemData__ImageContainer-sc-fe2b9e06-5 KVTni eapp-photo-gallery-item-data-imageContainer eapp-photo-gallery-masonry-item-imageContainer\">\r\n<div class=\"ItemData__ImageBackground-sc-fe2b9e06-1 NBKrO eapp-photo-gallery-item-data-imageBackground\">&nbsp;</div>\r\n</div>\r\n<div class=\"WatermarkLogo__Wrapper-sc-98c7adfb-0 jyOHFJ eapp-photo-gallery-item-data-watermarkLogoWrapper\">\r\n<div class=\"WatermarkLogo__LogoContainer-sc-98c7adfb-1 fYgucl eapp-photo-gallery-item-data-watermarkLogo eapp-photo-gallery-item-data-watermarkPosition-undefined\">&nbsp;</div>\r\n</div>\r\n<div class=\"ItemData__InfoWrapper-sc-fe2b9e06-2 dITMsh eapp-photo-gallery-item-data-info\">\r\n<div class=\"Info__Container-sc-13d2405c-0 cSRluY eapp-photo-gallery-info-component\">\r\n<div class=\"Info__Title-sc-13d2405c-1 DwfVd eapp-photo-gallery-info-title\">Vapor 16 Academy tf - Trắng/Xanh - FQ8449 - 400</div>\r\n<div class=\"Info__Description-sc-13d2405c-2 hHHVyA eapp-photo-gallery-info-description\">1.720.000đ</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"MasonryItem__Item-sc-a17d32ab-0 kXgGzo eapp-photo-gallery-masonry-item-item\" style=\"text-align: center;\">\r\n<div class=\"MasonryItem__Content-sc-a17d32ab-1 gBvKHj eapp-photo-gallery-masonry-item-content\">\r\n<div class=\"ItemData__Container-sc-fe2b9e06-4 lfFjav eapp-photo-gallery-item-data-component\" tabindex=\"0\" role=\"button\" aria-label=\"Visit linked content\">\r\n<div class=\"ItemData__ImageContainer-sc-fe2b9e06-5 KVTni eapp-photo-gallery-item-data-imageContainer eapp-photo-gallery-masonry-item-imageContainer\">\r\n<div class=\"ItemData__ImageBackground-sc-fe2b9e06-1 NBKrO eapp-photo-gallery-item-data-imageBackground\">&nbsp;</div>\r\n</div>\r\n<div class=\"WatermarkLogo__Wrapper-sc-98c7adfb-0 jyOHFJ eapp-photo-gallery-item-data-watermarkLogoWrapper\">\r\n<div class=\"WatermarkLogo__LogoContainer-sc-98c7adfb-1 fYgucl eapp-photo-gallery-item-data-watermarkLogo eapp-photo-gallery-item-data-watermarkPosition-undefined\">&nbsp;</div>\r\n</div>\r\n<div class=\"ItemData__InfoWrapper-sc-fe2b9e06-2 dITMsh eapp-photo-gallery-item-data-info\">\r\n<div class=\"Info__Container-sc-13d2405c-0 cSRluY eapp-photo-gallery-info-component\">\r\n<div class=\"Info__Title-sc-13d2405c-1 DwfVd eapp-photo-gallery-info-title\">Mercurial Vapor 16 Academy KM tf FQ8384-800</div>\r\n<div class=\"Info__Description-sc-13d2405c-2 hHHVyA eapp-photo-gallery-info-description\">1.830.000đ</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"MasonryItem__Item-sc-a17d32ab-0 kXgGzo eapp-photo-gallery-masonry-item-item\" style=\"text-align: center;\">\r\n<div class=\"MasonryItem__Content-sc-a17d32ab-1 gBvKHj eapp-photo-gallery-masonry-item-content\">\r\n<div class=\"ItemData__Container-sc-fe2b9e06-4 lfFjav eapp-photo-gallery-item-data-component\" tabindex=\"0\" role=\"button\" aria-label=\"Visit linked content\">\r\n<div class=\"ItemData__ImageContainer-sc-fe2b9e06-5 KVTni eapp-photo-gallery-item-data-imageContainer eapp-photo-gallery-masonry-item-imageContainer\">\r\n<div class=\"ItemData__ImageBackground-sc-fe2b9e06-1 NBKrO eapp-photo-gallery-item-data-imageBackground\">&nbsp;</div>\r\n</div>\r\n<div class=\"WatermarkLogo__Wrapper-sc-98c7adfb-0 jyOHFJ eapp-photo-gallery-item-data-watermarkLogoWrapper\">\r\n<div class=\"WatermarkLogo__LogoContainer-sc-98c7adfb-1 fYgucl eapp-photo-gallery-item-data-watermarkLogo eapp-photo-gallery-item-data-watermarkPosition-undefined\">&nbsp;</div>\r\n</div>\r\n<div class=\"ItemData__InfoWrapper-sc-fe2b9e06-2 dITMsh eapp-photo-gallery-item-data-info\">\r\n<div class=\"Info__Container-sc-13d2405c-0 cSRluY eapp-photo-gallery-info-component\">\r\n<div class=\"Info__Title-sc-13d2405c-1 DwfVd eapp-photo-gallery-info-title\">Mercurial Superfly 10 Academy - FQ8331-400</div>\r\n<div class=\"Info__Description-sc-13d2405c-2 hHHVyA eapp-photo-gallery-info-description\">2,050,000đ</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"MasonryItem__Item-sc-a17d32ab-0 kXgGzo eapp-photo-gallery-masonry-item-item\" style=\"text-align: center;\">\r\n<div class=\"MasonryItem__Content-sc-a17d32ab-1 gBvKHj eapp-photo-gallery-masonry-item-content\">\r\n<div class=\"ItemData__Container-sc-fe2b9e06-4 lfFjav eapp-photo-gallery-item-data-component\" tabindex=\"0\" role=\"button\" aria-label=\"Visit linked content\">\r\n<div class=\"ItemData__ImageContainer-sc-fe2b9e06-5 KVTni eapp-photo-gallery-item-data-imageContainer eapp-photo-gallery-masonry-item-imageContainer\">\r\n<div class=\"ItemData__ImageBackground-sc-fe2b9e06-1 NBKrO eapp-photo-gallery-item-data-imageBackground\">&nbsp;</div>\r\n</div>\r\n<div class=\"WatermarkLogo__Wrapper-sc-98c7adfb-0 jyOHFJ eapp-photo-gallery-item-data-watermarkLogoWrapper\">\r\n<div class=\"WatermarkLogo__LogoContainer-sc-98c7adfb-1 fYgucl eapp-photo-gallery-item-data-watermarkLogo eapp-photo-gallery-item-data-watermarkPosition-undefined\">&nbsp;</div>\r\n</div>\r\n<div class=\"ItemData__InfoWrapper-sc-fe2b9e06-2 dITMsh eapp-photo-gallery-item-data-info\">\r\n<div class=\"Info__Container-sc-13d2405c-0 cSRluY eapp-photo-gallery-info-component\">\r\n<div class=\"Info__Title-sc-13d2405c-1 DwfVd eapp-photo-gallery-info-title\">Mercurial Vapor 15 Pro tf - V&agrave;ng/Đen - DJ5605 - 700</div>\r\n<div class=\"Info__Description-sc-13d2405c-2 hHHVyA eapp-photo-gallery-info-description\">2.090.000đ</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"MasonryItem__Item-sc-a17d32ab-0 kXgGzo eapp-photo-gallery-masonry-item-item\">\r\n<div class=\"MasonryItem__Content-sc-a17d32ab-1 gBvKHj eapp-photo-gallery-masonry-item-content\">\r\n<div class=\"ItemData__Container-sc-fe2b9e06-4 lfFjav eapp-photo-gallery-item-data-component\" tabindex=\"0\" role=\"button\" aria-label=\"Visit linked content\">\r\n<div class=\"ItemData__ImageContainer-sc-fe2b9e06-5 KVTni eapp-photo-gallery-item-data-imageContainer eapp-photo-gallery-masonry-item-imageContainer\" style=\"text-align: center;\">\r\n<div class=\"ItemData__ImageBackground-sc-fe2b9e06-1 NBKrO eapp-photo-gallery-item-data-imageBackground\">&nbsp;</div>\r\n</div>\r\n<div class=\"WatermarkLogo__Wrapper-sc-98c7adfb-0 jyOHFJ eapp-photo-gallery-item-data-watermarkLogoWrapper\" style=\"text-align: center;\">\r\n<div class=\"WatermarkLogo__LogoContainer-sc-98c7adfb-1 fYgucl eapp-photo-gallery-item-data-watermarkLogo eapp-photo-gallery-item-data-watermarkPosition-undefined\">&nbsp;</div>\r\n</div>\r\n<div class=\"ItemData__InfoWrapper-sc-fe2b9e06-2 dITMsh eapp-photo-gallery-item-data-info\">\r\n<div class=\"Info__Container-sc-13d2405c-0 cSRluY eapp-photo-gallery-info-component\">\r\n<div class=\"Info__Title-sc-13d2405c-1 DwfVd eapp-photo-gallery-info-title\" style=\"text-align: center;\">Mercurial Vapor 15 Pro Hồng/Đen - DJ5605-601</div>\r\n<div class=\"Info__Description-sc-13d2405c-2 hHHVyA eapp-photo-gallery-info-description\" style=\"text-align: center;\">2.450,000đ</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"MasonryItem__Item-sc-a17d32ab-0 kXgGzo eapp-photo-gallery-masonry-item-item\">\r\n<div class=\"MasonryItem__Content-sc-a17d32ab-1 gBvKHj eapp-photo-gallery-masonry-item-content\">\r\n<div class=\"ItemData__Container-sc-fe2b9e06-4 hFBGse eapp-photo-gallery-item-data-component\" tabindex=\"0\" role=\"button\" aria-label=\"Visit linked content\">\r\n<div class=\"ItemData__ImageContainer-sc-fe2b9e06-5 iJOFUB eapp-photo-gallery-item-data-imageContainer eapp-photo-gallery-masonry-item-imageContainer\">\r\n<div class=\"ItemData__ImageBackground-sc-fe2b9e06-1 NBKrO eapp-photo-gallery-item-data-imageBackground\">&nbsp;</div>\r\n</div>\r\n<div class=\"WatermarkLogo__Wrapper-sc-98c7adfb-0 jyOHFJ eapp-photo-gallery-item-data-watermarkLogoWrapper\">\r\n<div class=\"WatermarkLogo__LogoContainer-sc-98c7adfb-1 fYgucl eapp-photo-gallery-item-data-watermarkLogo eapp-photo-gallery-item-data-watermarkPosition-undefined\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<hr />\r\n<h2>Thiết kế ấn tượng của&nbsp;<strong>Nike Mercurial Cosmic Speed</strong></h2>\r\n<p style=\"text-align: center;\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20241120_fi23InpK.jpg\" alt=\"Thiết kế ấn tượng của Nike Mercurial Cosmic Speed\" width=\"1000\" height=\"375\" /></p>\r\n<p>Ở phi&ecirc;n bản thứ hai của Cosmic Speed, Nike đ&atilde; mang đến một l&agrave;n gi&oacute; mới với hai phối m&agrave;u kh&aacute;c biệt v&agrave; cực kỳ ấn tượng</p>\r\n<ul>\r\n<li><strong>Mercurial Vapor 16</strong>: Với sắc &ldquo;Bright Mango/Black&rdquo;, đ&ocirc;i gi&agrave;y n&agrave;y l&agrave; sự tri &acirc;n tới mẫu Vapor VIII huyền thoại từ năm 2012, mang lại cảm gi&aacute;c vừa ho&agrave;i cổ, vừa hiện đại.</li>\r\n<li><strong>Mercurial Superfly 10</strong>: Mẫu gi&agrave;y cao cổ được kho&aacute;c l&ecirc;n sắc xanh ngọc &ldquo;Hyper Turq/Black&rdquo;, lấy cảm hứng từ Mercurial Vapor IX phi&ecirc;n bản đặc biệt năm 1998, t&aacute;i hiện lần đầu v&agrave;o năm 2014.</li>\r\n</ul>\r\n<p>Điểm nhấn thiết kế bao gồm d&ograve;ng chữ &ldquo;Nike&rdquo; in nổi bật tr&ecirc;n g&oacute;t gi&agrave;y v&agrave; dải băng đồ họa quấn quanh phần mũi ch&acirc;n. Hiệu ứng &aacute;nh kim quen thuộc được tạo ra bởi c&ocirc;ng nghệ PVD (Physical Vapor Deposition) &ndash; một quy tr&igrave;nh ch&acirc;n kh&ocirc;ng đặc biệt gi&uacute;p c&aacute;c lớp m&agrave;u kim loại si&ecirc;u mỏng b&aacute;m chặt v&agrave;o bề mặt vải dệt upper, với vẻ ngo&agrave;i lấp l&aacute;nh v&agrave; độc đ&aacute;o.</p>\r\n<h2>C&ocirc;ng nghệ đỉnh cao tr&ecirc;n Nike Mercurial Cosmic Speed</h2>\r\n<h3>1. Cấu tr&uacute;c upper Flyknit si&ecirc;u mỏng</h3>\r\n<p style=\"text-align: center;\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20241120_A4EwjLeY.jpg\" alt=\"C&ocirc;ng nghệ đỉnh cao tr&ecirc;n Nike Mercurial Cosmic Speed\" width=\"1000\" height=\"726\" /></p>\r\n<ul>\r\n<li>Vapor 16 v&agrave; Superfly 10 sử dụng lớp Flyknit mỏng v&agrave; nhẹ nhất từng được Nike &aacute;p dụng cho d&ograve;ng b&oacute;ng đ&aacute;.</li>\r\n<li>Độ d&agrave;y của Flyknit được giảm từ năm lớp xuống c&ograve;n ba lớp, tương đương giảm 20%, gi&uacute;p tối ưu h&oacute;a trọng lượng v&agrave; cảm gi&aacute;c b&oacute;ng.</li>\r\n</ul>\r\n<h3>2. Khả năng hỗ trợ tăng tốc cực kỳ ấn tượng</h3>\r\n<p>Gi&agrave;y cung cấp khả năng trả lại năng lượng cao hơn 10% mỗi bước chạy, gi&uacute;p c&aacute;c cầu thủ duy tr&igrave; tốc độ v&agrave; sức bền tr&ecirc;n s&acirc;n cỏ, đặc biệt ph&ugrave; hợp với lối chơi b&ugrave;ng nổ v&agrave; tốc độ cao.</p>\r\n<h3>3. Bộ đệm Air Zoom Strobel được n&acirc;ng cấp vượt trội</h3>\r\n<p style=\"text-align: center;\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20241120_GSsm4ir7.jpg\" alt=\"Bộ đệm Air Zoom Strobel được n&acirc;ng cấp vượt trội\" width=\"1000\" height=\"726\" /></p>\r\n<p>C&aacute;c r&atilde;nh linh hoạt tr&ecirc;n lớp đệm Air Zoom Strobel đ&atilde; được loại bỏ, thay v&agrave;o đ&oacute; l&agrave; c&aacute;c &ldquo;speed fins&rdquo; ở phần trước b&agrave;n ch&acirc;n, tăng cường độ b&aacute;m v&agrave; tối ưu h&oacute;a tốc độ.</p>\r\n<h3>4. Bộ đế th&uacute;c đẩy tối đa sự linh hoạt nhờ v&agrave;o cấu tr&uacute;c đặc biệt</h3>\r\n<p style=\"text-align: center;\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20241120_czICtgi9.jpg\" alt=\"Bộ đệm Air Zoom Strobel được n&acirc;ng cấp vượt trội\" width=\"1000\" height=\"726\" /></p>\r\n<p>Bộ đế được thiết kế để hỗ trợ tối đa khả năng chuyển động tự nhi&ecirc;n của b&agrave;n ch&acirc;n, gi&uacute;p cầu thủ cảm nhận đ&ocirc;i gi&agrave;y như một phần cơ thể, mang lại cảm gi&aacute;c tự do v&agrave; thoải m&aacute;i hơn.</p>\r\n<h2>Những ng&ocirc;i sao tốc độ đại diện cho Mercurial Cosmic Speed thế hệ thứ hai</h2>\r\n<p>Cosmic Speed thế hệ thứ hai được kỳ vọng sẽ sớm xuất hiện tr&ecirc;n ch&acirc;n c&aacute;c ng&ocirc;i sao b&oacute;ng đ&aacute; h&agrave;ng đầu thế giới, bao gồm</p>\r\n<ul>\r\n<li><strong>Vin&iacute;cius Jr</strong>. &ndash; Biểu tượng tốc độ v&agrave; kỹ thuật của Real Madrid.</li>\r\n<li>Lauren James &ndash; T&agrave;i năng s&aacute;ng gi&aacute; của b&oacute;ng đ&aacute; nữ Anh.</li>\r\n<li>Salma Paralluelo, Ada Hegerberg, Sam Kerr &ndash; Những ng&ocirc;i sao tấn c&ocirc;ng xuất sắc, đại diện cho sức mạnh v&agrave; phong c&aacute;ch của d&ograve;ng gi&agrave;y n&agrave;y.</li>\r\n</ul>\r\n<p>Với sự kết hợp ho&agrave;n hảo giữa thiết kế rực rỡ, c&ocirc;ng nghệ ti&ecirc;n tiến v&agrave; hiệu suất vượt trội,&nbsp;<strong>Nike Air Zoom Mercurial Cosmic Speed Chapter 2</strong>&nbsp;l&agrave; sự lựa chọn kh&ocirc;ng thể thiếu cho c&aacute;c cầu thủ khao kh&aacute;t chinh phục s&acirc;n cỏ. Đ&acirc;y kh&ocirc;ng chỉ l&agrave; đ&ocirc;i gi&agrave;y hỗ trợ tối đa hiệu suất thi đấu m&agrave; c&ograve;n l&agrave; tuy&ecirc;n ng&ocirc;n phong c&aacute;ch, gi&uacute;p c&aacute;c ng&ocirc;i sao tỏa s&aacute;ng tr&ecirc;n s&acirc;n cỏ to&agrave;n cầu.</p>\r\n<p>H&atilde;y sẵn s&agrave;ng b&ugrave;ng nổ c&ugrave;ng Cosmic Speed Chapter 2 &ndash; nơi tốc độ gặp gỡ sự s&aacute;ng tạo v&agrave; đẳng cấp!</p>\r\n</div>','2025-09-03 14:22:46.775864','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777607158/tblzs9ps1tdqn3rbp1wm.jpg','',0,'Nike Air Zoom Mercurial Cosmic Speed : Sự trở lại đầy','nike-air-zoom-mercurial-cosmic-speed-su-tro-lai-ay','Nike Air Zoom Mercurial Cosmic Speed : Sự trở lại đầy','2026-05-01 11:19:18.263784',NULL),(16,'<h1 style=\"text-align: center;\">Review Mizuno Alpha 3 Pro AS &ndash; Gi&agrave;y tốc độ cỏ nh&acirc;n tạo form dễ mang</h1>\r\n<div class=\"title-main-home\">\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260125_DHduIsXo.jpg\" alt=\"20260125_DHduIsXo.jpg\" width=\"1000\" height=\"667\" /></figure>\r\n<div id=\"toc_container\" class=\"no_bullets\">\r\n<p class=\"toc_title\" style=\"text-align: center;\"><strong>Mục lục</strong></p>\r\n<p style=\"text-align: center;\">1. Giới thiệu Mizuno Alpha 3 Pro AS</p>\r\n<p style=\"text-align: center;\">2. Thiết kế &amp; phối m&agrave;u</p>\r\n<p style=\"text-align: center;\">3. Upper dệt &ndash; d&agrave;y hơn nhưng mềm v&agrave; bền</p>\r\n<p style=\"text-align: center;\">4. Form gi&agrave;y &amp; cảm gi&aacute;c mang thực tế</p>\r\n<p style=\"text-align: center;\">5. Bộ đế thấp &ndash; linh hoạt cho s&acirc;n cỏ nh&acirc;n tạo</p>\r\n<p style=\"text-align: center;\">6. Trọng lượng &amp; cảm gi&aacute;c thi đấu</p>\r\n<p style=\"text-align: center;\">7. Mizuno Alpha 3 Pro AS ph&ugrave; hợp với ai?</p>\r\n<p style=\"text-align: center;\">8. Kết luận</p>\r\n</div>\r\n<h2><span id=\"gioi-thieu\">1. Giới thiệu Mizuno Alpha 3 Pro AS</span></h2>\r\n<div>\r\n<p style=\"text-align: center;\"><iframe src=\"https://www.youtube.com/embed/Fu65udkX9gc\" width=\"1000\" height=\"700\" frameborder=\"0\" data-mce-fragment=\"1\"></iframe></p>\r\n</div>\r\n<p><strong>Mizuno Alpha 3 Pro AS</strong>&nbsp;l&agrave; phi&ecirc;n bản d&agrave;nh cho&nbsp;<strong>s&acirc;n cỏ nh&acirc;n tạo</strong>&nbsp;trong d&ograve;ng&nbsp;Mizuno Alpha 3, hướng tới người chơi phong tr&agrave;o cần một đ&ocirc;i&nbsp;gi&agrave;y đ&aacute; b&oacute;ng&nbsp;tốc độ, dễ mang v&agrave; linh hoạt khi xoay trở tr&ecirc;n mặt s&acirc;n cứng.</p>\r\n<p>So với c&aacute;c bản cao hơn như Japan hay Elite TF, Alpha 3 Pro AS tập trung v&agrave;o t&iacute;nh thực dụng: form th&acirc;n thiện, đế thấp, cảm gi&aacute;c s&acirc;n r&otilde; r&agrave;ng v&agrave; mức gi&aacute; dễ tiếp cận hơn cho người chơi s&acirc;n 7, s&acirc;n 5.</p>\r\n<h2><span id=\"thiet-ke\">2. Thiết kế &amp; phối m&agrave;u</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260125_Cwd5FDQm.jpg\" alt=\"Review Mizuno Alpha 3 Pro AS 2\" width=\"1000\" height=\"667\" />\r\n<figcaption>Review Mizuno Alpha 3 Pro AS</figcaption>\r\n</figure>\r\n<p>Ấn tượng ban đầu khi mở hộp Mizuno Alpha 3 Pro AS l&agrave;&nbsp;<strong>phối m&agrave;u h&agrave;i h&ograve;a</strong>, kh&ocirc;ng qu&aacute; ch&oacute;i, dễ phối đồ v&agrave; ph&ugrave; hợp với nhiều phong c&aacute;ch thi đấu kh&aacute;c nhau.</p>\r\n<p>Tổng thể thiết kế giữ đ&uacute;ng tinh thần tốc độ của d&ograve;ng Alpha: form gọn, th&acirc;n gi&agrave;y thanh tho&aacute;t v&agrave; kh&ocirc;ng tạo cảm gi&aacute;c &ldquo;th&ocirc;&rdquo; như một số mẫu gi&agrave;y s&acirc;n cỏ nh&acirc;n tạo truyền thống.</p>\r\n<h2><span id=\"upper\">3. Upper dệt &ndash; d&agrave;y hơn nhưng mềm v&agrave; bền</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260125_ToHiHtoP.jpg\" alt=\"Review Mizuno Alpha 3 Pro AS\" width=\"1000\" height=\"667\" /></figure>\r\n<p>Phần upper của Alpha 3 Pro AS sử dụng&nbsp;<strong>vải dệt</strong>, c&oacute; cảm gi&aacute;c d&agrave;y hơn thế hệ trước nhưng đổi lại l&agrave; độ&nbsp;<strong>mềm v&agrave; bền</strong>&nbsp;tốt hơn.</p>\r\n<p>Upper n&agrave;y kh&ocirc;ng qu&aacute; mỏng kiểu barefoot, nhưng đủ mềm để tạo cảm gi&aacute;c thoải m&aacute;i khi tiếp x&uacute;c b&oacute;ng, đồng thời ph&ugrave; hợp với cường độ chơi thường xuy&ecirc;n tr&ecirc;n s&acirc;n cỏ nh&acirc;n tạo.</p>\r\n<p>Phần mũi gi&agrave;y được&nbsp;<strong>may sẵn đường chỉ</strong>, gi&uacute;p người chơi tự tin ch&iacute;ch mũi, hạn chế bong keo &ndash; chi tiết rất thực tế cho b&oacute;ng đ&aacute; phong tr&agrave;o.</p>\r\n<h2><span id=\"form-fit\">4. Form gi&agrave;y &amp; cảm gi&aacute;c mang thực tế</span></h2>\r\n<p>Mizuno Alpha 3 Pro AS c&oacute;&nbsp;<strong>lưỡi g&agrave; liền</strong>, gi&uacute;p gi&agrave;y &ocirc;m ch&acirc;n hơn nhưng cũng khiến việc xỏ gi&agrave;y ban đầu hơi kh&oacute;, đặc biệt với gi&agrave;y mới.</p>\r\n<p>Tuy nhi&ecirc;n, khi đ&atilde; v&agrave;o ch&acirc;n, kh&ocirc;ng gian b&ecirc;n trong kh&aacute; thoải m&aacute;i. Với form ch&acirc;n d&agrave;i khoảng 25.5cm, ngang ~10cm, gi&agrave;y cho cảm gi&aacute;c vừa vặn, kh&ocirc;ng cấn v&agrave; đủ kh&ocirc;ng gian cho ch&acirc;n b&egrave; vừa.</p>\r\n<p>G&oacute;t gi&agrave;y sử dụng&nbsp;<strong>da lộn</strong>, gi&uacute;p hạn chế xước g&oacute;t v&agrave; tăng độ b&aacute;m khi di chuyển li&ecirc;n tục.</p>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260125_o4zz9q1X.jpg\" alt=\"20260125_o4zz9q1X.jpg\" width=\"1000\" height=\"666\" />\r\n<figcaption>Review Mizuno Alpha 3 Pro AS - g&oacute;t gi&agrave;y</figcaption>\r\n</figure>\r\n<h2><span id=\"de-giay\">5. Bộ đế thấp &ndash; linh hoạt cho s&acirc;n cỏ nh&acirc;n tạo</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260125_EpLma5Av.jpg\" alt=\"Review Mizuno Alpha 3 Pro AS - bộ đế\" width=\"1000\" height=\"666\" />\r\n<figcaption>Review Mizuno Alpha 3 Pro AS - bộ đế</figcaption>\r\n</figure>\r\n<p>Điểm đ&aacute;ng ch&uacute; &yacute; tr&ecirc;n Alpha 3 Pro AS l&agrave;&nbsp;<strong>bộ đế kh&aacute; thấp</strong>, gần như&nbsp;<strong>kh&ocirc;ng c&oacute; đệm d&agrave;y</strong>.</p>\r\n<p>Cảm gi&aacute;c s&acirc;n r&otilde; r&agrave;ng, ph&ugrave; hợp với những anh em chơi linh hoạt, xoay chuyển nhiều v&agrave; th&iacute;ch cảm gi&aacute;c s&aacute;t mặt s&acirc;n khi xử l&yacute; b&oacute;ng.</p>\r\n<p>Gi&agrave;y được trang bị&nbsp;<strong>l&oacute;t Mizuno Enerzy XP</strong>, gi&uacute;p tăng độ &ecirc;m vừa đủ, b&ugrave; lại cho phần đế thấp v&agrave; giảm &aacute;p lực khi tiếp đất.</p>\r\n<h2><span id=\"trong-luong\">6. Trọng lượng &amp; cảm gi&aacute;c thi đấu</span></h2>\r\n<p>Trọng lượng thực tế của Mizuno Alpha 3 Pro AS (size 40.5) rơi v&agrave;o khoảng&nbsp;<strong>245&ndash;247g</strong>.</p>\r\n<p>Khi cầm tr&ecirc;n tay gi&agrave;y cho cảm gi&aacute;c kh&aacute; nhẹ, l&ecirc;n ch&acirc;n kh&ocirc;ng bị nặng nề, ph&ugrave; hợp cho c&aacute;c trận đấu s&acirc;n 7 k&eacute;o d&agrave;i hoặc chơi li&ecirc;n tục nhiều trận trong tuần.</p>\r\n<h2><span id=\"ai-phu-hop\">7. Mizuno Alpha 3 Pro AS ph&ugrave; hợp với ai?</span></h2>\r\n<p>Mizuno Alpha 3 Pro AS sẽ ph&ugrave; hợp nếu bạn:</p>\r\n<ul>\r\n<li>Chơi s&acirc;n cỏ nh&acirc;n tạo, ưu ti&ecirc;n cảm gi&aacute;c s&acirc;n r&otilde;</li>\r\n<li>Ch&acirc;n thon đến b&egrave; vừa, kh&ocirc;ng qu&aacute; b&egrave;</li>\r\n<li>Th&iacute;ch gi&agrave;y form dễ mang, kh&ocirc;ng cần break-in l&acirc;u</li>\r\n<li>Muốn một lựa chọn kinh tế hơn so với Alpha 3 Japan hoặc Elite</li>\r\n</ul>\r\n<p>Nếu bạn quan t&acirc;m tới trải nghiệm cao cấp hơn, c&oacute; thể tham khảo th&ecirc;m b&agrave;i&nbsp;đ&aacute;nh gi&aacute; Mizuno Alpha 3 Japan&nbsp;hoặc phi&ecirc;n bản&nbsp;Alpha 3 Elite TF.</p>\r\n<h2><span id=\"ket-luan\">8. Kết luận</span></h2>\r\n<p><strong>Mizuno Alpha 3 Pro AS</strong>&nbsp;l&agrave; lựa chọn hợp l&yacute; cho người chơi s&acirc;n cỏ nh&acirc;n tạo cần một đ&ocirc;i gi&agrave;y tốc độ, form dễ mang, đế thấp linh hoạt v&agrave; mức gi&aacute; dễ tiếp cận.</p>\r\n<p>Đ&acirc;y kh&ocirc;ng phải phi&ecirc;n bản &ldquo;đỉnh&rdquo; nhất trong d&ograve;ng Alpha 3, nhưng l&agrave; đ&ocirc;i gi&agrave;y&nbsp;<strong>thực dụng, ổn định v&agrave; ph&ugrave; hợp số đ&ocirc;ng</strong>&nbsp;người chơi phong tr&agrave;o.</p>\r\n<h2><span id=\"he-thong-the-gioi-bong-da\">Hệ thống cửa h&agrave;ng Beyond</span></h2>\r\n<p>C&aacute;c nhận định v&agrave; trải nghiệm trong b&agrave;i được tổng hợp từ thực tế tư vấn, thử gi&agrave;y v&agrave; phản hồi của kh&aacute;ch h&agrave;ng tại hệ thống cửa h&agrave;ng Thế Giới B&oacute;ng Đ&aacute; &ndash; chuy&ecirc;n gi&agrave;y đ&aacute; b&oacute;ng ch&iacute;nh h&atilde;ng.</p>\r\n<p>Tại cửa h&agrave;ng, kh&aacute;ch h&agrave;ng c&oacute; thể thử trực tiếp từng d&ograve;ng gi&agrave;y theo form ch&acirc;n, được tư vấn size ph&ugrave; hợp v&agrave; hỗ trợ đổi size nếu chưa vừa khi sử dụng thực tế.</p>\r\n</div>','2025-09-03 14:23:36.821112','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777606986/evjoi4f4tn3azxnrfz21.jpg','',0,'Review Mizuno Alpha 3 Pro AS – Giày tốc độ cỏ nhân tạo','review-mizuno-alpha-3-pro-as-giay-toc-o-co-nhan-tao','Review Mizuno Alpha 3 Pro AS – Giày tốc độ cỏ nhân tạo','2026-05-01 11:19:09.066429',NULL),(17,'<h1 style=\"text-align: center;\">Adidas Predator 26 Elite Review &ndash; Bước tiến hay bước l&ugrave;i của Predator?</h1>\r\n<div class=\"title-main-home\">\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/Adidas-Predator-26-Elite-1-.jpg\" alt=\"Review Adidas Predator 26 Elite 1\" width=\"1000\" height=\"667\" />\r\n<figcaption>Review Adidas Predator 26 Elite</figcaption>\r\n</figure>\r\n<p>&nbsp;</p>\r\n<div id=\"toc_container\" class=\"no_bullets\">\r\n<p class=\"toc_title\" style=\"text-align: center;\"><strong>Mục lục</strong></p>\r\n<p style=\"text-align: center;\">1. Giới thiệu</p>\r\n<p style=\"text-align: center;\">2. Upper NanoStrike+ &amp; cảm gi&aacute;c b&oacute;ng</p>\r\n<p style=\"text-align: center;\">3. Form gi&agrave;y &amp; độ &ocirc;m ch&acirc;n</p>\r\n<p style=\"text-align: center;\">4. Strikezone &amp; khả năng s&uacute;t b&oacute;ng</p>\r\n<p style=\"text-align: center;\">5. Đế gi&agrave;y, stud &amp; Powerspine</p>\r\n<p style=\"text-align: center;\">6. Ưu &amp; nhược điểm tổng hợp</p>\r\n<p style=\"text-align: center;\">7. Predator 26 Elite ph&ugrave; hợp với ai?</p>\r\n<p style=\"text-align: center;\">8. Kết luận</p>\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n</div>\r\n<h2><span id=\"gioi-thieu\">1. Giới thiệu</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/Adidas-Predator-26-Elite-3-.jpg\" alt=\"Review Adidas Predator 26 Elite 2\" width=\"1000\" height=\"666\" />\r\n<figcaption>Review Adidas Predator 26 Elite</figcaption>\r\n</figure>\r\n<p>Sau th&agrave;nh c&ocirc;ng của Predator 24 v&agrave; đặc biệt l&agrave; Predator 25,&nbsp;<strong>adidas&nbsp;</strong>bước v&agrave;o thế hệ mới với rất nhiều kỳ vọng đặt l&ecirc;n&nbsp;<strong>Adidas Predator 26 Elite</strong>. Lưỡi g&agrave; gập đ&atilde; trở lại, đế gi&agrave;y mới, v&agrave; h&agrave;ng loạt tinh chỉnh được quảng b&aacute; l&agrave; &ldquo;Predator hiện đại nhất&rdquo;.</p>\r\n<p>Nhưng khi trải nghiệm thực tế, Predator 26 Elite lại mang đến cảm gi&aacute;c kh&aacute;&hellip; lạ. Kh&ocirc;ng hẳn l&agrave; một bản n&acirc;ng cấp to&agrave;n diện, m&agrave; giống như một Predator được đẩy theo hướng&nbsp;<em>mỏng &ndash; nhẹ &ndash; gần b&oacute;ng hơn</em>. Trong b&agrave;i viết n&agrave;y, Thế Giới B&oacute;ng Đ&aacute; sẽ ph&acirc;n t&iacute;ch chi tiết Predator 26 Elite, đồng thời đặt n&oacute; trong bức tranh tổng thể của&nbsp;d&ograve;ng Predator 26&nbsp;v&agrave; b&agrave;i tổng qu&aacute;t&nbsp;Adidas Predator 26 &ndash; Kỷ nguy&ecirc;n kiểm so&aacute;t b&oacute;ng thế hệ mới&nbsp;.</p>\r\n<h2><span id=\"upper-va-cam-giac-bong\">2. Upper NanoStrike+ &amp; cảm gi&aacute;c b&oacute;ng</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/Adidas-Predator-26-Elite-2-.jpg\" alt=\"Review Adidas Predator 26 Elite 3\" width=\"1000\" height=\"667\" />\r\n<figcaption>Review Adidas Predator 26 Elite</figcaption>\r\n</figure>\r\n<p>Thay đổi g&acirc;y tranh c&atilde;i nhất tr&ecirc;n Predator 26 Elite ch&iacute;nh l&agrave; upper&nbsp;<strong>NanoStrike+</strong>. adidas đ&atilde; n&oacute;i lời chia tay Hybridtouch &ndash; chất liệu được đ&aacute;nh gi&aacute; rất cao ở Predator 24 v&agrave; 25 &ndash; để chuyển sang một lớp textile mesh si&ecirc;u mỏng phủ c&aacute;c điểm grip mới.</p>\r\n<p>Ở lần mang đầu ti&ecirc;n, phần upper chưa mềm ngay, cảm gi&aacute;c hơi cứng v&agrave; cần v&agrave;i buổi chơi để gi&agrave;y bắt đầu v&agrave;o form. Upper mỏng khiến b&agrave;n ch&acirc;n ở rất gần b&oacute;ng, nhưng điều n&agrave;y lại l&agrave;m Predator 26 Elite c&oacute; cảm gi&aacute;c hơi &ldquo;speed boot&rdquo;, gợi li&ecirc;n tưởng nhiều hơn đến F50 thay v&igrave; một Predator truyền thống.</p>\r\n<p>Sau qu&aacute; tr&igrave;nh break-in, upper c&oacute; mềm hơn v&agrave; bắt đầu &ocirc;m theo form ch&acirc;n. Tuy nhi&ecirc;n, thời gian thuần gi&agrave;y d&agrave;i hơn đ&aacute;ng kể: thay v&igrave; 1 buổi như Predator 25, Predator 26 Elite cần tới 2&ndash;3 buổi chơi mới đạt trạng th&aacute;i ổn định.</p>\r\n<h2><span id=\"form-va-fit\">3. Form gi&agrave;y &amp; độ &ocirc;m ch&acirc;n</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/Adidas-Predator-26-Elite-5-.jpg\" alt=\"Review Adidas Predator 26 Elite\" width=\"1000\" height=\"666\" />\r\n<figcaption>Review Adidas Predator 26 Elite</figcaption>\r\n</figure>\r\n<p>Về tổng thể, Predator 26 Elite vẫn mang form &ocirc;m vừa, midfoot kh&aacute; gọn v&agrave; kh&ocirc;ng ưu &aacute;i ch&acirc;n b&egrave;. Điểm kh&aacute;c l&agrave; phần toe box c&oacute; độ cao lớn hơn một ch&uacute;t, tạo th&ecirc;m kh&ocirc;ng gian cho ng&oacute;n ch&acirc;n v&agrave; tăng sự thoải m&aacute;i khi di chuyển l&acirc;u.</p>\r\n<p>Tuy nhi&ecirc;n, một số anh em sẽ nhận ra&nbsp;<strong>dead space nhẹ</strong>&nbsp;ở khu vực mu trong forefoot, đặc biệt gần ng&oacute;n c&aacute;i. Khi chơi th&igrave; kh&ocirc;ng ảnh hưởng qu&aacute; nhiều, nhưng khi nh&igrave;n xuống sẽ thấy form chưa thực sự &ldquo;liền mạch&rdquo; như Predator 25.</p>\r\n<p>G&oacute;t gi&agrave;y l&agrave; một điểm g&acirc;y tranh c&atilde;i kh&aacute;c. Phần heel b&ecirc;n trong c&oacute; xu hướng rộng hơn, khiến một số người phải siết d&acirc;y nhiều hơn để đạt lockdown mong muốn. Nếu anh em ưu ti&ecirc;n cảm gi&aacute;c kh&oacute;a g&oacute;t chặt, phi&ecirc;n bản kh&ocirc;ng lưỡi g&agrave; gập (non-FT) vẫn l&agrave; lựa chọn ổn định hơn.</p>\r\n<h2><span id=\"strikezone\">4. Strikezone &amp; khả năng s&uacute;t b&oacute;ng</span></h2>\r\n<p>Strikezone tr&ecirc;n Predator 26 Elite được thiết kế lại. Thay v&igrave; c&aacute;c v&acirc;y cao su lớn như Predator 25, adidas sử dụng c&aacute;c &ldquo;đảo&rdquo; grip nhỏ kết hợp bề mặt nh&aacute;m.</p>\r\n<p>Cảm gi&aacute;c khi s&uacute;t kh&ocirc;ng c&ograve;n qu&aacute; &ldquo;d&iacute;nh&rdquo; hay gắt, m&agrave; thi&ecirc;n về&nbsp;<strong>đồng đều v&agrave; kiểm so&aacute;t</strong>. Những pha s&uacute;t mu ch&iacute;nh diện vẫn cho lực đi gọn, c&ograve;n c&aacute;c c&uacute; cứa l&ograve;ng mang cảm gi&aacute;c rất dễ chịu, d&ugrave; độ b&aacute;m kh&ocirc;ng nổi bật như StrikeSkin trước đ&acirc;y.</p>\r\n<h2><span id=\"soleplate\">5. Đế gi&agrave;y, stud &amp; Powerspine</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/Adidas-Predator-26-Elite-4-.jpg\" alt=\"Review Adidas Predator 26 Elite 6\" width=\"1000\" height=\"667\" />\r\n<figcaption>Review Adidas Predator 26 Elite</figcaption>\r\n</figure>\r\n<p>Nếu phải chọn ra phần tốt nhất của Predator 26 Elite, th&igrave; đ&oacute; ch&iacute;nh l&agrave;&nbsp;<strong>soleplate</strong>. Đế mới cho cảm gi&aacute;c cao cấp hơn hẳn, độ ổn định tốt v&agrave; phản hồi rất r&otilde; khi đổi hướng.</p>\r\n<p><strong>Powerspine</strong>&nbsp;quay trở lại ở giữa th&acirc;n đế, gi&uacute;p hạn chế xoắn v&agrave; tạo nền tảng vững khi dứt điểm. Stud được thiết kế với mặt tiếp x&uacute;c lớn hơn, b&aacute;m s&acirc;n tốt nhưng vẫn xoay trở ổn, đặc biệt ph&ugrave; hợp cho AG v&agrave; FG hiện đại.</p>\r\n<h2><span id=\"uu-nhuoc-diem\">6. Ưu &amp; nhược điểm tổng hợp</span></h2>\r\n<ul>\r\n<li><strong>Ưu điểm:</strong>&nbsp;đế gi&agrave;y xuất sắc, ổn định, Powerspine hiệu quả, strikezone dễ kiểm so&aacute;t</li>\r\n<li><strong>Nhược điểm:</strong>&nbsp;upper cứng l&uacute;c đầu, break-in l&acirc;u, form g&oacute;t chưa tối ưu</li>\r\n</ul>\r\n<h2><span id=\"predator-26-elite-phu-hop-ai\">7. Predator 26 Elite ph&ugrave; hợp với ai?</span></h2>\r\n<p><strong>Adidas Predator 26 Elite</strong>&nbsp;ph&ugrave; hợp với:</p>\r\n<ul>\r\n<li>Cầu thủ th&iacute;ch cảm gi&aacute;c b&oacute;ng s&aacute;t ch&acirc;n, xử l&yacute; trực diện</li>\r\n<li>Tiền vệ hoặc tiền đạo ưu ti&ecirc;n s&uacute;t v&agrave; chuyền ch&iacute;nh x&aacute;c</li>\r\n<li>Người chơi sẵn s&agrave;ng d&agrave;nh thời gian break-in gi&agrave;y</li>\r\n</ul>\r\n<p>Nếu anh em y&ecirc;u th&iacute;ch cảm gi&aacute;c Predator truyền thống, mềm v&agrave; dễ chơi, Predator 25 vẫn l&agrave; lựa chọn an to&agrave;n hơn. Nhưng nếu muốn một Predator&nbsp;<em>mỏng, hiện đại v&agrave; sắc n&eacute;t</em>, Predator 26 Elite vẫn rất đ&aacute;ng để thử trực tiếp.</p>\r\n<h2><span id=\"ket-luan\">8. Kết luận</span></h2>\r\n<p><strong>Adidas</strong>&nbsp;Predator 26 Elite l&agrave; một bản ph&aacute;t h&agrave;nh kh&aacute; &ldquo;lạ&rdquo;. Upper g&acirc;y nhiều tranh c&atilde;i, nhưng b&ugrave; lại, đế gi&agrave;y v&agrave; strikezone lại rất xuất sắc.</p>\r\n<p>Đ&acirc;y kh&ocirc;ng phải Predator dễ y&ecirc;u ngay từ lần xỏ đầu ti&ecirc;n, nhưng nếu anh em ki&ecirc;n nhẫn l&agrave;m quen, Predator 26 Elite vẫn mang đến một trải nghiệm kiểm so&aacute;t b&oacute;ng rất kh&aacute;c biệt trong thế giới&nbsp;gi&agrave;y đ&aacute; b&oacute;ng Predator.</p>\r\n<h2>Hệ thống cửa h&agrave;ng <span id=\"he-thong-the-gioi-bong-da\">Beyond</span></h2>\r\n<p>C&aacute;c nhận định v&agrave; trải nghiệm trong b&agrave;i được tổng hợp từ thực tế tư vấn, thử gi&agrave;y v&agrave; phản hồi của kh&aacute;ch h&agrave;ng tại hệ thống cửa h&agrave;ng Thế Giới B&oacute;ng Đ&aacute; &ndash; chuy&ecirc;n gi&agrave;y đ&aacute; b&oacute;ng ch&iacute;nh h&atilde;ng.</p>\r\n<p>Tại cửa h&agrave;ng, kh&aacute;ch h&agrave;ng c&oacute; thể thử trực tiếp từng d&ograve;ng gi&agrave;y theo form ch&acirc;n, được tư vấn size ph&ugrave; hợp v&agrave; hỗ trợ đổi size nếu chưa vừa khi sử dụng thực tế.</p>\r\n</div>','2025-09-03 14:25:37.985498','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777606742/xfucsrjget4iyaahu8ln.jpg','',0,'Adidas Predator 26 Elite Review – Bước tiến hay bước lùi của Predator?','adidas-predator-26-elite-review-buoc-tien-hay-buoc-lui-cua-predator','Adidas Predator 26 Elite Review – Bước tiến hay bước lùi của Predator?','2026-05-10 00:38:11.626542',NULL),(18,'<h1 style=\"text-align: center;\">Adidas F50 Messi &ndash; Di sản tốc độ mang dấu ấn của một huyền thoại</h1>\r\n<div class=\"title-main-home\">\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260226_uRG8ZtPo.jpg\" alt=\"Adidas F50 Messi 1\" width=\"1000\" height=\"573\" />\r\n<figcaption>Adidas F50 Messi</figcaption>\r\n</figure>\r\n<div id=\"toc_container\" class=\"no_bullets\">\r\n<p class=\"toc_title\" style=\"text-align: center;\">&nbsp;</p>\r\n<p class=\"toc_title\" style=\"text-align: center;\"><strong>Mục lục</strong></p>\r\n<p style=\"text-align: center;\">1. F50 Messi l&agrave; g&igrave;? C&oacute; kh&aacute;c F50 thường kh&ocirc;ng?</p>\r\n<p style=\"text-align: center;\">2. C&acirc;u chuyện Messi v&agrave; F50 &ndash; Tốc độ c&oacute; kiểm so&aacute;t</p>\r\n<p style=\"text-align: center;\">3. C&ocirc;ng nghệ tr&ecirc;n Adidas F50 Messi thế hệ mới</p>\r\n<p style=\"text-align: center;\">4. So s&aacute;nh F50 Messi Elite &ndash; Pro &ndash; League</p>\r\n<p style=\"text-align: center;\">5. Ai n&ecirc;n chọn Adidas F50 Messi?</p>\r\n<p style=\"text-align: center;\">6. C&aacute;c b&agrave;i viết chi tiết về F50 Messi</p>\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n</div>\r\n<h2><span id=\"gioi-thieu\">1. F50 Messi l&agrave; g&igrave;? C&oacute; kh&aacute;c F50 thường kh&ocirc;ng?</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260226_ATq3Jfuh.jpg\" alt=\"Adidas F50 Messi 2\" width=\"1000\" height=\"725\" />\r\n<figcaption>Adidas F50 Messi</figcaption>\r\n</figure>\r\n<p>Adidas F50 Messi l&agrave; phi&ecirc;n bản signature nằm trong d&ograve;ng&nbsp;Adidas F50&nbsp;&ndash; d&ograve;ng speed boot huyền thoại của&nbsp;gi&agrave;y đ&aacute; b&oacute;ng Adidas.</p>\r\n<p>Nhiều anh em nghĩ F50 Messi chỉ kh&aacute;c ở phối m&agrave;u. Thực tế, đ&acirc;y l&agrave; phi&ecirc;n bản mang dấu ấn c&aacute; nh&acirc;n của Lionel Messi, từ thiết kế đồ họa, m&agrave;u sắc đến tinh thần chơi b&oacute;ng m&agrave; đ&ocirc;i gi&agrave;y hướng tới.</p>\r\n<p>Về nền tảng kỹ thuật, F50 Messi vẫn dựa tr&ecirc;n cấu tr&uacute;c speed boot của F50 thế hệ mới. Tuy nhi&ecirc;n, cảm gi&aacute;c b&oacute;ng, độ &ocirc;m ch&acirc;n v&agrave; tinh thần thiết kế thi&ecirc;n về phong c&aacute;ch r&ecirc; dắt tốc độ cao &ndash; thứ đ&atilde; l&agrave;m n&ecirc;n thương hiệu của Messi.</p>\r\n<p>Nếu Pillar&nbsp;Adidas F50&nbsp;tập trung v&agrave;o kh&aacute;i niệm tốc độ thuần, th&igrave; F50 Messi l&agrave; tốc độ đi k&egrave;m kiểm so&aacute;t.</p>\r\n<h2><span id=\"cau-chuyen\">2. C&acirc;u chuyện Messi v&agrave; F50 &ndash; Tốc độ c&oacute; kiểm so&aacute;t</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260226_Lv55c6jl.jpg\" alt=\"Adidas F50 Messi 3\" width=\"1000\" height=\"573\" />\r\n<figcaption>Adidas F50 Messi</figcaption>\r\n</figure>\r\n<p>Trong giai đoạn đỉnh cao sự nghiệp, Messi từng gắn b&oacute; với F50 v&agrave; tạo n&ecirc;n những m&ugrave;a giải b&ugrave;ng nổ. Nhưng điều đặc biệt l&agrave; Messi kh&ocirc;ng phải mẫu cầu thủ &ldquo;chạy thẳng v&agrave; bứt ph&aacute;&rdquo; thuần tốc độ.</p>\r\n<p>Phong c&aacute;ch của anh l&agrave; giữ b&oacute;ng s&aacute;t ch&acirc;n, r&ecirc; trong kh&ocirc;ng gian hẹp, tăng tốc ngắn li&ecirc;n tục v&agrave; đổi hướng cực nhanh. Ch&iacute;nh v&igrave; vậy, F50 Messi kh&ocirc;ng chỉ cần nhẹ &ndash; m&agrave; phải phản hồi nhanh v&agrave; giữ được cảm gi&aacute;c b&oacute;ng ch&iacute;nh x&aacute;c.</p>\r\n<p>Triết l&yacute; đ&oacute; được t&aacute;i hiện tr&ecirc;n thế hệ F50 Messi mới: speed nhưng kh&ocirc;ng đ&aacute;nh đổi khả năng kiểm so&aacute;t.</p>\r\n<h2><span id=\"cong-nghe\">3. C&ocirc;ng nghệ tr&ecirc;n Adidas F50 Messi thế hệ mới</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260226_eljRvukJ.jpg\" alt=\"Adidas F50 Messi 4\" width=\"1000\" height=\"725\" />\r\n<figcaption>Adidas F50 Messi</figcaption>\r\n</figure>\r\n<h3>Fibertouch Upper</h3>\r\n<p>Upper Fibertouch dạng mesh tổng hợp cho cảm gi&aacute;c b&oacute;ng trực diện. Khi r&ecirc; b&oacute;ng ở tốc độ cao, lớp vật liệu n&agrave;y gi&uacute;p phản hồi nhanh v&agrave; r&otilde; lực.</p>\r\n<h3>Sprintweb Texturing</h3>\r\n<p>Bề mặt phủ v&acirc;n nổi Sprintweb tăng ma s&aacute;t khi xử l&yacute; b&oacute;ng, hỗ trợ những pha đảo hướng nhanh &ndash; đ&uacute;ng phong c&aacute;ch Messi.</p>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260226_6Bm3hqNC.jpg\" alt=\"Adidas F50 Messi 5\" width=\"1000\" height=\"725\" />\r\n<figcaption>Adidas F50 Messi</figcaption>\r\n</figure>\r\n<h3>Sprintframe 360</h3>\r\n<p>Bộ đế Sprintframe 360 với cấu tr&uacute;c đinh b&aacute;n n&oacute;n kết hợp lưỡi dao hỗ trợ xoay trụ đa hướng. Điều n&agrave;y đặc biệt hữu &iacute;ch khi r&ecirc; b&oacute;ng v&agrave; cắt v&agrave;o trung lộ.</p>\r\n<p>Một số phi&ecirc;n bản cao cấp c&ograve;n t&iacute;ch hợp Lightstrike Pro ở phần forefoot gi&uacute;p tăng độ bật khi tăng tốc ngắn.</p>\r\n<p>Tổng thể, F50 Messi vẫn giữ DNA speed boot, nhưng cảm gi&aacute;c b&oacute;ng c&oacute; xu hướng &ldquo;mềm&rdquo; v&agrave; kiểm so&aacute;t hơn so với nhiều speed boot thuần kh&aacute;c.</p>\r\n<h2><span id=\"so-sanh\">4. So s&aacute;nh F50 Messi Elite &ndash; Pro &ndash; League</span></h2>\r\n<h3>F50 Messi Elite</h3>\r\n<p>Phi&ecirc;n bản cao cấp nhất, ho&agrave;n thiện chi tiết tốt nhất, upper mỏng v&agrave; phản hồi r&otilde;. Ph&ugrave; hợp người chơi cường độ cao, muốn cảm gi&aacute;c locked-in tối đa.</p>\r\n<h3>F50 Messi Pro</h3>\r\n<p>Giữ lại phần lớn nền tảng c&ocirc;ng nghệ nhưng tối ưu gi&aacute; th&agrave;nh. Tương tự như triết l&yacute; của&nbsp;Adidas F50 Pro, đ&acirc;y thường l&agrave; lựa chọn c&acirc;n bằng giữa hiệu năng v&agrave; ng&acirc;n s&aacute;ch.</p>\r\n<h3>F50 Messi League</h3>\r\n<p>Phi&ecirc;n bản dễ tiếp cận hơn, ph&ugrave; hợp học sinh &ndash; sinh vi&ecirc;n hoặc người chơi phong tr&agrave;o. C&aacute;ch ph&acirc;n cấp tương tự d&ograve;ng&nbsp;Adidas F50 League, nhưng mang thiết kế Messi.</p>\r\n<p>Trong c&aacute;c buổi tư vấn thực tế tại cửa h&agrave;ng, phi&ecirc;n bản Pro thường l&agrave; lựa chọn hợp l&yacute; nhất cho s&acirc;n 7 Việt Nam &ndash; vừa đủ c&ocirc;ng nghệ, vừa tối ưu chi ph&iacute;.</p>\r\n<h2><span id=\"phu-hop\">5. Ai n&ecirc;n chọn Adidas F50 Messi?</span></h2>\r\n<ul>\r\n<li>Cầu thủ r&ecirc; dắt, th&iacute;ch xử l&yacute; b&oacute;ng trong phạm vi hẹp</li>\r\n<li>Người chơi đ&aacute; bi&ecirc;n hoặc tiền đạo nhỏ con thi&ecirc;n kỹ thuật</li>\r\n<li>Anh em th&iacute;ch cảm gi&aacute;c b&oacute;ng r&otilde;, phản hồi nhanh</li>\r\n</ul>\r\n<p>Kh&ocirc;ng ph&ugrave; hợp nếu:</p>\r\n<ul>\r\n<li>Bạn c&oacute; b&agrave;n ch&acirc;n qu&aacute; b&egrave; ngang</li>\r\n<li>Ưu ti&ecirc;n độ &ecirc;m d&agrave;y như d&ograve;ng kiểm so&aacute;t truyền thống</li>\r\n</ul>\r\n<p>Nếu đang t&igrave;m một đ&ocirc;i&nbsp;gi&agrave;y b&oacute;ng đ&aacute;&nbsp;thi&ecirc;n về kỹ thuật v&agrave; tăng tốc ngắn, F50 Messi l&agrave; lựa chọn rất đ&aacute;ng c&acirc;n nhắc.</p>\r\n<h2><span id=\"ket-noi-silo\">6. C&aacute;c b&agrave;i chi tiết về F50 Messi</span></h2>\r\n<ul>\r\n<li>Đ&aacute;nh gi&aacute; chi tiết F50 Messi Elite</li>\r\n<li>Ph&acirc;n t&iacute;ch hiệu năng F50 Messi Pro s&acirc;n 7</li>\r\n<li>Cảm nhận thực tế F50 Messi League phong tr&agrave;o</li>\r\n<li>So s&aacute;nh F50 Messi v&agrave; F50 thường</li>\r\n</ul>\r\n<h2><span id=\"he-thong-the-gioi-bong-da\">Hệ thống cửa h&agrave;ng Beyond</span></h2>\r\n<p>C&aacute;c nhận định v&agrave; trải nghiệm trong b&agrave;i được tổng hợp từ thực tế tư vấn, thử gi&agrave;y v&agrave; phản hồi của kh&aacute;ch h&agrave;ng tại hệ thống cửa h&agrave;ng Thế Giới B&oacute;ng Đ&aacute; &ndash; chuy&ecirc;n gi&agrave;y đ&aacute; b&oacute;ng ch&iacute;nh h&atilde;ng.</p>\r\n<p>Tại cửa h&agrave;ng, kh&aacute;ch h&agrave;ng c&oacute; thể thử trực tiếp từng d&ograve;ng gi&agrave;y theo form ch&acirc;n, được tư vấn size ph&ugrave; hợp v&agrave; hỗ trợ đổi size nếu chưa vừa khi sử dụng thực tế.</p>\r\n</div>','2025-09-03 14:26:33.062735','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777606334/cdxecyfvh2ois3n5btfy.jpg','',0,'Adidas F50 Messi – Di sản tốc độ mang dấu ấn của một huyền thoại','adidas-f50-messi-di-san-toc-o-mang-dau-an-cua-mot-huyen-thoai','Adidas F50 Messi – Di sản tốc độ mang dấu ấn của một huyền thoại','2026-05-10 00:39:04.780186',NULL),(19,'<h1 style=\"text-align: center;\">Nike \'Heat Up\' Pack: Bộ sưu tập gi&agrave;y đ&aacute; b&oacute;ng Nike mới</h1>\r\n<div class=\"title-main-home\">\r\n<figure class=\"image\" style=\"text-align: center;\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/nike1-1-1.jpg\" alt=\"Nike \'Heat Up\' Pack\" width=\"1000\" height=\"667\" />\r\n<figcaption>Nike \'Heat Up\' Pack</figcaption>\r\n</figure>\r\n<div id=\"toc_container\" class=\"no_bullets\">\r\n<p class=\"toc_title\" style=\"text-align: center;\">&nbsp;</p>\r\n<p class=\"toc_title\" style=\"text-align: center;\"><strong>Mục lục</strong></p>\r\n<p style=\"text-align: center;\">1. Nike Heat Up Pack l&agrave; g&igrave;?</p>\r\n<p style=\"text-align: center;\">2. Điểm nổi bật của Nike Heat Up Pack</p>\r\n<p style=\"text-align: center;\">3. C&aacute;c d&ograve;ng gi&agrave;y c&oacute; trong Nike Heat Up Pack</p>\r\n<p style=\"text-align: center;\">4. Thiết kế m&agrave;u sắc v&agrave; ng&ocirc;n ngữ thị gi&aacute;c</p>\r\n<p style=\"text-align: center;\">5. Nike Heat Up Pack ph&ugrave; hợp với ai?</p>\r\n<p style=\"text-align: center;\">6. Gợi &yacute; chọn nhanh theo nhu cầu</p>\r\n<p style=\"text-align: center;\">7. Mua gi&agrave;y đ&aacute; b&oacute;ng Nike ở đ&acirc;u để được tư vấn đ&uacute;ng?</p>\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n</div>\r\n<p>Nike \"Heat Up\" Pack l&agrave; bộ sưu tập mới xoay quanh ba silo quan trọng của Nike Football: Mercurial, Phantom v&agrave; Tiempo. Điểm chung của pack n&agrave;y nằm ở nền m&agrave;u tối, phối c&ugrave;ng c&aacute;c chi tiết chuyển sắc v&agrave; điểm nhấn m&agrave;u nổi để tạo cảm gi&aacute;c nổi bật hơn khi l&ecirc;n s&acirc;n.</p>\r\n<p>Với người chơi phong tr&agrave;o s&acirc;n cỏ nh&acirc;n tạo, đ&acirc;y kh&ocirc;ng chỉ l&agrave; một pack mới về m&agrave;u sắc. Điều đ&aacute;ng quan t&acirc;m hơn l&agrave; mỗi d&ograve;ng gi&agrave;y trong pack vẫn giữ đ&uacute;ng định hướng quen thuộc của Nike: Mercurial thi&ecirc;n tốc độ v&agrave; cảm gi&aacute;c bứt l&ecirc;n nhanh, Phantom thi&ecirc;n kiểm so&aacute;t v&agrave; xử l&yacute; b&oacute;ng, c&ograve;n Tiempo thi&ecirc;n sự ổn định, &ecirc;m ch&acirc;n v&agrave; cảm gi&aacute;c tiếp x&uacute;c b&oacute;ng dễ chịu hơn.</p>\r\n<p>Nếu đang t&igrave;m một đ&ocirc;i trong bộ sưu tập n&agrave;y, anh em c&oacute; thể xem th&ecirc;m danh mục&nbsp;gi&agrave;y đ&aacute; b&oacute;ng Nike, hoặc đi thẳng v&agrave;o từng d&ograve;ng như&nbsp;Nike Mercurial,&nbsp;Nike Phantom&nbsp;v&agrave;&nbsp;Nike Tiempo&nbsp;để chọn đ&uacute;ng hơn theo lối chơi.</p>\r\n<h2><span id=\"nike-heat-up-pack-la-gi\">1. Nike Heat Up Pack l&agrave; g&igrave;?</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/nike2-1.jpg\" alt=\"Nike \'Heat Up\' Pack 2\" width=\"1920\" height=\"1250\" />\r\n<figcaption>Nike \'Heat Up\' Pack</figcaption>\r\n</figure>\r\n<p>\"Heat Up\" Pack l&agrave; bộ sưu tập colorway mới của Nike d&agrave;nh cho ba d&ograve;ng gi&agrave;y chủ lực. Về tổng thể, pack n&agrave;y đi theo hướng tương phản giữa nền upper đen chủ đạo v&agrave; c&aacute;c chi tiết m&agrave;u s&aacute;ng, tạo hiệu ứng nh&igrave;n kh&aacute; gọn nhưng vẫn đủ nổi bật khi di chuyển.</p>\r\n<p>C&aacute;ch l&agrave;m n&agrave;y ph&ugrave; hợp với những người th&iacute;ch gi&agrave;y đ&aacute; b&oacute;ng c&oacute; ngoại h&igrave;nh mạnh, &iacute;t ph&ocirc; trương hơn kiểu phối m&agrave;u s&aacute;ng to&agrave;n bộ nhưng vẫn c&oacute; điểm nhấn r&otilde; tr&ecirc;n s&acirc;n. Thực tế tại cửa h&agrave;ng, nh&oacute;m kh&aacute;ch chơi s&acirc;n 7 thường chia l&agrave;m hai kiểu: một nh&oacute;m th&iacute;ch phối m&agrave;u s&aacute;ng dễ nổi, nh&oacute;m c&ograve;n lại th&iacute;ch nền tối v&igrave; nh&igrave;n sạch hơn trong qu&aacute; tr&igrave;nh sử dụng. Nike Heat Up Pack nằm kh&aacute; đ&uacute;ng nhu cầu của nh&oacute;m thứ hai.</p>\r\n<p>Về mặt định hướng nội dung, đ&acirc;y l&agrave; một b&agrave;i thuộc nh&aacute;nh Nike Football, n&ecirc;n nếu anh em đang t&igrave;m th&ecirc;m c&aacute;c mẫu d&ugrave;ng cho&nbsp;s&acirc;n cỏ nh&acirc;n tạo, c&oacute; thể xem theo danh mục để lọc nhanh hơn theo mặt s&acirc;n v&agrave; nhu cầu sử dụng thực tế.</p>\r\n<h2><span id=\"diem-noi-bat-cua-nike-heat-up-pack\">2. Điểm nổi bật của Nike Heat Up Pack</span></h2>\r\n<ul>\r\n<li>Nền m&agrave;u đen chủ đạo, tạo cảm gi&aacute;c gọn v&agrave; dễ d&ugrave;ng tr&ecirc;n s&acirc;n.</li>\r\n<li>Chi tiết chuyển sắc v&agrave; m&agrave;u nổi gi&uacute;p đ&ocirc;i gi&agrave;y nổi bật hơn khi di chuyển dưới &aacute;nh s&aacute;ng.</li>\r\n<li>Gồm ba silo quen thuộc của Nike: Mercurial, Phantom v&agrave; Tiempo.</li>\r\n<li>Mỗi d&ograve;ng vẫn giữ đ&uacute;ng định hướng sử dụng ri&ecirc;ng, kh&ocirc;ng chỉ đổi m&agrave;u đơn thuần.</li>\r\n<li>Ph&ugrave; hợp với người chơi th&iacute;ch phối m&agrave;u tối nhưng vẫn muốn đ&ocirc;i gi&agrave;y c&oacute; điểm nhấn r&otilde;.</li>\r\n</ul>\r\n<p>Điểm hay của một collection như Heat Up Pack l&agrave; người chơi c&oacute; thể chọn đ&uacute;ng d&ograve;ng gi&agrave;y m&igrave;nh quen d&ugrave;ng m&agrave; kh&ocirc;ng phải đ&aacute;nh đổi sang một form ho&agrave;n to&agrave;n kh&aacute;c chỉ v&igrave; th&iacute;ch m&agrave;u. Điều n&agrave;y kh&aacute; quan trọng, v&igrave; trong thực tế tư vấn tại cửa h&agrave;ng, nhiều người thường chọn gi&agrave;y theo m&agrave;u trước rồi mới để &yacute; đến form. Kết quả l&agrave; mang l&ecirc;n đẹp nhưng cảm gi&aacute;c chạy v&agrave; &ocirc;m ch&acirc;n lại kh&ocirc;ng hợp.</p>\r\n<h2><span id=\"cac-dong-giay-co-trong-nike-heat-up-pack\">3. C&aacute;c d&ograve;ng gi&agrave;y c&oacute; trong Nike Heat Up Pack</span></h2>\r\n<p>Bộ sưu tập n&agrave;y gồm ba d&ograve;ng ch&iacute;nh, đại diện cho ba kiểu chơi kh&aacute;c nhau trong hệ sinh th&aacute;i Nike Football.</p>\r\n<h3>Mercurial</h3>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/nike4-1.jpg\" alt=\"Nike \'Heat Up\' Pack - Mercurial\" width=\"1920\" height=\"1250\" />\r\n<figcaption>Nike \'Heat Up\' Pack - Mercurial</figcaption>\r\n</figure>\r\n<p>D&ograve;ng nổi bật nhất trong pack l&agrave; Nike Air Zoom Mercurial Vapor v&agrave; phi&ecirc;n bản cổ cao Superfly, với nền đen kết hợp điểm nhấn Hyper Crimson. Mercurial vẫn l&agrave; lựa chọn quen thuộc cho người th&iacute;ch cảm gi&aacute;c gọn ch&acirc;n, v&agrave;o b&oacute;ng nhanh v&agrave; tăng tốc dứt kho&aacute;t. Với anh em chơi bi&ecirc;n, tiền đạo hoặc thường xuy&ecirc;n bứt tốc ở qu&atilde;ng ngắn,&nbsp;Nike Mercurial&nbsp;lu&ocirc;n l&agrave; một trong những d&ograve;ng được hỏi nhiều nhất.</p>\r\n<h3>Phantom</h3>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/nike6-1.jpg\" alt=\"nike6-1.jpg\" width=\"1920\" height=\"1250\" /></figure>\r\n<p>Nike Phantom trong Heat Up Pack mang phối m&agrave;u Med Ash/Gold Amber/Black. Tinh thần chung vẫn l&agrave; nền tối đi c&ugrave;ng c&aacute;c chi tiết tạo hiệu ứng &aacute;nh s&aacute;ng khi nh&igrave;n nghi&ecirc;ng hoặc khi di chuyển. So với Mercurial,&nbsp;Nike Phantom&nbsp;thường ph&ugrave; hợp hơn với người th&iacute;ch cảm gi&aacute;c kiểm so&aacute;t b&oacute;ng, xử l&yacute; b&oacute;ng trong kh&ocirc;ng gian hẹp v&agrave; muốn upper cho cảm gi&aacute;c b&aacute;m b&oacute;ng r&otilde; hơn.</p>\r\n<h3>Tiempo</h3>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/nike5-1.jpg\" alt=\"Nike \'Heat Up\' Pack - Tiempo\" width=\"1920\" height=\"1250\" />\r\n<figcaption>Nike \'Heat Up\' Pack - Tiempo</figcaption>\r\n</figure>\r\n<p>D&ograve;ng c&ograve;n lại l&agrave; Nike Tiempo Maestro với phối m&agrave;u Black/Laser Orange/Hyper Crimson. Đ&acirc;y l&agrave; hướng thiết kế kh&aacute; hợp với Tiempo v&igrave; upper mềm v&agrave; thi&ecirc;n cảm gi&aacute;c &ocirc;m ch&acirc;n dễ chịu vốn đ&atilde; l&agrave; điểm được nhiều người chơi phong tr&agrave;o đ&aacute;nh gi&aacute; cao. Nếu ưu ti&ecirc;n sự ổn định, mang l&acirc;u &iacute;t bị g&ograve; ch&acirc;n v&agrave; cần một đ&ocirc;i gi&agrave;y dễ l&agrave;m quen hơn,&nbsp;Nike Tiempo&nbsp;vẫn l&agrave; lựa chọn an to&agrave;n hơn cho số đ&ocirc;ng.</p>\r\n<p>Nh&igrave;n ở g&oacute;c độ sưu tập, Heat Up Pack kh&ocirc;ng cố biến mọi d&ograve;ng th&agrave;nh c&ugrave;ng một kiểu chơi. Nike chỉ giữ chung một ng&ocirc;n ngữ m&agrave;u sắc, c&ograve;n bản chất từng silo vẫn r&otilde; r&agrave;ng. Đ&acirc;y l&agrave; điểm tốt với người mua thực tế, v&igrave; chọn pack mới nhưng vẫn dựa tr&ecirc;n nền tảng quen thuộc của từng d&ograve;ng gi&agrave;y.</p>\r\n<h2><span id=\"thiet-ke-mau-sac-va-ngon-ngu-thi-giac\">4. Thiết kế m&agrave;u sắc v&agrave; ng&ocirc;n ngữ thị gi&aacute;c</span></h2>\r\n<p>Điểm chung r&otilde; nhất của Nike Heat Up Pack l&agrave; nền tối đi c&ugrave;ng c&aacute;c mảng m&agrave;u nổi hoặc chi tiết chuyển sắc. Thay v&igrave; d&ugrave;ng upper s&aacute;ng to&agrave;n bộ, pack n&agrave;y tạo cảm gi&aacute;c \"ẩn nhưng kh&ocirc;ng ch&igrave;m\": nh&igrave;n tổng thể vẫn gọn, nhưng khi l&ecirc;n s&acirc;n hoặc gặp &aacute;nh s&aacute;ng mạnh th&igrave; c&aacute;c chi tiết mới hiện r&otilde; hơn.</p>\r\n<p>Tr&ecirc;n Mercurial, Swoosh lớn v&agrave; phần branding tạo cảm gi&aacute;c nổi mạnh hơn, hợp với tinh thần tốc độ. Tr&ecirc;n Phantom, hiệu ứng chuyển sắc được xử l&yacute; tiết chế hơn, ph&ugrave; hợp với kiểu d&aacute;ng thi&ecirc;n kiểm so&aacute;t. C&ograve;n với Tiempo, c&aacute;c đường n&eacute;t v&agrave; mảng m&agrave;u đặt tr&ecirc;n upper tạo cảm gi&aacute;c hiện đại hơn nhưng vẫn giữ được vẻ chắc v&agrave; ổn định đặc trưng của d&ograve;ng n&agrave;y.</p>\r\n<p>Với người chơi phong tr&agrave;o, yếu tố m&agrave;u sắc kh&ocirc;ng quyết định hiệu năng, nhưng lại ảnh hưởng kh&aacute; r&otilde; đến cảm gi&aacute;c chọn mua. Nhiều anh em th&iacute;ch đ&ocirc;i gi&agrave;y nh&igrave;n sắc, gọn, &iacute;t bị bẩn m&agrave;u v&agrave; dễ phối đồ đ&aacute; b&oacute;ng. Heat Up Pack l&agrave;m kh&aacute; tốt điểm đ&oacute;, nhất l&agrave; với những ai kh&ocirc;ng th&iacute;ch kiểu phối m&agrave;u qu&aacute; s&aacute;ng.</p>\r\n<h2><span id=\"nike-heat-up-pack-phu-hop-voi-ai\">5. Nike Heat Up Pack ph&ugrave; hợp với ai?</span></h2>\r\n<p>Bộ sưu tập n&agrave;y ph&ugrave; hợp với người chơi muốn một đ&ocirc;i gi&agrave;y Nike mới về m&agrave;u sắc nhưng vẫn giữ đ&uacute;ng t&iacute;nh c&aacute;ch quen thuộc của từng d&ograve;ng.</p>\r\n<ul>\r\n<li><strong>Người th&iacute;ch cảm gi&aacute;c bứt tốc, gọn ch&acirc;n:</strong>&nbsp;n&ecirc;n ưu ti&ecirc;n Mercurial.</li>\r\n<li><strong>Người cần kiểm so&aacute;t b&oacute;ng, xử l&yacute; linh hoạt:</strong>&nbsp;n&ecirc;n ưu ti&ecirc;n Phantom.</li>\r\n<li><strong>Người ưu ti&ecirc;n sự &ecirc;m ch&acirc;n, dễ mang v&agrave; ổn định:</strong>&nbsp;n&ecirc;n ưu ti&ecirc;n Tiempo.</li>\r\n<li><strong>Người th&iacute;ch phối m&agrave;u tối, dễ d&ugrave;ng l&acirc;u:</strong>&nbsp;Heat Up Pack l&agrave; lựa chọn dễ hợp mắt.</li>\r\n</ul>\r\n<p>Thực tế tại cửa h&agrave;ng, c&acirc;u hỏi phổ biến nhất kh&ocirc;ng phải l&agrave; &ldquo;đ&ocirc;i n&agrave;o đẹp nhất&rdquo; m&agrave; l&agrave; &ldquo;đ&ocirc;i n&agrave;o hợp ch&acirc;n v&agrave; đ&aacute; c&oacute; thoải m&aacute;i kh&ocirc;ng&rdquo;. V&igrave; vậy, với một collection như Heat Up Pack, điều quan trọng kh&ocirc;ng nằm ở việc chọn m&agrave;u n&agrave;o nổi hơn, m&agrave; l&agrave; chọn đ&uacute;ng nền tảng sản phẩm b&ecirc;n dưới.</p>\r\n<p>Nếu anh em mới bắt đầu t&igrave;m gi&agrave;y Nike, c&aacute;ch dễ nhất l&agrave; x&aacute;c định nhu cầu chơi trước, sau đ&oacute; mới quay lại chọn phối m&agrave;u trong pack. L&agrave;m như vậy sẽ giảm nhiều khả năng mua theo cảm hứng nhưng d&ugrave;ng kh&ocirc;ng hợp ch&acirc;n hoặc kh&ocirc;ng hợp lối đ&aacute;.</p>\r\n<h2><span id=\"goi-y-chon-nhanh-theo-nhu-cau\">6. Gợi &yacute; chọn nhanh theo nhu cầu</span></h2>\r\n<p>Dưới đ&acirc;y l&agrave; c&aacute;ch chọn nhanh nếu anh em đang ph&acirc;n v&acirc;n giữa c&aacute;c d&ograve;ng trong Nike Heat Up Pack:</p>\r\n<ul>\r\n<li><strong>Chọn Mercurial</strong>&nbsp;nếu anh em th&iacute;ch form &ocirc;m hơn, cảm gi&aacute;c ch&acirc;n gọn v&agrave; ưu ti&ecirc;n những pha bứt tốc hoặc đổi hướng nhanh.</li>\r\n<li><strong>Chọn Phantom</strong>&nbsp;nếu anh em muốn cảm gi&aacute;c xử l&yacute; b&oacute;ng r&otilde;, th&iacute;ch r&ecirc; b&oacute;ng, giữ b&oacute;ng v&agrave; chơi thi&ecirc;n về kiểm so&aacute;t hơn.</li>\r\n<li><strong>Chọn Tiempo</strong>&nbsp;nếu anh em ưu ti&ecirc;n sự c&acirc;n bằng, dễ l&agrave;m quen, mang &ecirc;m hơn v&agrave; &iacute;t bị gắt ch&acirc;n khi sử dụng thời gian d&agrave;i.</li>\r\n</ul>\r\n<p>Nếu vẫn chưa chắc n&ecirc;n đi theo d&ograve;ng n&agrave;o, c&oacute; thể bắt đầu từ danh mục&nbsp;gi&agrave;y đ&aacute; b&oacute;ng&nbsp;để xem tổng thể, sau đ&oacute; lọc s&acirc;u hơn theo&nbsp;gi&agrave;y đ&aacute; b&oacute;ng Nike. C&aacute;ch n&agrave;y ph&ugrave; hợp với người đang so s&aacute;nh nhiều mẫu trong c&ugrave;ng thương hiệu trước khi chốt một form gi&agrave;y cụ thể.</p>\r\n<h2><span id=\"mua-giay-da-bong-nike-o-dau-de-duoc-tu-van-dung\">7. Mua gi&agrave;y đ&aacute; b&oacute;ng Nike ở đ&acirc;u để được tư vấn đ&uacute;ng?</span></h2>\r\n<p>Với c&aacute;c bộ sưu tập như Nike Heat Up Pack, điều dễ bị bỏ qua l&agrave; c&ugrave;ng một phối m&agrave;u đẹp nhưng trải nghiệm thực tế giữa Mercurial, Phantom v&agrave; Tiempo lại rất kh&aacute;c nhau. V&igrave; vậy, c&aacute;ch chọn an to&agrave;n nhất vẫn l&agrave; thử trực tiếp để kiểm tra độ &ocirc;m ch&acirc;n, cảm gi&aacute;c upper v&agrave; độ ổn định khi di chuyển tr&ecirc;n s&acirc;n cỏ nh&acirc;n tạo.</p>\r\n<p>Tại Thế Giới B&oacute;ng Đ&aacute;, nhiều kh&aacute;ch khi đến thử thường đổi &yacute; sau khi mang l&ecirc;n ch&acirc;n. C&oacute; người ban đầu th&iacute;ch Mercurial v&igrave; d&aacute;ng gọn, nhưng sau khi thử lại thấy Tiempo hợp hơn do ch&acirc;n b&egrave; nhẹ v&agrave; cần cảm gi&aacute;c dễ chịu hơn khi đ&aacute; s&acirc;n 7. Cũng c&oacute; người đang d&ugrave;ng gi&agrave;y form rộng lại chuyển sang Phantom v&igrave; muốn cảm gi&aacute;c xử l&yacute; b&oacute;ng gọn v&agrave; r&otilde; hơn. Những kh&aacute;c biệt n&agrave;y kh&oacute; nh&igrave;n hết chỉ qua ảnh pack hoặc th&ocirc;ng tin m&agrave;u sắc.</p>\r\n<p>Nếu anh em đang quan t&acirc;m bộ sưu tập n&agrave;y, n&ecirc;n ưu ti&ecirc;n thử theo đ&uacute;ng d&ograve;ng gi&agrave;y m&igrave;nh đang hướng tới trước, rồi mới chọn colorway ph&ugrave; hợp. C&aacute;ch chọn đ&oacute; thực tế hơn v&agrave; giảm rủi ro mua đẹp nhưng kh&ocirc;ng hợp nhu cầu sử dụng.</p>\r\n<h2><span id=\"he-thong-the-gioi-bong-da\">Hệ thống cửa h&agrave;ng Beyond</span></h2>\r\n<p>C&aacute;c nhận định v&agrave; trải nghiệm trong b&agrave;i được tổng hợp từ thực tế tư vấn, thử gi&agrave;y v&agrave; phản hồi của kh&aacute;ch h&agrave;ng tại hệ thống cửa h&agrave;ng Thế Giới B&oacute;ng Đ&aacute; &ndash; chuy&ecirc;n gi&agrave;y đ&aacute; b&oacute;ng, đồ pickleball ch&iacute;nh h&atilde;ng.</p>\r\n<p>Tại cửa h&agrave;ng, kh&aacute;ch h&agrave;ng c&oacute; thể thử trực tiếp từng d&ograve;ng gi&agrave;y theo form ch&acirc;n, được tư vấn size ph&ugrave; hợp v&agrave; hỗ trợ đổi size nếu chưa vừa khi sử dụng thực tế.</p>\r\n</div>','2025-09-03 14:27:26.857580','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777605402/s66vdg4rhx5c2cpd36tl.jpg','',0,'Nike \'Heat Up\' Pack: Bộ sưu tập giày đá bóng Nike mới','nike-heat-up-pack-bo-suu-tap-giay-a-bong-nike-moi','Nike \'Heat Up\' Pack: Bộ sưu tập giày đá bóng Nike mới','2026-05-01 11:18:09.719685',NULL),(20,'<h1 class=\"title\" style=\"text-align: center;\">B&ugrave;ng nổ với sự kết hợp Zocker Inspire x Đỗ H&ugrave;ng Dũng</h1>\r\n<p>&nbsp;</p>\r\n<p>Zocker l&agrave; Thương hiệu gi&agrave;y b&oacute;ng đ&aacute; s&acirc;n phủi được rất nhiều anh em trong giới biết đến v&agrave; tin tưởng sử dụng. Hiểu được những gi&aacute; trị tinh thần m&agrave; nh&atilde;n h&agrave;ng đ&atilde; đem đến cho anh em s&acirc;n phủi, Zocker đ&atilde; quyết định cho ra mắt Bộ sưu tập mới mang t&ecirc;n Zocker Inspire.</p>\r\n<p>Kh&ocirc;ng chỉ kh&aacute;c biệt về thiết kế m&agrave;u sắc, lần n&agrave;y Zocker c&ograve;n tạo n&ecirc;n sự kết hơp ho&agrave;n hảo kh&ocirc;ng thể &ldquo;chối từ&rdquo; giữa Zocker Inspire x Đỗ H&ugrave;ng Dũng - Đội Trưởng Đội tuyển Quốc gia Việt Nam.</p>\r\n<p>Sự ra đời của Si&ecirc;u phẩm lần n&agrave;y được bắt nguồn từ sự cố gắng kh&ocirc;ng ngừng của Đỗ H&ugrave;ng Dũng trong suốt thời gian qua</p>\r\n<p style=\"text-align: center;\"><img src=\"https://zocker.vn/Pic/images/chuong-trinh-dong-hanh/do-hung-dung-zocker-inspire%20(1).jpg\" alt=\"do-hung-dung-zocker-inspire\" /></p>\r\n<p>Để đến được với s&acirc;n cỏ, cậu thiếu ni&ecirc;n Dũng &ldquo;Ch&iacute;p&rdquo; đ&atilde; phải nỗ lực rất nhiều nhằm chứng tỏ quyết t&acirc;m cũng như thuyết phục gia đ&igrave;nh đồng &yacute; cho tham gia v&agrave; gắn cuộc đời m&igrave;nh với một m&ocirc;n thể thao c&oacute; t&iacute;nh đua tranh khốc liệt như b&oacute;ng đ&aacute;. Kh&ocirc;ng những thế H&ugrave;ng Dũng đ&atilde; phải trải qua 1 thời gian d&agrave;i để hồi phục chấn thương kh&ocirc;ng mong muốn trong một giải đấu.</p>\r\n<p>H&agrave;nh tr&igrave;nh của một Thương hiệu cũng tương tự như một con người. Trong qu&aacute; tr&igrave;nh h&igrave;nh th&agrave;nh v&agrave; ph&aacute;t triển, Zocker đ&atilde; can đảm bước đi tr&ecirc;n con đường trải đầy ch&ocirc;ng gai. Dựa tr&ecirc;n khả năng t&agrave;i ch&iacute;nh v&agrave; lối chơi người Việt, mỗi năm, Zocker đều cho ra mắt những mẫu gi&agrave;y mới, từ: ZTF 18VT, ZTF 1902, Santo 2101, Space,&hellip; Mỗi thế hệ gi&agrave;y đều lưu giữ những dấu ấn trong nỗ lực cải tiến về chất liệu, n&acirc;ng cao độ bền v&agrave; chất lượng sản phẩm, ứng dụng c&ocirc;ng nghệ mới để mang lại những đ&ocirc;i gi&agrave;y đ&aacute; b&oacute;ng c&oacute; thể cạnh tranh s&ograve;ng phẳng với h&agrave;ng ngoại nhập từ c&aacute;c thương hiệu h&agrave;ng đầu.</p>\r\n<p>Con đường đ&atilde; đi tạo ra sự đồng cảm, mang đến mối &ldquo;lương duy&ecirc;n&rdquo; giữa Zocker v&agrave; H&ugrave;ng Dũng, vững bước tiến về ph&iacute;a trước.</p>\r\n<p style=\"text-align: center;\"><img src=\"https://zocker.vn/Pic/images/chuong-trinh-dong-hanh/do-hung-dung-zocker-inspire-2%20(1).jpg\" alt=\"do-hung-dung-zocker-inspire-2\" /></p>\r\n<p>Khi trực tiếp tr&ecirc;n tay sản phẩm, Đỗ H&ugrave;ng Dũng c&oacute; n&oacute;i: &ldquo;Dũng rất vui khi l&agrave; người được trải nghiệm đầu ti&ecirc;n mẫu gi&agrave;y m&agrave; m&igrave;nh đang hợp t&aacute;c. Thiết kế của mẫu gi&agrave;y n&agrave;y rất nổi bật, &ecirc;m mềm, kiểm so&aacute;t b&oacute;ng tốt, Dũng c&oacute; thể thoải m&aacute;i kiến tạo những đường b&oacute;ng của m&igrave;nh. Zocker Inspire được nh&atilde;n h&agrave;ng chăm ch&uacute;t rất kĩ lưỡng v&agrave; Dũng tin rằng anh em trong giới phủi sẽ th&iacute;ch mẫu gi&agrave;y n&agrave;y&rdquo;.</p>\r\n<p>Zocker Inspire được sử dụng chất liệu da PU cao cấp, c&oacute; khả năng đ&agrave;n hồi gấp 1.5 lần so với c&aacute;c phi&ecirc;n bản cũ, kh&ocirc;ng chỉ &ocirc;m vừa kh&iacute;t ch&acirc;n, tăng độ bền m&agrave; c&ograve;n bảo vệ tốt hơn cho đ&ocirc;i ch&acirc;n. Lớp đế giữa l&agrave; chất liệu tổng hợp, c&ugrave;ng với l&oacute;t gi&agrave;y từ cao su non rất &ecirc;m ch&acirc;n, giảm t&aacute;c động của phản lực l&ecirc;n ch&acirc;n hiệu quả. Phần đế gi&agrave;y sử dụng cao su đ&uacute;c nguy&ecirc;n khối mang đến sự chắc ch&acirc;n, khả năng đ&agrave;n hồi cao cũng gi&uacute;p cầu thủ tăng tốc thuận lợi.</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"https://zocker.vn/Pic/images/chuong-trinh-dong-hanh/do-hung-dung-zocker-inspire-3%20(1).jpg\" alt=\"do-hung-dung-zocker-inspire-3\" /></p>\r\n<p>Zocker Inspire được ứng dụng c&ocirc;ng nghệ ma s&aacute;t k&eacute;p cho phần đế, sử dụng c&ugrave;ng l&uacute;c 2 loại đinh dăm. Đinh tr&ograve;n gi&uacute;p chắc ch&acirc;n, hỗ trợ tăng tốc. Đinh h&igrave;nh ng&ocirc;i sao 3 c&aacute;nh gi&uacute;p cầu thủ kh&ocirc;ng bị ngừng đột ngột khi v&agrave;o b&oacute;ng, từ đ&oacute; ph&ograve;ng ngừa chấn thương lật cổ ch&acirc;n (rất phổ biến trong b&oacute;ng đ&aacute;).</p>\r\n<p>Sản phẩm được thiết kế theo phong c&aacute;ch đơn sắc (All color) với 4 phi&ecirc;n bản m&agrave;u: Xanh ngọc, Cam, Xanh chuối, Trắng; Đồng t&ocirc;ng từ upper &ndash; đế - đế đinh &ndash; lưỡi g&agrave; &ndash; v&agrave; d&acirc;y buộc. C&aacute;c họa tiết chấm tr&ograve;n ngẫu hứng c&ugrave;ng c&aacute;c đường kẻ đan xen mang đến n&eacute;t chấm ph&aacute;, c&ugrave;ng sự trẻ trung, s&aacute;ng tạo. Logo Zocker nổi bật h&igrave;nh ch&uacute; s&oacute;c th&ocirc;ng minh, linh hoạt.</p>\r\n<p><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"https://zocker.vn/Pic/images/chuong-trinh-dong-hanh/do-hung-dung-zocker-inspire-4%20(1).jpg\" alt=\"do-hung-dung-zocker-inspire-4\" /></p>\r\n<p>Kh&ocirc;ng dễ để một Thương hiệu c&oacute; thể thực sự hợp t&aacute;c với một cầu thủ, để cho ra một sản phẩm mang cảm hứng từ c&aacute;ch chơi của ch&iacute;nh cầu thủ ấy. C&oacute; thể khẳng định, ngay từ khi thai ngh&eacute;n &yacute; tưởng, c&aacute;c kỹ sư của h&atilde;ng đ&atilde; nghĩ về H&ugrave;ng Dũng c&ugrave;ng tinh thần bền bỉ, &yacute; ch&iacute; vươn l&ecirc;n, kh&ocirc;ng ngại kh&oacute;, kh&ocirc;ng ngại khổ. Inspire truyền đi th&ocirc;ng điệp: &ldquo;Thể thao tạo n&ecirc;n sức mạnh&rdquo;. Mong rằng tinh thần thể thao, thượng v&otilde; từ H&ugrave;ng Dũng, Zocker, từ trong b&oacute;ng đ&aacute; sẽ truyền cảm hứng để mỗi người trong ch&uacute;ng ta: Ai cũng c&oacute; thể chạm đến th&agrave;nh c&ocirc;ng, chỉ cần bạn hiểu rằng &ldquo;Đừng giả vờ nỗ lực, v&igrave; kết quả kh&ocirc;ng bao giờ n&oacute;i dối&rdquo;.&nbsp;</p>','2025-09-03 14:28:19.933410','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777608588/znzb4yz5rchucip5cgva.jpg','',0,'Bùng nổ với sự kết hợp Zocker Inspire x Đỗ Hùng Dũng','bung-no-voi-su-ket-hop-zocker-inspire-x-o-hung-dung','Bùng nổ với sự kết hợp Zocker Inspire x Đỗ Hùng Dũng','2026-05-01 11:18:25.174882',NULL),(21,'<h1 style=\"text-align: center;\">Review Nike Tiempo Maestro Elite FG - Tiempo bước sang kỷ nguy&ecirc;n mới</h1>\r\n<div class=\"title-main-home\">\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260129_BWGQJVR3.jpg\" alt=\"Nike Tiempo Maestro Elite FG\" width=\"1000\" height=\"667\" />\r\n<figcaption>Nike Tiempo Maestro Elite FG</figcaption>\r\n</figure>\r\n<div id=\"toc_container\" class=\"no_bullets\">\r\n<p class=\"toc_title\" style=\"text-align: center;\"><strong>Mục lục</strong></p>\r\n<p style=\"text-align: center;\">1. Giới thiệu</p>\r\n<p style=\"text-align: center;\">2. Upper Tech Leather &ndash; mềm nhất Nike từng l&agrave;m?</p>\r\n<p style=\"text-align: center;\">3. Form gi&agrave;y &amp; cảm gi&aacute;c mang thực tế</p>\r\n<p style=\"text-align: center;\">4. Cảm gi&aacute;c b&oacute;ng &amp; khả năng kiểm so&aacute;t</p>\r\n<p style=\"text-align: center;\">5. Đế Maestro360 &amp; độ b&aacute;m s&acirc;n</p>\r\n<p style=\"text-align: center;\">6. Những điểm cần c&acirc;n nhắc</p>\r\n<p style=\"text-align: center;\">7. Đ&aacute;nh gi&aacute; tổng kết</p>\r\n</div>\r\n<h2><span id=\"gioi-thieu\">1. Giới thiệu</span></h2>\r\n<p>Sau hơn 20 năm v&agrave; 10 thế hệ mang t&ecirc;n Tiempo Legend, Nike ch&iacute;nh thức kh&eacute;p lại một kỷ nguy&ecirc;n để mở ra chương mới với&nbsp;<strong>Nike Tiempo Maestro Elite</strong>. Đ&acirc;y kh&ocirc;ng chỉ l&agrave; bản n&acirc;ng cấp, m&agrave; l&agrave; một cuộc t&aacute;i định hướng ho&agrave;n to&agrave;n của d&ograve;ng Tiempo &ndash; từ h&igrave;nh ảnh &ldquo;gi&agrave;y hậu vệ chắc chắn&rdquo; quay trở lại đ&uacute;ng bản chất:&nbsp;<strong>đ&ocirc;i gi&agrave;y của nhạc trưởng s&acirc;n cỏ</strong>.</p>\r\n<p>Trong hệ sinh th&aacute;i&nbsp;Nike Tiempo Maestro, phi&ecirc;n bản Elite l&agrave; nơi Nike thể hiện r&otilde; nhất tham vọng đ&oacute;.</p>\r\n<figure class=\"image align-center\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260129_O0Q7ZV8m.jpg\" alt=\"Nike Tiempo Maestro Elite FG 2\" width=\"1000\" height=\"667\" />\r\n<figcaption>Nike Tiempo Maestro Elite FG</figcaption>\r\n</figure>\r\n<h2><span id=\"upper-tech-leather\">2. Upper Tech Leather &ndash; mềm nhất Nike từng l&agrave;m?</span></h2>\r\n<figure class=\"image align-center\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260129_nDrUnjWs.jpg\" alt=\"Nike Tiempo Maestro Elite FG - Upper\" width=\"896\" height=\"1152\" />\r\n<figcaption>Nike Tiempo Maestro Elite FG - Upper</figcaption>\r\n</figure>\r\n<p>Điểm thay đổi lớn nhất &ndash; v&agrave; cũng g&acirc;y tranh c&atilde;i nhất &ndash; tr&ecirc;n Tiempo Maestro Elite ch&iacute;nh l&agrave; upper&nbsp;<strong>Tech Leather</strong>. Đ&acirc;y l&agrave; da tổng hợp ho&agrave;n to&agrave;n, được Nike ph&aacute;t triển với mục ti&ecirc;u: t&aacute;i tạo cảm gi&aacute;c da thật nhưng ổn định v&agrave; đồng đều hơn.</p>\r\n<p>Trải nghiệm thực tế cho thấy Tech Leather thực sự&nbsp;<strong>cực kỳ mềm</strong>. Ngay khi xỏ gi&agrave;y, upper &ocirc;m s&aacute;t b&agrave;n ch&acirc;n, dễ uốn, dễ th&iacute;ch nghi, mang lại cảm gi&aacute;c &ldquo;melt v&agrave;o ch&acirc;n&rdquo; rất r&otilde;. So với FlyTouch Plus tr&ecirc;n Legend 10, Tech Leather mềm hơn đ&aacute;ng kể v&agrave; thậm ch&iacute; khiến nhiều người lầm tưởng đ&acirc;y l&agrave; da tự nhi&ecirc;n.</p>\r\n<p>Điểm cộng lớn l&agrave; Tech Leather &iacute;t gi&atilde;n qu&aacute; mức, gi&uacute;p gi&agrave;y giữ form tốt hơn theo thời gian &ndash; điều m&agrave; nhiều đ&ocirc;i da thật kh&ocirc;ng l&agrave;m được.</p>\r\n<div>\r\n<p><iframe src=\"https://www.youtube.com/embed/nx9ruqpQY_w?start=1\" width=\"1000\" height=\"700\" frameborder=\"0\"></iframe></p>\r\n</div>\r\n<h2><span id=\"form-va-size\">3. Form gi&agrave;y &amp; cảm gi&aacute;c mang thực tế</span></h2>\r\n<figure class=\"image align-center\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260129_6Y8YNnc1.jpg\" alt=\"Nike Tiempo Maestro Elite FG - Form gi&agrave;y\" width=\"1000\" height=\"667\" />\r\n<figcaption>Nike Tiempo Maestro Elite FG</figcaption>\r\n</figure>\r\n<p>Nike đ&atilde; chỉnh lại ho&agrave;n to&agrave;n shape so với Legend 10. Tiempo Maestro Elite c&oacute;&nbsp;<strong>forefoot rộng hơn, thể t&iacute;ch gi&agrave;y lớn hơn</strong>, đem lại cảm gi&aacute;c rất &ldquo;Tiempo truyền thống&rdquo;.</p>\r\n<p>D&ugrave; mũi gi&agrave;y nh&igrave;n hơi thấp v&agrave; nhọn, nhưng nhờ Tech Leather qu&aacute; mềm n&ecirc;n kh&ocirc;ng tạo &aacute;p lực hay điểm cấn. Gi&agrave;y ph&ugrave; hợp với đa số form ch&acirc;n từ thon đến b&egrave; vừa.</p>\r\n<p>Về size, trải nghiệm thực tế cho thấy n&ecirc;n đi&nbsp;<strong>true size</strong>&nbsp;Nike. Nếu anh em từng thấy Legend 10 hơi mỏng v&agrave; b&oacute;, th&igrave; Maestro Elite sẽ dễ chịu hơn r&otilde; rệt.</p>\r\n<h2><span id=\"cam-giac-bong\">4. Cảm gi&aacute;c b&oacute;ng &amp; khả năng kiểm so&aacute;t</span></h2>\r\n<p>Cảm gi&aacute;c b&oacute;ng l&agrave; điểm mạnh lớn của Maestro Elite. Upper c&oacute; lớp l&oacute;t v&agrave; foam mỏng b&ecirc;n trong, tạo cảm gi&aacute;c đỡ b&oacute;ng&nbsp;<strong>&ecirc;m &ndash; c&oacute; đệm &ndash; gần b&oacute;ng</strong>.</p>\r\n<p>Trong điều kiện s&acirc;n ướt, bề mặt Tech Leather c&oacute; độ ma s&aacute;t nhẹ, hơi &ldquo;d&iacute;nh&rdquo;, gi&uacute;p cảm gi&aacute;c b&oacute;ng ổn định hơn so với da tự nhi&ecirc;n truyền thống. Với những cầu thủ th&iacute;ch cầm nhịp, giữ b&oacute;ng v&agrave; xử l&yacute; trong kh&ocirc;ng gian hẹp, đ&acirc;y l&agrave; trải nghiệm rất dễ nghiện.</p>\r\n<h2><span id=\"de-maestro-360\">5. Đế Maestro360 &amp; độ b&aacute;m s&acirc;n</span></h2>\r\n<figure class=\"image\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260129_7GYhAEC8.jpg\" alt=\"Nike Tiempo Maestro Elite FG - Đế\" width=\"1070\" height=\"714\" />\r\n<figcaption>Nike Tiempo Maestro Elite FG - Đế</figcaption>\r\n</figure>\r\n<p>Tiempo Maestro Elite sử dụng đế&nbsp;<strong>Maestro360 split-sole</strong>&nbsp;với hai mảng đế ri&ecirc;ng ở mũi v&agrave; g&oacute;t. Cảm gi&aacute;c di chuyển kh&ocirc;ng qu&aacute; &ldquo;speed&rdquo;, nhưng b&ugrave; lại l&agrave; sự linh hoạt v&agrave; ổn định khi xoay trở.</p>\r\n<p>Bộ đinh vẫn mang DNA Tiempo: dễ xoay, b&aacute;m s&acirc;n vừa đủ, kh&ocirc;ng qu&aacute; gắt. Nike c&oacute; tăng độ agressive nhẹ ở mũi để hỗ trợ những pha đạp b&oacute;ng ngắn v&agrave; chuyển hướng nhanh.</p>\r\n<h2><span id=\"diem-tru\">6. Những điểm cần c&acirc;n nhắc</span></h2>\r\n<figure class=\"image align-center\"><img src=\"https://pos.nvncdn.com/3c8244-211061/art/artCT/20260129_Nie56hY2.jpg\" alt=\"Nike Tiempo Maestro Elite FG - G&oacute;t gi&agrave;y\" width=\"1000\" height=\"666\" />\r\n<figcaption>Nike Tiempo Maestro Elite FG - G&oacute;t gi&agrave;y</figcaption>\r\n</figure>\r\n<ul>\r\n<li>G&oacute;t gi&agrave;y hơi rộng với một số người, cảm gi&aacute;c kh&oacute;a g&oacute;t chưa thật &ldquo;chặt&rdquo;</li>\r\n<li>L&oacute;t trong c&oacute; thể hơi trơn nếu d&ugrave;ng tất &iacute;t ma s&aacute;t</li>\r\n<li>Đ&ocirc;i l&uacute;c c&oacute; cảm gi&aacute;c cấn đinh nhẹ khi đạp mũi mạnh (kh&ocirc;ng phổ biến)</li>\r\n</ul>\r\n<p>Những điểm n&agrave;y kh&ocirc;ng phải ai cũng gặp, nhưng anh em n&ecirc;n biết trước để tr&aacute;nh kỳ vọng qu&aacute; mức.</p>\r\n<h2><span id=\"ket-luan\">7. Đ&aacute;nh gi&aacute; tổng kết</span></h2>\r\n<p><strong>Nike Tiempo Maestro Elite</strong>&nbsp;l&agrave; một trong những đ&ocirc;i gi&agrave;y &ecirc;m v&agrave; dễ mang nhất m&agrave; Nike từng l&agrave;m. N&oacute; kh&ocirc;ng c&ograve;n cố chạy theo tốc độ, m&agrave; quay về đ&uacute;ng gi&aacute; trị cốt l&otilde;i của Tiempo:&nbsp;<strong>cảm gi&aacute;c b&oacute;ng, kiểm so&aacute;t v&agrave; sự thoải m&aacute;i</strong>.</p>\r\n<p>Đ&acirc;y l&agrave; lựa chọn rất đ&aacute;ng c&acirc;n nhắc cho tiền vệ trung t&acirc;m, tiền vệ tấn c&ocirc;ng v&agrave; những cầu thủ chơi bằng tư duy. Nếu anh em muốn trải nghiệm trọn vẹn d&ograve;ng Tiempo mới, c&oacute; thể bắt đầu từ danh mục&nbsp;Nike Tiempo ch&iacute;nh h&atilde;ng&nbsp;hoặc tham khảo th&ecirc;m bản tầm trung&nbsp;Tiempo Maestro Academy TF&nbsp;để so s&aacute;nh cảm gi&aacute;c.</p>\r\n<h2><span id=\"he-thong-the-gioi-bong-da\">Hệ thống cửa h&agrave;ng Beyond</span></h2>\r\n<p>C&aacute;c nhận định v&agrave; trải nghiệm trong b&agrave;i được tổng hợp từ thực tế tư vấn, thử gi&agrave;y v&agrave; phản hồi của kh&aacute;ch h&agrave;ng tại hệ thống cửa h&agrave;ng Thế Giới B&oacute;ng Đ&aacute; &ndash; chuy&ecirc;n gi&agrave;y đ&aacute; b&oacute;ng ch&iacute;nh h&atilde;ng.</p>\r\n<p>Tại cửa h&agrave;ng, kh&aacute;ch h&agrave;ng c&oacute; thể thử trực tiếp từng d&ograve;ng gi&agrave;y theo form ch&acirc;n, được tư vấn size ph&ugrave; hợp v&agrave; hỗ trợ đổi size nếu chưa vừa khi sử dụng thực tế.</p>\r\n</div>','2025-09-03 14:29:03.102804','','http://res.cloudinary.com/dt2g4oabz/image/upload/v1777608776/lhlgf9piilpmtacydqtd.jpg','',0,'Review Nike Tiempo Maestro Elite FG - Tiempo bước sang kỷ','review-nike-tiempo-maestro-elite-fg-tiempo-buoc-sang-ky','Review Nike Tiempo Maestro Elite FG - Tiempo bước sang kỷ','2026-05-01 11:18:38.026002',NULL);
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


-- Map the same source data to the existing Vietnamese schema.
INSERT INTO danh_muc (ten_danh_muc)
SELECT DISTINCT c.name FROM category c
WHERE c.name IS NOT NULL AND NOT EXISTS
 (SELECT 1 FROM danh_muc d WHERE d.ten_danh_muc=c.name);

INSERT INTO tai_khoan (ten_dang_nhap,mat_khau,vai_tro,trang_thai)
SELECT u.email,u.password,IF(u.role='ROLE_ADMIN','ADMIN','NHAN_VIEN'),
 IF(u.actived=1 AND COALESCE(u.deleted,0)=0,1,0)
FROM users u WHERE u.role IN ('ROLE_ADMIN','ROLE_EMPLOYEE')
AND NOT EXISTS (SELECT 1 FROM tai_khoan t WHERE t.ten_dang_nhap=u.email);

INSERT INTO nhan_vien (ma_nhan_vien,ho_ten,email,trang_thai,tai_khoan_id)
SELECT CONCAT('SRCNV',u.id),COALESCE(u.full_name,u.email),u.email,t.trang_thai,t.id
FROM users u JOIN tai_khoan t ON t.ten_dang_nhap=u.email
WHERE u.role='ROLE_EMPLOYEE'
AND NOT EXISTS (SELECT 1 FROM nhan_vien n WHERE n.tai_khoan_id=t.id OR n.email=u.email);

INSERT INTO san_pham (ma_san_pham,ten_san_pham,thuong_hieu,mo_ta,gia_ban,hinh_anh,trang_thai,ngay_tao,danh_muc_id)
SELECT CONCAT('SRCSP',p.id),p.name,
 CASE WHEN UPPER(p.name) LIKE '%ADIDAS%' THEN 'Adidas'
 WHEN UPPER(p.name) LIKE '%NIKE%' THEN 'Nike'
 WHEN UPPER(p.name) LIKE '%JOMA%' THEN 'Joma'
 WHEN UPPER(p.name) LIKE '%MIZUNO%' THEN 'Mizuno'
 WHEN UPPER(p.name) LIKE '%ZOCKER%' THEN 'Zocker'
 WHEN UPPER(p.name) LIKE '%WIKA%' THEN 'Wika' ELSE NULL END,
 p.description,COALESCE(p.price,0),p.image,COALESCE(p.active,0),COALESCE(p.created_at,NOW()),
 COALESCE((SELECT MIN(d.id) FROM product_category pc JOIN category c ON c.id=pc.category_id
 JOIN danh_muc d ON d.ten_danh_muc=c.name WHERE pc.product_id=p.id),
 (SELECT id FROM danh_muc WHERE ten_danh_muc='Giày bóng đá' LIMIT 1))
FROM product p WHERE NOT EXISTS
 (SELECT 1 FROM san_pham s WHERE s.ma_san_pham=CONCAT('SRCSP',p.id) OR s.ten_san_pham=p.name);

INSERT INTO san_pham_chi_tiet (san_pham_id,kich_co,mau_sac,so_luong_ton)
SELECT sp.id,sz.name,c.name,SUM(COALESCE(pd.stock,0))
FROM product_detail pd JOIN product p ON p.id=pd.product_id
JOIN san_pham sp ON sp.ten_san_pham=p.name
JOIN size sz ON sz.id=pd.size_id JOIN color c ON c.id=pd.color_id
WHERE NOT EXISTS (SELECT 1 FROM san_pham_chi_tiet x
 WHERE x.san_pham_id=sp.id AND x.kich_co=sz.name AND x.mau_sac=c.name)
GROUP BY sp.id,sz.name,c.name;

INSERT INTO bai_viet (tieu_de,noi_dung,hinh_anh,ngay_dang,tai_khoan_id)
SELECT b.title,COALESCE(b.content,''),b.image_banner,COALESCE(b.created_date,NOW()),
 (SELECT MIN(id) FROM tai_khoan WHERE vai_tro='ADMIN') FROM blog b
WHERE NOT EXISTS (SELECT 1 FROM bai_viet v WHERE v.tieu_de=b.title AND v.noi_dung=COALESCE(b.content,''));
COMMIT;
SET FOREIGN_KEY_CHECKS=1;

-- Select the intended f6s_shop database before import. Back up first.
-- Additive demo content: no DROP, no password/account/order changes.
SET NAMES utf8mb4;
START TRANSACTION;

INSERT INTO banner (active,created_date,display_order,image_url,link_url,page_name,title,update_date,banner_type)
SELECT b'1',NOW(),1,'/image/banners/source-banner1.jpg','/category/nike','/','Bộ sưu tập giày Nike',NOW(),'SLIDER'
WHERE NOT EXISTS (SELECT 1 FROM banner WHERE image_url='/image/banners/source-banner1.jpg' AND page_name='/');
INSERT INTO banner (active,created_date,display_order,image_url,link_url,page_name,title,update_date,banner_type)
SELECT b'1',NOW(),2,'/image/banners/source-banner2.jpg','/category/giay-co-tu-nhien','/','Chọn giày cho sân cỏ tự nhiên',NOW(),'SLIDER'
WHERE NOT EXISTS (SELECT 1 FROM banner WHERE image_url='/image/banners/source-banner2.jpg' AND page_name='/');
INSERT INTO banner (active,created_date,display_order,image_url,link_url,page_name,title,update_date,banner_type)
SELECT b'1',NOW(),3,'/image/banners/source-banner3.jpg','/category/zocker','/','Zocker Winner Energy',NOW(),'SLIDER'
WHERE NOT EXISTS (SELECT 1 FROM banner WHERE image_url='/image/banners/source-banner3.jpg' AND page_name='/');
INSERT INTO banner (active,created_date,display_order,image_url,link_url,page_name,title,update_date,banner_type)
SELECT b'1',NOW(),1,'/image/banners/source-banner4.jpg','/category/adidas','/','Khám phá giày Adidas',NOW(),'NORMAL'
WHERE NOT EXISTS (SELECT 1 FROM banner WHERE image_url='/image/banners/source-banner4.jpg' AND page_name='/');
INSERT INTO banner (active,created_date,display_order,image_url,link_url,page_name,title,update_date,banner_type)
SELECT b'1',NOW(),2,'/image/banners/source-munich.jpg','/category/giay-futsal','/','Lựa chọn giày Futsal',NOW(),'NORMAL'
WHERE NOT EXISTS (SELECT 1 FROM banner WHERE image_url='/image/banners/source-munich.jpg' AND page_name='/');

-- Broaden the label to avoid presenting unrelated Adidas models as F50 Messi.
-- Preserve the existing URL and any custom name chosen by the store owner.
UPDATE category SET name='Adidas nổi bật'
WHERE slug='adidas-f50-messi-' AND TRIM(name)='Adidas F50 Messi';

INSERT INTO product_category (category_id,product_id)
SELECT c.id,p.id FROM category c JOIN product p
  ON p.slug IN ('adidas','nemeziz')
WHERE c.slug='adidas-f50-messi-'
  AND NOT EXISTS (SELECT 1 FROM product_category pc WHERE pc.category_id=c.id AND pc.product_id=p.id);
INSERT INTO product_category (category_id,product_id)
SELECT c.id,p.id FROM category c JOIN product p
  ON p.slug IN ('nike-air-zoom-mercurial-vapor-16-elite-fg-mbappe-personal-edition-grand-purplepale-ivory-fq8683-500',
               'nike-air-zoom-mercurial-vapor-16-pro-fg-attack-racer-bluewhite-fq8685-446')
WHERE c.slug='nike-zoom-mercurial'
  AND NOT EXISTS (SELECT 1 FROM product_category pc WHERE pc.category_id=c.id AND pc.product_id=p.id);

COMMIT;

-- Expected on the bundled seed: no rows. Custom databases may need more content.
SELECT c.id,c.name,c.slug,COUNT(DISTINCT p.id) AS active_products
FROM category c LEFT JOIN product_category pc ON pc.category_id=c.id
LEFT JOIN product p ON p.id=pc.product_id AND p.active=b'1'
WHERE c.deleted=b'0'
GROUP BY c.id,c.name,c.slug HAVING COUNT(DISTINCT p.id)<3;

-- Additive schema update only. Select the intended database first; back up first.
-- No users are deleted, activated, unlocked or assigned a password by this script.
CREATE TABLE IF NOT EXISTS pending_registration (
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) DEFAULT NULL,
    phone VARCHAR(255) DEFAULT NULL,
    created_date DATETIME(6) NOT NULL,
    expires_at DATETIME(6) NOT NULL,
    PRIMARY KEY (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- F6S consolidated schema: shoe modules, 23/10/2026.
-- Chay tren database F6S hien tai. KHONG DROP database/table, KHONG sua users/invoices.
-- Tuong thich MySQL 8 va MariaDB: them cot qua information_schema, chay lai an toan.
CREATE TABLE IF NOT EXISTS shoe_attribute (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    kind VARCHAR(16) NOT NULL,
    name VARCHAR(100) NOT NULL,
    active BIT NOT NULL DEFAULT 1,
    CONSTRAINT uk_shoe_attribute_kind_name UNIQUE (kind, name)
);
SET @ddl = IF(EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='product' AND column_name='brand_id'), 'SELECT 1', 'ALTER TABLE product ADD COLUMN brand_id BIGINT NULL');
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @ddl = IF(EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='product' AND column_name='sole_id'), 'SELECT 1', 'ALTER TABLE product ADD COLUMN sole_id BIGINT NULL');
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @ddl = IF(EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='product' AND column_name='material_id'), 'SELECT 1', 'ALTER TABLE product ADD COLUMN material_id BIGINT NULL');
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;
-- Khong doan thuong hieu/chat lieu/de giay cua san pham cu. Quan tri vien phan loai sau.

-- Consolidated stable catalog identifiers, 23/10/2026.
-- F6S catalog codes. Back up first; run before starting the new application.
-- No product/variant IDs, stock, cart references or historical invoice codes are changed.
SET @ddl = IF(EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='product' AND column_name='code'), 'SELECT 1', 'ALTER TABLE product ADD COLUMN code VARCHAR(32) NULL');
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @ddl = IF(EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='product_detail' AND column_name='legacy_sku'), 'SELECT 1', 'ALTER TABLE product_detail ADD COLUMN legacy_sku VARCHAR(255) NULL');
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

UPDATE product SET code=CONCAT('F6S-SP',LPAD(CAST(id AS CHAR),GREATEST(6,CHAR_LENGTH(CAST(id AS CHAR))),'0')) WHERE code IS NULL OR TRIM(code)='';
UPDATE product_detail SET legacy_sku=sku
WHERE legacy_sku IS NULL AND sku IS NOT NULL
  AND BINARY sku<>BINARY CONCAT('F6S-SKU',LPAD(CAST(id AS CHAR),GREATEST(6,CHAR_LENGTH(CAST(id AS CHAR))),'0'));
UPDATE product_detail SET sku=CONCAT('F6S-SKU',LPAD(CAST(id AS CHAR),GREATEST(6,CHAR_LENGTH(CAST(id AS CHAR))),'0'));

SET @ddl = IF(EXISTS(SELECT 1 FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='product' AND index_name='uk_f6s_product_code'), 'SELECT 1', 'CREATE UNIQUE INDEX uk_f6s_product_code ON product(code)');
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @ddl = IF(EXISTS(SELECT 1 FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='product_detail' AND index_name='uk_f6s_variant_sku'), 'SELECT 1', 'CREATE UNIQUE INDEX uk_f6s_variant_sku ON product_detail(sku)');
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- REPORT ONLY: do not merge variants automatically; existing invoice/cart references need review.
SELECT product_id,color,size,COUNT(*) AS duplicate_variants
FROM product_detail GROUP BY product_id,color,size HAVING COUNT(*)>1;

-- Approved duplicate variant resolution. Historical rows remain intact.
-- Approved merge: source 245 -> target 244, only for product 31 / color 9 / size 12.
-- STOP WEB and back up first. Retain source row, SKU aliases and historical invoices.
-- Refuse to apply if the source is still referenced by carts/open drafts.
CREATE TABLE IF NOT EXISTS catalog_variant_merge (
    migration_key VARCHAR(64) NOT NULL PRIMARY KEY,
    source_variant_id BIGINT NOT NULL,
    target_variant_id BIGINT NOT NULL,
    source_stock_before INT NOT NULL,
    target_stock_before INT NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

START TRANSACTION;
SELECT id FROM product_detail WHERE id IN (244,245) ORDER BY id FOR UPDATE;
SET @f6s_merge_allowed = (
    SELECT COUNT(*) FROM product_detail target JOIN product_detail source ON source.id=245
    WHERE target.id=244 AND target.product_id=31 AND source.product_id=31
      AND target.color=9 AND source.color=9 AND target.size=12 AND source.size=12
      AND target.color_id=9 AND source.color_id=9 AND target.size_id=12 AND source.size_id=12
      AND target.active=b'1' AND (target.price <=> source.price)
      AND target.stock>=0 AND source.stock>=0 AND CAST(target.stock AS SIGNED)+CAST(source.stock AS SIGNED)<=2147483647
      AND NOT EXISTS (SELECT 1 FROM carts WHERE product_detail_id=245)
      AND NOT EXISTS (SELECT 1 FROM order_detail_draft WHERE id_product_detail=245)
      AND NOT EXISTS (SELECT 1 FROM catalog_variant_merge WHERE migration_key='merge-244-245-v1')
);
INSERT INTO catalog_variant_merge (migration_key,source_variant_id,target_variant_id,source_stock_before,target_stock_before)
SELECT 'merge-244-245-v1',source.id,target.id,source.stock,target.stock
FROM product_detail target JOIN product_detail source ON source.id=245
WHERE target.id=244 AND @f6s_merge_allowed=1;
SET @f6s_merge_apply = ROW_COUNT();
UPDATE product_detail target JOIN catalog_variant_merge audit ON audit.target_variant_id=target.id
SET target.stock=audit.target_stock_before+audit.source_stock_before
WHERE audit.migration_key='merge-244-245-v1' AND @f6s_merge_apply=1;
UPDATE product_detail SET stock=0,active=b'0' WHERE id=245 AND @f6s_merge_apply=1;
COMMIT;
SELECT CASE WHEN @f6s_merge_apply=1 THEN 'APPLIED'
            WHEN EXISTS(SELECT 1 FROM catalog_variant_merge WHERE migration_key='merge-244-245-v1') THEN 'ALREADY_APPLIED'
            ELSE 'SKIPPED_REVIEW_CART_DRAFT_OR_VARIANT_DATA' END AS merge_status;

-- Persist customer identity independently of the staff creator.
SET @f6s_customer_column = IF(
  (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='order_draft' AND column_name='customer_id')=0,
  'ALTER TABLE order_draft ADD COLUMN customer_id BIGINT NULL', 'SELECT 1');
PREPARE f6s_customer_stmt FROM @f6s_customer_column;
EXECUTE f6s_customer_stmt;
DEALLOCATE PREPARE f6s_customer_stmt;
-- F6S catalog metadata, 24/10/2026. STOP WEB, back up, select the existing schema.
-- No product, inventory, user or invoice is deleted/renamed/reset.
SET @ddl = IF(EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='shoe_attribute' AND column_name='code'),'SELECT 1','ALTER TABLE shoe_attribute ADD COLUMN code VARCHAR(32) NULL');
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @ddl = IF(EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='shoe_attribute' AND column_name='description'),'SELECT 1','ALTER TABLE shoe_attribute ADD COLUMN description VARCHAR(500) NULL');
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @ddl = IF(EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='shoe_attribute' AND column_name='created_at'),'SELECT 1','ALTER TABLE shoe_attribute ADD COLUMN created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)');
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @ddl = IF(EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='shoe_attribute' AND column_name='updated_at'),'SELECT 1','ALTER TABLE shoe_attribute ADD COLUMN updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)');
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;
UPDATE shoe_attribute SET code=CONCAT('F6S-',CASE kind WHEN 'BRAND' THEN 'TH' WHEN 'SOLE' THEN 'DE' ELSE 'CL' END,LPAD(CAST(id AS CHAR),GREATEST(6,CHAR_LENGTH(CAST(id AS CHAR))),'0')) WHERE code IS NULL OR TRIM(code)='';
SET @ddl = IF(EXISTS(SELECT 1 FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='shoe_attribute' AND index_name='uk_shoe_attribute_code'),'SELECT 1','CREATE UNIQUE INDEX uk_shoe_attribute_code ON shoe_attribute(code)');
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;
CREATE TABLE IF NOT EXISTS catalog_demo_seed (
 seed_key VARCHAR(64) NOT NULL PRIMARY KEY,
 product_id BIGINT NOT NULL UNIQUE,
 created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
 CONSTRAINT fk_catalog_demo_product FOREIGN KEY(product_id) REFERENCES product(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Foreign keys are added only when legacy values have no orphan references.
SET @orphans = (SELECT COUNT(*) FROM product p LEFT JOIN shoe_attribute a ON a.id=p.brand_id WHERE p.brand_id IS NOT NULL AND a.id IS NULL);
SET @ddl = IF(EXISTS(SELECT 1 FROM information_schema.table_constraints WHERE constraint_schema=DATABASE() AND table_name='product' AND constraint_name='fk_f6s_product_brand') OR @orphans>0,'SELECT 1','ALTER TABLE product ADD CONSTRAINT fk_f6s_product_brand FOREIGN KEY (brand_id) REFERENCES shoe_attribute(id)');
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SELECT 'brand_id' AS checked_column,@orphans AS orphan_references_to_review;
SET @orphans = (SELECT COUNT(*) FROM product p LEFT JOIN shoe_attribute a ON a.id=p.sole_id WHERE p.sole_id IS NOT NULL AND a.id IS NULL);
SET @ddl = IF(EXISTS(SELECT 1 FROM information_schema.table_constraints WHERE constraint_schema=DATABASE() AND table_name='product' AND constraint_name='fk_f6s_product_sole') OR @orphans>0,'SELECT 1','ALTER TABLE product ADD CONSTRAINT fk_f6s_product_sole FOREIGN KEY (sole_id) REFERENCES shoe_attribute(id)');
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SELECT 'sole_id' AS checked_column,@orphans AS orphan_references_to_review;
SET @orphans = (SELECT COUNT(*) FROM product p LEFT JOIN shoe_attribute a ON a.id=p.material_id WHERE p.material_id IS NOT NULL AND a.id IS NULL);
SET @ddl = IF(EXISTS(SELECT 1 FROM information_schema.table_constraints WHERE constraint_schema=DATABASE() AND table_name='product' AND constraint_name='fk_f6s_product_material') OR @orphans>0,'SELECT 1','ALTER TABLE product ADD CONSTRAINT fk_f6s_product_material FOREIGN KEY (material_id) REFERENCES shoe_attribute(id)');
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SELECT 'material_id' AS checked_column,@orphans AS orphan_references_to_review;

-- OPTIONAL DEMO ONLY. Back up and stop the web. Run after nang_cap_f6s.sql.
-- Adds demo records without deleting/reclassifying old products or resetting stock on rerun.
-- Serial imports only; do not run concurrently. No real orders, payments, accounts or secrets.
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;
START TRANSACTION;
INSERT INTO shoe_attribute(kind,name,active,description) SELECT 'BRAND','F6S',b'1','Dữ liệu danh mục mẫu; quản trị viên cần kiểm tra trước khi kinh doanh.' WHERE NOT EXISTS(SELECT 1 FROM shoe_attribute WHERE kind='BRAND' AND name='F6S');
INSERT INTO shoe_attribute(kind,name,active,description) SELECT 'BRAND','Nike',b'1','Dữ liệu danh mục mẫu; quản trị viên cần kiểm tra trước khi kinh doanh.' WHERE NOT EXISTS(SELECT 1 FROM shoe_attribute WHERE kind='BRAND' AND name='Nike');
INSERT INTO shoe_attribute(kind,name,active,description) SELECT 'BRAND','Adidas',b'1','Dữ liệu danh mục mẫu; quản trị viên cần kiểm tra trước khi kinh doanh.' WHERE NOT EXISTS(SELECT 1 FROM shoe_attribute WHERE kind='BRAND' AND name='Adidas');
INSERT INTO shoe_attribute(kind,name,active,description) SELECT 'BRAND','Puma',b'1','Dữ liệu danh mục mẫu; quản trị viên cần kiểm tra trước khi kinh doanh.' WHERE NOT EXISTS(SELECT 1 FROM shoe_attribute WHERE kind='BRAND' AND name='Puma');
INSERT INTO shoe_attribute(kind,name,active,description) SELECT 'BRAND','New Balance',b'1','Dữ liệu danh mục mẫu; quản trị viên cần kiểm tra trước khi kinh doanh.' WHERE NOT EXISTS(SELECT 1 FROM shoe_attribute WHERE kind='BRAND' AND name='New Balance');
INSERT INTO shoe_attribute(kind,name,active,description) SELECT 'SOLE','Cao su bám đường',b'1','Dữ liệu danh mục mẫu; quản trị viên cần kiểm tra trước khi kinh doanh.' WHERE NOT EXISTS(SELECT 1 FROM shoe_attribute WHERE kind='SOLE' AND name='Cao su bám đường');
INSERT INTO shoe_attribute(kind,name,active,description) SELECT 'SOLE','EVA',b'1','Dữ liệu danh mục mẫu; quản trị viên cần kiểm tra trước khi kinh doanh.' WHERE NOT EXISTS(SELECT 1 FROM shoe_attribute WHERE kind='SOLE' AND name='EVA');
INSERT INTO shoe_attribute(kind,name,active,description) SELECT 'SOLE','Phylon',b'1','Dữ liệu danh mục mẫu; quản trị viên cần kiểm tra trước khi kinh doanh.' WHERE NOT EXISTS(SELECT 1 FROM shoe_attribute WHERE kind='SOLE' AND name='Phylon');
INSERT INTO shoe_attribute(kind,name,active,description) SELECT 'SOLE','TPU',b'1','Dữ liệu danh mục mẫu; quản trị viên cần kiểm tra trước khi kinh doanh.' WHERE NOT EXISTS(SELECT 1 FROM shoe_attribute WHERE kind='SOLE' AND name='TPU');
INSERT INTO shoe_attribute(kind,name,active,description) SELECT 'SOLE','Cao su non',b'1','Dữ liệu danh mục mẫu; quản trị viên cần kiểm tra trước khi kinh doanh.' WHERE NOT EXISTS(SELECT 1 FROM shoe_attribute WHERE kind='SOLE' AND name='Cao su non');
INSERT INTO shoe_attribute(kind,name,active,description) SELECT 'MATERIAL','Lưới thoáng khí',b'1','Dữ liệu danh mục mẫu; quản trị viên cần kiểm tra trước khi kinh doanh.' WHERE NOT EXISTS(SELECT 1 FROM shoe_attribute WHERE kind='MATERIAL' AND name='Lưới thoáng khí');
INSERT INTO shoe_attribute(kind,name,active,description) SELECT 'MATERIAL','Da tổng hợp',b'1','Dữ liệu danh mục mẫu; quản trị viên cần kiểm tra trước khi kinh doanh.' WHERE NOT EXISTS(SELECT 1 FROM shoe_attribute WHERE kind='MATERIAL' AND name='Da tổng hợp');
INSERT INTO shoe_attribute(kind,name,active,description) SELECT 'MATERIAL','Vải knit',b'1','Dữ liệu danh mục mẫu; quản trị viên cần kiểm tra trước khi kinh doanh.' WHERE NOT EXISTS(SELECT 1 FROM shoe_attribute WHERE kind='MATERIAL' AND name='Vải knit');
INSERT INTO shoe_attribute(kind,name,active,description) SELECT 'MATERIAL','Vải canvas',b'1','Dữ liệu danh mục mẫu; quản trị viên cần kiểm tra trước khi kinh doanh.' WHERE NOT EXISTS(SELECT 1 FROM shoe_attribute WHERE kind='MATERIAL' AND name='Vải canvas');
INSERT INTO shoe_attribute(kind,name,active,description) SELECT 'MATERIAL','Da lộn',b'1','Dữ liệu danh mục mẫu; quản trị viên cần kiểm tra trước khi kinh doanh.' WHERE NOT EXISTS(SELECT 1 FROM shoe_attribute WHERE kind='MATERIAL' AND name='Da lộn');
INSERT INTO size(name,deleted) SELECT '38',b'0' WHERE NOT EXISTS(SELECT 1 FROM size WHERE name='38');
INSERT INTO size(name,deleted) SELECT '39',b'0' WHERE NOT EXISTS(SELECT 1 FROM size WHERE name='39');
INSERT INTO size(name,deleted) SELECT '40',b'0' WHERE NOT EXISTS(SELECT 1 FROM size WHERE name='40');
INSERT INTO size(name,deleted) SELECT '41',b'0' WHERE NOT EXISTS(SELECT 1 FROM size WHERE name='41');
INSERT INTO size(name,deleted) SELECT '42',b'0' WHERE NOT EXISTS(SELECT 1 FROM size WHERE name='42');
INSERT INTO color(name,code,deleted) SELECT 'Đen','#111827',b'0' WHERE NOT EXISTS(SELECT 1 FROM color WHERE name='Đen');
INSERT INTO color(name,code,deleted) SELECT 'Trắng','#FFFFFF',b'0' WHERE NOT EXISTS(SELECT 1 FROM color WHERE name='Trắng');
INSERT INTO color(name,code,deleted) SELECT 'Xám','#6B7280',b'0' WHERE NOT EXISTS(SELECT 1 FROM color WHERE name='Xám');
INSERT INTO color(name,code,deleted) SELECT 'Xanh navy','#1E3A5F',b'0' WHERE NOT EXISTS(SELECT 1 FROM color WHERE name='Xanh navy');
INSERT INTO color(name,code,deleted) SELECT 'Đỏ','#DC2626',b'0' WHERE NOT EXISTS(SELECT 1 FROM color WHERE name='Đỏ');
INSERT INTO category(name,slug,deleted,is_parent,position,created_date,update_date,meta_description,image) SELECT 'Giày chạy bộ','f6s-demo-category-1',b'0',b'1',20,NOW(6),NOW(6),'Danh mục giày thể thao F6S.','/image/demo/catalog-1.svg' WHERE NOT EXISTS(SELECT 1 FROM category WHERE name='Giày chạy bộ');
INSERT INTO category(name,slug,deleted,is_parent,position,created_date,update_date,meta_description,image) SELECT 'Giày tập luyện','f6s-demo-category-2',b'0',b'1',21,NOW(6),NOW(6),'Danh mục giày thể thao F6S.','/image/demo/catalog-2.svg' WHERE NOT EXISTS(SELECT 1 FROM category WHERE name='Giày tập luyện');
INSERT INTO category(name,slug,deleted,is_parent,position,created_date,update_date,meta_description,image) SELECT 'Giày đi bộ','f6s-demo-category-3',b'0',b'1',22,NOW(6),NOW(6),'Danh mục giày thể thao F6S.','/image/demo/catalog-3.svg' WHERE NOT EXISTS(SELECT 1 FROM category WHERE name='Giày đi bộ');
INSERT INTO category(name,slug,deleted,is_parent,position,created_date,update_date,meta_description,image) SELECT 'Giày bóng rổ','f6s-demo-category-4',b'0',b'1',23,NOW(6),NOW(6),'Danh mục giày thể thao F6S.','/image/demo/catalog-4.svg' WHERE NOT EXISTS(SELECT 1 FROM category WHERE name='Giày bóng rổ');
INSERT INTO category(name,slug,deleted,is_parent,position,created_date,update_date,meta_description,image) SELECT 'Giày lifestyle','f6s-demo-category-5',b'0',b'1',24,NOW(6),NOW(6),'Danh mục giày thể thao F6S.','/image/demo/catalog-5.svg' WHERE NOT EXISTS(SELECT 1 FROM category WHERE name='Giày lifestyle');
UPDATE shoe_attribute SET code=CONCAT('F6S-',CASE kind WHEN 'BRAND' THEN 'TH' WHEN 'SOLE' THEN 'DE' ELSE 'CL' END,LPAD(CAST(id AS CHAR),GREATEST(6,CHAR_LENGTH(CAST(id AS CHAR))),'0')) WHERE code IS NULL;
DROP TEMPORARY TABLE IF EXISTS f6s_demo_input_20261024;
CREATE TEMPORARY TABLE f6s_demo_input_20261024(seed_key VARCHAR(64),slug VARCHAR(255),name VARCHAR(255),brand VARCHAR(100),sole VARCHAR(100),material VARCHAR(100),category_name VARCHAR(255),color_name VARCHAR(255),price DOUBLE,image VARCHAR(255)) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
INSERT INTO f6s_demo_input_20261024 VALUES
('catalog-demo-1','f6s-demo-20261024-1','[DEMO] Giày chạy bộ F6S 01','F6S','Cao su bám đường','Lưới thoáng khí','Giày chạy bộ','Đen',590000,'/image/demo/catalog-1.svg'),
('catalog-demo-2','f6s-demo-20261024-2','[DEMO] Giày tập luyện F6S 02','Nike','EVA','Da tổng hợp','Giày tập luyện','Trắng',690000,'/image/demo/catalog-2.svg'),
('catalog-demo-3','f6s-demo-20261024-3','[DEMO] Giày đi bộ F6S 03','Adidas','Phylon','Vải knit','Giày đi bộ','Xám',790000,'/image/demo/catalog-3.svg'),
('catalog-demo-4','f6s-demo-20261024-4','[DEMO] Giày bóng rổ F6S 04','Puma','TPU','Vải canvas','Giày bóng rổ','Xanh navy',890000,'/image/demo/catalog-4.svg'),
('catalog-demo-5','f6s-demo-20261024-5','[DEMO] Giày lifestyle F6S 05','New Balance','Cao su non','Da lộn','Giày lifestyle','Đỏ',990000,'/image/demo/catalog-5.svg');
DROP TEMPORARY TABLE IF EXISTS f6s_demo_new_20261024;
CREATE TEMPORARY TABLE f6s_demo_new_20261024(seed_key VARCHAR(64) PRIMARY KEY) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
INSERT INTO f6s_demo_new_20261024 SELECT d.seed_key FROM f6s_demo_input_20261024 d WHERE NOT EXISTS(SELECT 1 FROM catalog_demo_seed r WHERE r.seed_key=d.seed_key);
INSERT INTO product(name,slug,brand_id,sole_id,material_id,price,ole_price,weight,active,sold,image,description,short_description,meta_title,meta_description,created_at,updated_at)
SELECT d.name,d.slug,b.id,s.id,m.id,d.price,d.price+100000,0.65,b'1',0,d.image,
'<p>DỮ LIỆU DEMO: dùng kiểm thử danh mục, màu, size và giỏ hàng. Không phải sản phẩm thương mại hay thông số được hãng xác nhận. Thay bằng dữ liệu thật trước khi công khai.</p>',
'Sản phẩm minh họa, không phải thông tin thương mại đã xác minh.','F6S DEMO CATALOG 20261024','Dữ liệu minh họa F6S, không phải thông tin sản phẩm thương mại.',NOW(6),NOW(6)
FROM f6s_demo_input_20261024 d
JOIN shoe_attribute b ON b.kind='BRAND' AND b.name=d.brand AND b.active=b'1'
JOIN shoe_attribute s ON s.kind='SOLE' AND s.name=d.sole AND s.active=b'1'
JOIN shoe_attribute m ON m.kind='MATERIAL' AND m.name=d.material AND m.active=b'1'
WHERE NOT EXISTS(SELECT 1 FROM product p WHERE p.slug=d.slug) AND d.seed_key IN (SELECT seed_key FROM f6s_demo_new_20261024);
INSERT INTO catalog_demo_seed(seed_key,product_id)
SELECT d.seed_key,p.id FROM f6s_demo_input_20261024 d JOIN product p ON p.slug=d.slug AND p.meta_title='F6S DEMO CATALOG 20261024'
WHERE NOT EXISTS(SELECT 1 FROM catalog_demo_seed r WHERE r.seed_key=d.seed_key);
UPDATE product p JOIN catalog_demo_seed r ON r.product_id=p.id SET p.code=CONCAT('F6S-SP',LPAD(CAST(p.id AS CHAR),GREATEST(6,CHAR_LENGTH(CAST(p.id AS CHAR))),'0')) WHERE p.code IS NULL;
INSERT INTO product_category(product_id,category_id)
SELECT r.product_id,c.id FROM f6s_demo_input_20261024 d JOIN catalog_demo_seed r ON r.seed_key=d.seed_key
JOIN category c ON c.id=(SELECT MIN(id) FROM category WHERE name=d.category_name AND deleted=b'0')
WHERE NOT EXISTS(SELECT 1 FROM product_category pc WHERE pc.product_id=r.product_id AND pc.category_id=c.id) AND r.seed_key IN (SELECT seed_key FROM f6s_demo_new_20261024);
INSERT INTO product_detail(product_id,color_id,color,size_id,size,stock,price,old_price,active)
SELECT r.product_id,c.id,c.id,s.id,s.id,20,d.price,d.price+100000,b'1'
FROM f6s_demo_input_20261024 d JOIN catalog_demo_seed r ON r.seed_key=d.seed_key
JOIN color c ON c.id=(SELECT MIN(id) FROM color WHERE name=d.color_name AND deleted=b'0')
JOIN size s ON s.name IN ('38','39','40','41','42') AND s.deleted=b'0'
 AND s.id=(SELECT MIN(s2.id) FROM size s2 WHERE s2.name=s.name AND s2.deleted=b'0')
WHERE NOT EXISTS(SELECT 1 FROM product_detail pd WHERE pd.product_id=r.product_id AND pd.color_id=c.id AND pd.size_id=s.id) AND r.seed_key IN (SELECT seed_key FROM f6s_demo_new_20261024);
UPDATE product_detail pd JOIN catalog_demo_seed r ON r.product_id=pd.product_id
SET pd.sku=CONCAT('F6S-SKU',LPAD(CAST(pd.id AS CHAR),GREATEST(6,CHAR_LENGTH(CAST(pd.id AS CHAR))),'0')) WHERE pd.sku IS NULL;
INSERT INTO product_color_image(product_id,color_id,image)
SELECT r.product_id,c.id,d.image FROM f6s_demo_input_20261024 d JOIN catalog_demo_seed r ON r.seed_key=d.seed_key
JOIN color c ON c.id=(SELECT MIN(id) FROM color WHERE name=d.color_name AND deleted=b'0')
WHERE NOT EXISTS(SELECT 1 FROM product_color_image pci WHERE pci.product_id=r.product_id AND pci.color_id=c.id) AND r.seed_key IN (SELECT seed_key FROM f6s_demo_new_20261024);
INSERT INTO product_image(product_id,link_image)
SELECT r.product_id,d.image FROM f6s_demo_input_20261024 d JOIN catalog_demo_seed r ON r.seed_key=d.seed_key
WHERE NOT EXISTS(SELECT 1 FROM product_image pi WHERE pi.product_id=r.product_id AND pi.link_image=d.image) AND r.seed_key IN (SELECT seed_key FROM f6s_demo_new_20261024);
COMMIT;
SELECT r.seed_key,p.code,p.name,COUNT(pd.id) AS variants FROM catalog_demo_seed r JOIN product p ON p.id=r.product_id LEFT JOIN product_detail pd ON pd.product_id=p.id GROUP BY r.seed_key,p.id,p.code,p.name;
SELECT kind,COUNT(*) AS attribute_count FROM shoe_attribute GROUP BY kind;
SELECT d.seed_key,'SKIPPED_REVIEW_INACTIVE_ATTRIBUTE_OR_SLUG_CONFLICT' AS warning FROM f6s_demo_input_20261024 d WHERE NOT EXISTS(SELECT 1 FROM catalog_demo_seed r WHERE r.seed_key=d.seed_key);
SELECT r.seed_key,'REVIEW_DEMO_VARIANT_COUNT' AS warning,COUNT(pd.id) AS variants FROM catalog_demo_seed r LEFT JOIN product_detail pd ON pd.product_id=r.product_id GROUP BY r.seed_key HAVING COUNT(pd.id)<>5;
DROP TEMPORARY TABLE f6s_demo_new_20261024;
DROP TEMPORARY TABLE f6s_demo_input_20261024;
SET @f6s_customer_column = IF(
  (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='invoice' AND column_name='customer_id')=0,
  'ALTER TABLE invoice ADD COLUMN customer_id BIGINT NULL', 'SELECT 1');
PREPARE f6s_customer_stmt FROM @f6s_customer_column;
EXECUTE f6s_customer_stmt;
DEALLOCATE PREPARE f6s_customer_stmt;

-- DEMO DATABASE ONLY. Prerequisites: current full schema and catalog demo seed.
-- Never import into a live store. Synthetic invoices affect revenue reports.
-- All 10 new accounts are disabled: no shared public demo password is installed.
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS demo_dataset_install (
  dataset_key VARCHAR(80) PRIMARY KEY,
  installed_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  description VARCHAR(500) NOT NULL
) ENGINE=InnoDB;
DELIMITER $$
DROP PROCEDURE IF EXISTS f6s_seed_all_modules_20261024$$
CREATE PROCEDURE f6s_seed_all_modules_20261024()
main: BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
  IF DATABASE() IS NULL OR RIGHT(DATABASE(),5) <> '_demo' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='DEMO ONLY: select a separate database ending in _demo';
  END IF;
  START TRANSACTION;
  -- This primary key also serializes concurrent imports. Any failure rolls back all rows.
  INSERT IGNORE INTO demo_dataset_install(dataset_key,description)
  VALUES('all-modules-20261024','Synthetic business fixtures. Not real customers, shipments or payments.');
  IF ROW_COUNT()=0 THEN COMMIT; SELECT 'ALREADY_INSTALLED_NO_CHANGES' AS result; LEAVE main; END IF;
  IF (SELECT COUNT(*) FROM catalog_demo_seed WHERE seed_key IN ('catalog-demo-1','catalog-demo-2','catalog-demo-3','catalog-demo-4','catalog-demo-5')) <> 5 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Import the catalog demo seed first (five shoes required)';
  END IF;
  IF EXISTS(SELECT 1 FROM users WHERE email LIKE 'f6s-demo-%@example.invalid')
     OR EXISTS(SELECT 1 FROM invoice WHERE code LIKE 'F6S-DEMO-HD-%')
     OR EXISTS(SELECT 1 FROM voucher WHERE code LIKE 'F6S-DEMO-VC-%') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Demo identifiers already exist without installation marker; review before importing';
  END IF;
  DROP TEMPORARY TABLE IF EXISTS f6s_seed_rows;
  CREATE TEMPORARY TABLE f6s_seed_rows(n INT PRIMARY KEY,person_name VARCHAR(80),topic VARCHAR(150)) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
  INSERT INTO f6s_seed_rows VALUES
    (1,'An','Chọn size giày chạy bộ'),(2,'Bình','Bảo quản giày thể thao'),
    (3,'Chi','Chọn đế phù hợp mặt sân'),(4,'Dũng','Phân biệt giày tập luyện và đi bộ'),(5,'Hà','Vệ sinh giày đúng cách');
  INSERT INTO users(email,full_name,phone,address,role,user_type,actived,deleted,activation_status,account_non_locked,failed_attempts,is_google_user,created_date)
  SELECT CONCAT('f6s-demo-nv-',n,'@example.invalid'),CONCAT('[DEMO] Nhân viên ',person_name),CONCAT('000000010',n),'Địa chỉ minh họa, không giao hàng','ROLE_EMPLOYEE','NORMAL',b'0',b'0',b'0',b'1',0,b'0',NOW(6) FROM f6s_seed_rows;
  INSERT INTO users(email,full_name,phone,address,role,user_type,actived,deleted,activation_status,account_non_locked,failed_attempts,is_google_user,created_date)
  SELECT CONCAT('f6s-demo-kh-',n,'@example.invalid'),CONCAT('[DEMO] Khách hàng ',person_name),CONCAT('000000020',n),'Địa chỉ minh họa, không giao hàng','ROLE_USER','NORMAL',b'0',b'0',b'0',b'1',0,b'0',NOW(6) FROM f6s_seed_rows;
  DROP TEMPORARY TABLE IF EXISTS f6s_seed_links;
  CREATE TEMPORARY TABLE f6s_seed_links AS
  SELECT r.n,r.person_name,r.topic,u.id customer_id,e.id staff_id,p.id product_id,p.price,p.image,p.name product_name,
    pd.id detail_id,pd.sku,c.name color_name,s.name size_name
  FROM f6s_seed_rows r JOIN users u ON u.email=CONCAT('f6s-demo-kh-',r.n,'@example.invalid')
  JOIN users e ON e.email=CONCAT('f6s-demo-nv-',r.n,'@example.invalid')
  JOIN catalog_demo_seed ds ON ds.seed_key=CONCAT('catalog-demo-',r.n)
  JOIN product p ON p.id=ds.product_id
  JOIN product_detail pd ON pd.id=(SELECT MIN(x.id) FROM product_detail x WHERE x.product_id=p.id AND x.active=b'1')
  JOIN color c ON c.id=pd.color JOIN size s ON s.id=pd.size;
  IF (SELECT COUNT(*) FROM f6s_seed_links) <> 5 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Five valid demo variants are required; no business rows installed';
  END IF;
  INSERT INTO voucher(code,name,discount,min_amount,block,created_date,update_date)
  SELECT CONCAT('F6S-DEMO-VC-',n),CONCAT('[DEMO] Phiếu giảm ',n*10000,' đồng'),n*10000,500000,b'0',NOW(6),NOW(6) FROM f6s_seed_links;
  INSERT INTO discount_product(product_id,user_id,discount_product_type,discount_value,max_discount_value,start_date,end_date,created_date)
  SELECT product_id,staff_id,'PERCENT',5,50000,NOW(6),DATE_ADD(NOW(6),INTERVAL 30 DAY),NOW(6) FROM f6s_seed_links;
  INSERT INTO carts(user_id,product_detail_id,quantity,created_date,update_date)
  SELECT customer_id,detail_id,1,NOW(6),NOW(6) FROM f6s_seed_links;
  INSERT INTO banner(title,image_url,link_url,page_name,banner_type,active,display_order,created_date,update_date)
  SELECT CONCAT('[DEMO] Bộ sưu tập thể thao ',n),image,CONCAT('/product/',(SELECT slug FROM product WHERE id=l.product_id)),'/','SLIDER',b'1',n,NOW(6),NOW(6) FROM f6s_seed_links l;
  INSERT INTO blog(title,slug,seo_title,description,meta_description,content,image_banner,num_view,user_id,created_date,update_date)
  SELECT CONCAT('[DEMO] ',topic),CONCAT('f6s-demo-bai-viet-',n),topic,CONCAT('Hướng dẫn minh họa: ',topic),topic,
    CONCAT('<h2>',topic,'</h2><p>Nội dung minh họa F6S. Hãy kiểm tra bảng size của từng hãng, thử giày vừa chân và sử dụng đúng mục đích.</p><p>Làm sạch nhẹ nhàng, hong khô tự nhiên và thay giày khi đế mất độ bám. Không phải tư vấn chuyên môn hay cam kết thương mại.</p>'),image,0,staff_id,NOW(6),NOW(6) FROM f6s_seed_links;
  INSERT INTO contact(full_name,email,phone,content,ip_address,created_date)
  SELECT CONCAT('[DEMO] Khách hàng ',person_name),CONCAT('f6s-demo-kh-',n,'@example.invalid'),CONCAT('000000020',n),CONCAT('[DEMO] Cần tư vấn: ',topic),'127.0.0.1',NOW(6) FROM f6s_seed_links;
  INSERT INTO chatting(user_id,type,content,created_date)
  SELECT customer_id,'USER',CONCAT('[DEMO] Xin tư vấn ',topic),NOW(6) FROM f6s_seed_links;
  INSERT INTO product_view_history(product_id,user_id,session_id,view_count,created_at,last_viewed_at)
  SELECT product_id,customer_id,CONCAT('F6S-DEMO-SESSION-',n),n,NOW(6),NOW(6) FROM f6s_seed_links;
  INSERT INTO order_draft(customer_id,created_by_id,full_name,phone,email,address_detail,note,total_amount,discount,ship_cost,created_date,update_date)
  SELECT customer_id,staff_id,CONCAT('[DEMO] Khách hàng ',person_name),CONCAT('000000020',n),CONCAT('f6s-demo-kh-',n,'@example.invalid'),
    'Địa chỉ minh họa, không giao hàng',CONCAT('F6S-DEMO-DRAFT-',n),price,0,0,NOW(6),NOW(6) FROM f6s_seed_links;
  INSERT INTO order_detail_draft(order_draft_id,id_product_detail,price,quantity,product_name,product_image,color_name,size_name,sku,weight)
  SELECT d.id,l.detail_id,l.price,1,l.product_name,l.image,l.color_name,l.size_name,l.sku,0.65 FROM f6s_seed_links l JOIN order_draft d ON d.note=CONCAT('F6S-DEMO-DRAFT-',l.n);
  -- Scenarios: counter complete, online waiting, online shipped, online complete, cancelled.
  -- Opening stock is not decremented: these are historical fixtures, not newly placed orders.
  INSERT INTO invoice(code,customer_id,user_id,full_name,phone,email,address_detail,note,total_amount,discount,ship_cost,weight,invoice_type,invoice_status,pay_type,created_date,update_date,completed_date,token)
  SELECT CONCAT('F6S-DEMO-HD-',n),customer_id,IF(n=1,staff_id,customer_id),CONCAT('[DEMO] Khách hàng ',person_name),CONCAT('000000020',n),CONCAT('f6s-demo-kh-',n,'@example.invalid'),
    'Địa chỉ minh họa, không giao hàng','[DEMO] Hóa đơn minh họa; không gửi vận chuyển hoặc coi là doanh thu thật.',price,0,0,0.65,
    IF(n=1,'TAI_QUAY','ONLINE'),CASE n WHEN 1 THEN 'HOAN_THANH' WHEN 2 THEN 'DANG_CHO_VAN_CHUYEN' WHEN 3 THEN 'DA_VAN_CHUYEN' WHEN 4 THEN 'HOAN_THANH' ELSE 'DA_HUY' END,
    'COD',NOW(6),NOW(6),IF(n IN (1,4),NOW(6),NULL),UUID() FROM f6s_seed_links;
  INSERT INTO invoice_detail(id_invoice,id_product_detail,price,quantity,product_name,product_image,color_name,size_name,sku)
  SELECT i.id,l.detail_id,l.price,1,l.product_name,l.image,l.color_name,l.size_name,l.sku FROM f6s_seed_links l JOIN invoice i ON i.code=CONCAT('F6S-DEMO-HD-',l.n);
  INSERT INTO history_invoice_status(invoice_id,user_id,created_by,email,full_name,note,invoice_status,created_date)
  SELECT i.id,l.staff_id,'DEMO FIXTURE',CONCAT('f6s-demo-nv-',l.n,'@example.invalid'),CONCAT('[DEMO] Nhân viên ',l.person_name),'[DEMO] Trạng thái khởi tạo của dữ liệu mô phỏng',i.invoice_status,NOW(6)
  FROM f6s_seed_links l JOIN invoice i ON i.code=CONCAT('F6S-DEMO-HD-',l.n);
  -- Do not forge VNPAY receipts in history_pay: it is also used for callback deduplication.
  DROP TEMPORARY TABLE f6s_seed_links;
  DROP TEMPORARY TABLE f6s_seed_rows;
  COMMIT;
  SELECT 'INSTALLED: 5 employees, 5 customers and 5 records per supported business table' AS result;
END$$
CALL f6s_seed_all_modules_20261024()$$
DROP PROCEDURE f6s_seed_all_modules_20261024$$
DELIMITER ;
